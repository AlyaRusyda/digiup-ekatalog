<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-11-12 14:50:45 --> Config Class Initialized
INFO - 2022-11-12 14:50:45 --> Hooks Class Initialized
DEBUG - 2022-11-12 14:50:46 --> UTF-8 Support Enabled
INFO - 2022-11-12 14:50:46 --> Utf8 Class Initialized
INFO - 2022-11-12 14:50:46 --> URI Class Initialized
INFO - 2022-11-12 14:50:46 --> Router Class Initialized
INFO - 2022-11-12 14:50:46 --> Output Class Initialized
INFO - 2022-11-12 14:50:46 --> Security Class Initialized
DEBUG - 2022-11-12 14:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 14:50:46 --> Input Class Initialized
INFO - 2022-11-12 14:50:46 --> Language Class Initialized
INFO - 2022-11-12 14:50:46 --> Loader Class Initialized
INFO - 2022-11-12 14:50:46 --> Helper loaded: url_helper
INFO - 2022-11-12 14:50:46 --> Controller Class Initialized
INFO - 2022-11-12 14:50:46 --> Model "Penerbit_model" initialized
ERROR - 2022-11-12 14:50:46 --> Severity: Notice --> Undefined property: Penerbit::$db C:\xampp\htdocs\ekatalog\system\core\Model.php 73
ERROR - 2022-11-12 14:50:46 --> Severity: error --> Exception: Call to a member function get() on null C:\xampp\htdocs\ekatalog\application\models\Base_model.php 21
INFO - 2022-11-12 14:54:48 --> Config Class Initialized
INFO - 2022-11-12 14:54:48 --> Hooks Class Initialized
DEBUG - 2022-11-12 14:54:48 --> UTF-8 Support Enabled
INFO - 2022-11-12 14:54:48 --> Utf8 Class Initialized
INFO - 2022-11-12 14:54:48 --> URI Class Initialized
INFO - 2022-11-12 14:54:48 --> Router Class Initialized
INFO - 2022-11-12 14:54:48 --> Output Class Initialized
INFO - 2022-11-12 14:54:48 --> Security Class Initialized
DEBUG - 2022-11-12 14:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 14:54:48 --> Input Class Initialized
INFO - 2022-11-12 14:54:48 --> Language Class Initialized
INFO - 2022-11-12 14:54:48 --> Loader Class Initialized
INFO - 2022-11-12 14:54:48 --> Helper loaded: url_helper
INFO - 2022-11-12 14:54:48 --> Database Driver Class Initialized
INFO - 2022-11-12 14:54:48 --> Helper loaded: form_helper
INFO - 2022-11-12 14:54:48 --> Form Validation Class Initialized
INFO - 2022-11-12 14:54:48 --> Controller Class Initialized
INFO - 2022-11-12 14:54:48 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 14:54:48 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-12 14:54:48 --> Final output sent to browser
DEBUG - 2022-11-12 14:54:48 --> Total execution time: 0.1495
INFO - 2022-11-12 14:54:49 --> Config Class Initialized
INFO - 2022-11-12 14:54:49 --> Hooks Class Initialized
DEBUG - 2022-11-12 14:54:49 --> UTF-8 Support Enabled
INFO - 2022-11-12 14:54:49 --> Utf8 Class Initialized
INFO - 2022-11-12 14:54:49 --> URI Class Initialized
INFO - 2022-11-12 14:54:49 --> Router Class Initialized
INFO - 2022-11-12 14:54:49 --> Output Class Initialized
INFO - 2022-11-12 14:54:49 --> Security Class Initialized
DEBUG - 2022-11-12 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 14:54:49 --> Input Class Initialized
INFO - 2022-11-12 14:54:49 --> Language Class Initialized
INFO - 2022-11-12 14:54:49 --> Loader Class Initialized
INFO - 2022-11-12 14:54:49 --> Helper loaded: url_helper
INFO - 2022-11-12 14:54:49 --> Database Driver Class Initialized
INFO - 2022-11-12 14:54:49 --> Helper loaded: form_helper
INFO - 2022-11-12 14:54:49 --> Form Validation Class Initialized
INFO - 2022-11-12 14:54:49 --> Controller Class Initialized
INFO - 2022-11-12 14:54:49 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 14:54:49 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-12 14:54:49 --> Final output sent to browser
DEBUG - 2022-11-12 14:54:49 --> Total execution time: 0.0385
INFO - 2022-11-12 15:14:06 --> Config Class Initialized
INFO - 2022-11-12 15:14:06 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:14:06 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:14:06 --> Utf8 Class Initialized
INFO - 2022-11-12 15:14:06 --> URI Class Initialized
INFO - 2022-11-12 15:14:06 --> Router Class Initialized
INFO - 2022-11-12 15:14:06 --> Output Class Initialized
INFO - 2022-11-12 15:14:06 --> Security Class Initialized
DEBUG - 2022-11-12 15:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:14:06 --> Input Class Initialized
INFO - 2022-11-12 15:14:06 --> Language Class Initialized
INFO - 2022-11-12 15:14:06 --> Loader Class Initialized
INFO - 2022-11-12 15:14:06 --> Helper loaded: url_helper
INFO - 2022-11-12 15:14:06 --> Database Driver Class Initialized
INFO - 2022-11-12 15:14:06 --> Helper loaded: form_helper
INFO - 2022-11-12 15:14:06 --> Form Validation Class Initialized
INFO - 2022-11-12 15:14:06 --> Controller Class Initialized
INFO - 2022-11-12 15:14:06 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 15:14:06 --> Final output sent to browser
DEBUG - 2022-11-12 15:14:06 --> Total execution time: 0.0326
INFO - 2022-11-12 15:14:11 --> Config Class Initialized
INFO - 2022-11-12 15:14:11 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:14:11 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:14:11 --> Utf8 Class Initialized
INFO - 2022-11-12 15:14:11 --> URI Class Initialized
INFO - 2022-11-12 15:14:11 --> Router Class Initialized
INFO - 2022-11-12 15:14:11 --> Output Class Initialized
INFO - 2022-11-12 15:14:11 --> Security Class Initialized
DEBUG - 2022-11-12 15:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:14:11 --> Input Class Initialized
INFO - 2022-11-12 15:14:11 --> Language Class Initialized
INFO - 2022-11-12 15:14:11 --> Loader Class Initialized
INFO - 2022-11-12 15:14:11 --> Helper loaded: url_helper
INFO - 2022-11-12 15:14:11 --> Database Driver Class Initialized
INFO - 2022-11-12 15:14:11 --> Helper loaded: form_helper
INFO - 2022-11-12 15:14:11 --> Form Validation Class Initialized
INFO - 2022-11-12 15:14:11 --> Controller Class Initialized
INFO - 2022-11-12 15:14:11 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 15:14:11 --> Final output sent to browser
DEBUG - 2022-11-12 15:14:11 --> Total execution time: 0.0307
INFO - 2022-11-12 15:48:24 --> Config Class Initialized
INFO - 2022-11-12 15:48:24 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:48:24 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:48:24 --> Utf8 Class Initialized
INFO - 2022-11-12 15:48:24 --> URI Class Initialized
INFO - 2022-11-12 15:48:24 --> Router Class Initialized
INFO - 2022-11-12 15:48:24 --> Output Class Initialized
INFO - 2022-11-12 15:48:24 --> Security Class Initialized
DEBUG - 2022-11-12 15:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:48:24 --> Input Class Initialized
INFO - 2022-11-12 15:48:24 --> Language Class Initialized
INFO - 2022-11-12 15:48:24 --> Loader Class Initialized
INFO - 2022-11-12 15:48:24 --> Helper loaded: url_helper
INFO - 2022-11-12 15:48:24 --> Database Driver Class Initialized
INFO - 2022-11-12 15:48:24 --> Helper loaded: form_helper
INFO - 2022-11-12 15:48:24 --> Form Validation Class Initialized
INFO - 2022-11-12 15:48:24 --> Controller Class Initialized
INFO - 2022-11-12 15:48:24 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 15:48:24 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-12 15:48:24 --> Final output sent to browser
DEBUG - 2022-11-12 15:48:24 --> Total execution time: 0.0350
INFO - 2022-11-12 15:49:06 --> Config Class Initialized
INFO - 2022-11-12 15:49:06 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:49:06 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:49:06 --> Utf8 Class Initialized
INFO - 2022-11-12 15:49:06 --> URI Class Initialized
INFO - 2022-11-12 15:49:06 --> Router Class Initialized
INFO - 2022-11-12 15:49:06 --> Output Class Initialized
INFO - 2022-11-12 15:49:06 --> Security Class Initialized
DEBUG - 2022-11-12 15:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:49:06 --> Input Class Initialized
INFO - 2022-11-12 15:49:06 --> Language Class Initialized
INFO - 2022-11-12 15:49:06 --> Loader Class Initialized
INFO - 2022-11-12 15:49:06 --> Helper loaded: url_helper
INFO - 2022-11-12 15:49:06 --> Database Driver Class Initialized
INFO - 2022-11-12 15:49:06 --> Helper loaded: form_helper
INFO - 2022-11-12 15:49:06 --> Form Validation Class Initialized
INFO - 2022-11-12 15:49:06 --> Controller Class Initialized
INFO - 2022-11-12 15:49:06 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 15:49:06 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-12 15:49:06 --> Final output sent to browser
DEBUG - 2022-11-12 15:49:06 --> Total execution time: 0.0401
INFO - 2022-11-12 15:49:18 --> Config Class Initialized
INFO - 2022-11-12 15:49:18 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:49:18 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:49:18 --> Utf8 Class Initialized
INFO - 2022-11-12 15:49:18 --> URI Class Initialized
INFO - 2022-11-12 15:49:18 --> Router Class Initialized
INFO - 2022-11-12 15:49:18 --> Output Class Initialized
INFO - 2022-11-12 15:49:18 --> Security Class Initialized
DEBUG - 2022-11-12 15:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:49:18 --> Input Class Initialized
INFO - 2022-11-12 15:49:18 --> Language Class Initialized
INFO - 2022-11-12 15:49:18 --> Loader Class Initialized
INFO - 2022-11-12 15:49:18 --> Helper loaded: url_helper
INFO - 2022-11-12 15:49:18 --> Database Driver Class Initialized
INFO - 2022-11-12 15:49:18 --> Helper loaded: form_helper
INFO - 2022-11-12 15:49:18 --> Form Validation Class Initialized
INFO - 2022-11-12 15:49:18 --> Controller Class Initialized
INFO - 2022-11-12 15:49:18 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 15:49:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-11-12 15:49:18 --> Config Class Initialized
INFO - 2022-11-12 15:49:18 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:49:18 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:49:18 --> Utf8 Class Initialized
INFO - 2022-11-12 15:49:18 --> URI Class Initialized
INFO - 2022-11-12 15:49:18 --> Router Class Initialized
INFO - 2022-11-12 15:49:18 --> Output Class Initialized
INFO - 2022-11-12 15:49:18 --> Security Class Initialized
DEBUG - 2022-11-12 15:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:49:18 --> Input Class Initialized
INFO - 2022-11-12 15:49:18 --> Language Class Initialized
INFO - 2022-11-12 15:49:18 --> Loader Class Initialized
INFO - 2022-11-12 15:49:18 --> Helper loaded: url_helper
INFO - 2022-11-12 15:49:18 --> Database Driver Class Initialized
INFO - 2022-11-12 15:49:18 --> Helper loaded: form_helper
INFO - 2022-11-12 15:49:18 --> Form Validation Class Initialized
INFO - 2022-11-12 15:49:18 --> Controller Class Initialized
INFO - 2022-11-12 15:49:18 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 15:49:18 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-12 15:49:18 --> Final output sent to browser
DEBUG - 2022-11-12 15:49:18 --> Total execution time: 0.0320
INFO - 2022-11-12 15:50:22 --> Config Class Initialized
INFO - 2022-11-12 15:50:22 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:50:22 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:50:22 --> Utf8 Class Initialized
INFO - 2022-11-12 15:50:22 --> URI Class Initialized
INFO - 2022-11-12 15:50:22 --> Router Class Initialized
INFO - 2022-11-12 15:50:22 --> Output Class Initialized
INFO - 2022-11-12 15:50:22 --> Security Class Initialized
DEBUG - 2022-11-12 15:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:50:22 --> Input Class Initialized
INFO - 2022-11-12 15:50:22 --> Language Class Initialized
INFO - 2022-11-12 15:50:22 --> Loader Class Initialized
INFO - 2022-11-12 15:50:22 --> Helper loaded: url_helper
INFO - 2022-11-12 15:50:22 --> Database Driver Class Initialized
INFO - 2022-11-12 15:50:22 --> Helper loaded: form_helper
INFO - 2022-11-12 15:50:22 --> Form Validation Class Initialized
INFO - 2022-11-12 15:50:22 --> Controller Class Initialized
INFO - 2022-11-12 15:50:22 --> Model "Penerbit_model" initialized
ERROR - 2022-11-12 15:50:22 --> Severity: Notice --> Undefined variable: kode C:\xampp\htdocs\ekatalog\application\views\penerbit\detail.php 12
INFO - 2022-11-12 15:50:22 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/detail.php
INFO - 2022-11-12 15:50:22 --> Final output sent to browser
DEBUG - 2022-11-12 15:50:22 --> Total execution time: 0.0444
INFO - 2022-11-12 15:53:42 --> Config Class Initialized
INFO - 2022-11-12 15:53:42 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:53:42 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:53:42 --> Utf8 Class Initialized
INFO - 2022-11-12 15:53:42 --> URI Class Initialized
INFO - 2022-11-12 15:53:42 --> Router Class Initialized
INFO - 2022-11-12 15:53:42 --> Output Class Initialized
INFO - 2022-11-12 15:53:42 --> Security Class Initialized
DEBUG - 2022-11-12 15:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:53:42 --> Input Class Initialized
INFO - 2022-11-12 15:53:42 --> Language Class Initialized
INFO - 2022-11-12 15:53:42 --> Loader Class Initialized
INFO - 2022-11-12 15:53:42 --> Helper loaded: url_helper
INFO - 2022-11-12 15:53:42 --> Database Driver Class Initialized
INFO - 2022-11-12 15:53:42 --> Helper loaded: form_helper
INFO - 2022-11-12 15:53:42 --> Form Validation Class Initialized
INFO - 2022-11-12 15:53:42 --> Controller Class Initialized
INFO - 2022-11-12 15:53:42 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 15:53:42 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/detail.php
INFO - 2022-11-12 15:53:42 --> Final output sent to browser
DEBUG - 2022-11-12 15:53:42 --> Total execution time: 0.0343
INFO - 2022-11-12 15:53:46 --> Config Class Initialized
INFO - 2022-11-12 15:53:46 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:53:46 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:53:46 --> Utf8 Class Initialized
INFO - 2022-11-12 15:53:46 --> URI Class Initialized
INFO - 2022-11-12 15:53:46 --> Router Class Initialized
INFO - 2022-11-12 15:53:46 --> Output Class Initialized
INFO - 2022-11-12 15:53:46 --> Security Class Initialized
DEBUG - 2022-11-12 15:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:53:46 --> Input Class Initialized
INFO - 2022-11-12 15:53:46 --> Language Class Initialized
INFO - 2022-11-12 15:53:46 --> Loader Class Initialized
INFO - 2022-11-12 15:53:46 --> Helper loaded: url_helper
INFO - 2022-11-12 15:53:46 --> Database Driver Class Initialized
INFO - 2022-11-12 15:53:46 --> Helper loaded: form_helper
INFO - 2022-11-12 15:53:46 --> Form Validation Class Initialized
INFO - 2022-11-12 15:53:46 --> Controller Class Initialized
INFO - 2022-11-12 15:53:46 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 15:53:46 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-12 15:53:46 --> Final output sent to browser
DEBUG - 2022-11-12 15:53:46 --> Total execution time: 0.0352
INFO - 2022-11-12 15:54:05 --> Config Class Initialized
INFO - 2022-11-12 15:54:05 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:54:05 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:54:05 --> Utf8 Class Initialized
INFO - 2022-11-12 15:54:05 --> URI Class Initialized
INFO - 2022-11-12 15:54:05 --> Router Class Initialized
INFO - 2022-11-12 15:54:05 --> Output Class Initialized
INFO - 2022-11-12 15:54:05 --> Security Class Initialized
DEBUG - 2022-11-12 15:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:54:05 --> Input Class Initialized
INFO - 2022-11-12 15:54:05 --> Language Class Initialized
INFO - 2022-11-12 15:54:05 --> Loader Class Initialized
INFO - 2022-11-12 15:54:05 --> Helper loaded: url_helper
INFO - 2022-11-12 15:54:05 --> Database Driver Class Initialized
INFO - 2022-11-12 15:54:05 --> Helper loaded: form_helper
INFO - 2022-11-12 15:54:05 --> Form Validation Class Initialized
INFO - 2022-11-12 15:54:05 --> Controller Class Initialized
INFO - 2022-11-12 15:54:05 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 15:54:05 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/detail.php
INFO - 2022-11-12 15:54:05 --> Final output sent to browser
DEBUG - 2022-11-12 15:54:05 --> Total execution time: 0.0325
INFO - 2022-11-12 15:58:09 --> Config Class Initialized
INFO - 2022-11-12 15:58:09 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:58:09 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:58:09 --> Utf8 Class Initialized
INFO - 2022-11-12 15:58:09 --> URI Class Initialized
INFO - 2022-11-12 15:58:09 --> Router Class Initialized
INFO - 2022-11-12 15:58:09 --> Output Class Initialized
INFO - 2022-11-12 15:58:09 --> Security Class Initialized
DEBUG - 2022-11-12 15:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:58:09 --> Input Class Initialized
INFO - 2022-11-12 15:58:09 --> Language Class Initialized
INFO - 2022-11-12 15:58:09 --> Loader Class Initialized
INFO - 2022-11-12 15:58:09 --> Helper loaded: url_helper
INFO - 2022-11-12 15:58:09 --> Database Driver Class Initialized
INFO - 2022-11-12 15:58:09 --> Helper loaded: form_helper
INFO - 2022-11-12 15:58:09 --> Form Validation Class Initialized
INFO - 2022-11-12 15:58:09 --> Controller Class Initialized
INFO - 2022-11-12 15:58:09 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 15:58:09 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/detail.php
INFO - 2022-11-12 15:58:09 --> Final output sent to browser
DEBUG - 2022-11-12 15:58:09 --> Total execution time: 0.0386
INFO - 2022-11-12 15:58:10 --> Config Class Initialized
INFO - 2022-11-12 15:58:10 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:58:10 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:58:10 --> Utf8 Class Initialized
INFO - 2022-11-12 15:58:10 --> URI Class Initialized
INFO - 2022-11-12 15:58:10 --> Router Class Initialized
INFO - 2022-11-12 15:58:10 --> Output Class Initialized
INFO - 2022-11-12 15:58:10 --> Security Class Initialized
DEBUG - 2022-11-12 15:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:58:10 --> Input Class Initialized
INFO - 2022-11-12 15:58:10 --> Language Class Initialized
ERROR - 2022-11-12 15:58:10 --> 404 Page Not Found: Buku/index
INFO - 2022-11-12 15:58:12 --> Config Class Initialized
INFO - 2022-11-12 15:58:12 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:58:12 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:58:12 --> Utf8 Class Initialized
INFO - 2022-11-12 15:58:12 --> URI Class Initialized
INFO - 2022-11-12 15:58:12 --> Router Class Initialized
INFO - 2022-11-12 15:58:12 --> Output Class Initialized
INFO - 2022-11-12 15:58:12 --> Security Class Initialized
DEBUG - 2022-11-12 15:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:58:12 --> Input Class Initialized
INFO - 2022-11-12 15:58:12 --> Language Class Initialized
INFO - 2022-11-12 15:58:12 --> Loader Class Initialized
INFO - 2022-11-12 15:58:12 --> Helper loaded: url_helper
INFO - 2022-11-12 15:58:12 --> Database Driver Class Initialized
INFO - 2022-11-12 15:58:12 --> Helper loaded: form_helper
INFO - 2022-11-12 15:58:12 --> Form Validation Class Initialized
INFO - 2022-11-12 15:58:12 --> Controller Class Initialized
INFO - 2022-11-12 15:58:12 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 15:58:12 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-12 15:58:12 --> Final output sent to browser
DEBUG - 2022-11-12 15:58:12 --> Total execution time: 0.0394
INFO - 2022-11-12 15:59:37 --> Config Class Initialized
INFO - 2022-11-12 15:59:37 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:59:37 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:59:37 --> Utf8 Class Initialized
INFO - 2022-11-12 15:59:37 --> URI Class Initialized
INFO - 2022-11-12 15:59:37 --> Router Class Initialized
INFO - 2022-11-12 15:59:37 --> Output Class Initialized
INFO - 2022-11-12 15:59:37 --> Security Class Initialized
DEBUG - 2022-11-12 15:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:59:37 --> Input Class Initialized
INFO - 2022-11-12 15:59:37 --> Language Class Initialized
INFO - 2022-11-12 15:59:37 --> Loader Class Initialized
INFO - 2022-11-12 15:59:37 --> Helper loaded: url_helper
INFO - 2022-11-12 15:59:37 --> Database Driver Class Initialized
INFO - 2022-11-12 15:59:37 --> Helper loaded: form_helper
INFO - 2022-11-12 15:59:37 --> Form Validation Class Initialized
INFO - 2022-11-12 15:59:37 --> Controller Class Initialized
INFO - 2022-11-12 15:59:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 15:59:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/detail.php
INFO - 2022-11-12 15:59:37 --> Final output sent to browser
DEBUG - 2022-11-12 15:59:37 --> Total execution time: 0.0342
INFO - 2022-11-12 15:59:40 --> Config Class Initialized
INFO - 2022-11-12 15:59:40 --> Hooks Class Initialized
DEBUG - 2022-11-12 15:59:40 --> UTF-8 Support Enabled
INFO - 2022-11-12 15:59:40 --> Utf8 Class Initialized
INFO - 2022-11-12 15:59:40 --> URI Class Initialized
INFO - 2022-11-12 15:59:40 --> Router Class Initialized
INFO - 2022-11-12 15:59:40 --> Output Class Initialized
INFO - 2022-11-12 15:59:40 --> Security Class Initialized
DEBUG - 2022-11-12 15:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-12 15:59:40 --> Input Class Initialized
INFO - 2022-11-12 15:59:40 --> Language Class Initialized
INFO - 2022-11-12 15:59:40 --> Loader Class Initialized
INFO - 2022-11-12 15:59:40 --> Helper loaded: url_helper
INFO - 2022-11-12 15:59:40 --> Database Driver Class Initialized
INFO - 2022-11-12 15:59:40 --> Helper loaded: form_helper
INFO - 2022-11-12 15:59:40 --> Form Validation Class Initialized
INFO - 2022-11-12 15:59:40 --> Controller Class Initialized
INFO - 2022-11-12 15:59:40 --> Model "Penerbit_model" initialized
INFO - 2022-11-12 15:59:40 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/detail.php
INFO - 2022-11-12 15:59:40 --> Final output sent to browser
DEBUG - 2022-11-12 15:59:40 --> Total execution time: 0.0372
