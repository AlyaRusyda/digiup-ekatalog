<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-11-11 14:00:28 --> Config Class Initialized
INFO - 2022-11-11 14:00:28 --> Hooks Class Initialized
DEBUG - 2022-11-11 14:00:28 --> UTF-8 Support Enabled
INFO - 2022-11-11 14:00:28 --> Utf8 Class Initialized
INFO - 2022-11-11 14:00:28 --> URI Class Initialized
DEBUG - 2022-11-11 14:00:28 --> No URI present. Default controller set.
INFO - 2022-11-11 14:00:28 --> Router Class Initialized
INFO - 2022-11-11 14:00:28 --> Output Class Initialized
INFO - 2022-11-11 14:00:28 --> Security Class Initialized
DEBUG - 2022-11-11 14:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-11 14:00:28 --> Input Class Initialized
INFO - 2022-11-11 14:00:28 --> Language Class Initialized
INFO - 2022-11-11 14:00:28 --> Loader Class Initialized
INFO - 2022-11-11 14:00:28 --> Helper loaded: url_helper
INFO - 2022-11-11 14:00:28 --> Controller Class Initialized
INFO - 2022-11-11 14:00:28 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-11 14:00:28 --> Final output sent to browser
DEBUG - 2022-11-11 14:00:28 --> Total execution time: 0.1132
INFO - 2022-11-11 14:00:30 --> Config Class Initialized
INFO - 2022-11-11 14:00:30 --> Hooks Class Initialized
DEBUG - 2022-11-11 14:00:30 --> UTF-8 Support Enabled
INFO - 2022-11-11 14:00:30 --> Utf8 Class Initialized
INFO - 2022-11-11 14:00:30 --> URI Class Initialized
DEBUG - 2022-11-11 14:00:30 --> No URI present. Default controller set.
INFO - 2022-11-11 14:00:30 --> Router Class Initialized
INFO - 2022-11-11 14:00:30 --> Output Class Initialized
INFO - 2022-11-11 14:00:30 --> Security Class Initialized
DEBUG - 2022-11-11 14:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-11 14:00:30 --> Input Class Initialized
INFO - 2022-11-11 14:00:30 --> Language Class Initialized
INFO - 2022-11-11 14:00:30 --> Loader Class Initialized
INFO - 2022-11-11 14:00:30 --> Helper loaded: url_helper
INFO - 2022-11-11 14:00:30 --> Controller Class Initialized
INFO - 2022-11-11 14:00:30 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-11 14:00:30 --> Final output sent to browser
DEBUG - 2022-11-11 14:00:30 --> Total execution time: 0.0251
INFO - 2022-11-11 14:01:51 --> Config Class Initialized
INFO - 2022-11-11 14:01:51 --> Hooks Class Initialized
DEBUG - 2022-11-11 14:01:51 --> UTF-8 Support Enabled
INFO - 2022-11-11 14:01:51 --> Utf8 Class Initialized
INFO - 2022-11-11 14:01:51 --> URI Class Initialized
DEBUG - 2022-11-11 14:01:51 --> No URI present. Default controller set.
INFO - 2022-11-11 14:01:51 --> Router Class Initialized
INFO - 2022-11-11 14:01:51 --> Output Class Initialized
INFO - 2022-11-11 14:01:51 --> Security Class Initialized
DEBUG - 2022-11-11 14:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-11 14:01:51 --> Input Class Initialized
INFO - 2022-11-11 14:01:51 --> Language Class Initialized
INFO - 2022-11-11 14:01:51 --> Loader Class Initialized
INFO - 2022-11-11 14:01:51 --> Helper loaded: url_helper
INFO - 2022-11-11 14:01:51 --> Controller Class Initialized
INFO - 2022-11-11 14:01:51 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-11 14:01:51 --> Final output sent to browser
DEBUG - 2022-11-11 14:01:51 --> Total execution time: 0.0211
INFO - 2022-11-11 14:01:51 --> Config Class Initialized
INFO - 2022-11-11 14:01:51 --> Hooks Class Initialized
DEBUG - 2022-11-11 14:01:51 --> UTF-8 Support Enabled
INFO - 2022-11-11 14:01:51 --> Utf8 Class Initialized
INFO - 2022-11-11 14:01:51 --> URI Class Initialized
DEBUG - 2022-11-11 14:01:51 --> No URI present. Default controller set.
INFO - 2022-11-11 14:01:51 --> Router Class Initialized
INFO - 2022-11-11 14:01:51 --> Output Class Initialized
INFO - 2022-11-11 14:01:51 --> Security Class Initialized
DEBUG - 2022-11-11 14:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-11 14:01:51 --> Input Class Initialized
INFO - 2022-11-11 14:01:51 --> Language Class Initialized
INFO - 2022-11-11 14:01:51 --> Loader Class Initialized
INFO - 2022-11-11 14:01:51 --> Helper loaded: url_helper
INFO - 2022-11-11 14:01:51 --> Controller Class Initialized
INFO - 2022-11-11 14:01:51 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-11 14:01:51 --> Final output sent to browser
DEBUG - 2022-11-11 14:01:51 --> Total execution time: 0.0185
INFO - 2022-11-11 14:11:49 --> Config Class Initialized
INFO - 2022-11-11 14:11:49 --> Hooks Class Initialized
DEBUG - 2022-11-11 14:11:49 --> UTF-8 Support Enabled
INFO - 2022-11-11 14:11:49 --> Utf8 Class Initialized
INFO - 2022-11-11 14:11:49 --> URI Class Initialized
INFO - 2022-11-11 14:11:49 --> Router Class Initialized
INFO - 2022-11-11 14:11:49 --> Output Class Initialized
INFO - 2022-11-11 14:11:49 --> Security Class Initialized
DEBUG - 2022-11-11 14:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-11 14:11:49 --> Input Class Initialized
INFO - 2022-11-11 14:11:49 --> Language Class Initialized
INFO - 2022-11-11 14:11:49 --> Loader Class Initialized
INFO - 2022-11-11 14:11:49 --> Helper loaded: url_helper
INFO - 2022-11-11 14:11:49 --> Controller Class Initialized
INFO - 2022-11-11 14:12:58 --> Config Class Initialized
INFO - 2022-11-11 14:12:58 --> Hooks Class Initialized
DEBUG - 2022-11-11 14:12:58 --> UTF-8 Support Enabled
INFO - 2022-11-11 14:12:58 --> Utf8 Class Initialized
INFO - 2022-11-11 14:12:58 --> URI Class Initialized
INFO - 2022-11-11 14:12:58 --> Router Class Initialized
INFO - 2022-11-11 14:12:58 --> Output Class Initialized
INFO - 2022-11-11 14:12:58 --> Security Class Initialized
DEBUG - 2022-11-11 14:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-11 14:12:58 --> Input Class Initialized
INFO - 2022-11-11 14:12:58 --> Language Class Initialized
INFO - 2022-11-11 14:12:58 --> Loader Class Initialized
INFO - 2022-11-11 14:12:58 --> Helper loaded: url_helper
INFO - 2022-11-11 14:12:58 --> Controller Class Initialized
INFO - 2022-11-11 14:12:58 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\hello.php
INFO - 2022-11-11 14:12:58 --> Final output sent to browser
DEBUG - 2022-11-11 14:12:58 --> Total execution time: 0.0214
INFO - 2022-11-11 14:13:08 --> Config Class Initialized
INFO - 2022-11-11 14:13:08 --> Hooks Class Initialized
DEBUG - 2022-11-11 14:13:08 --> UTF-8 Support Enabled
INFO - 2022-11-11 14:13:08 --> Utf8 Class Initialized
INFO - 2022-11-11 14:13:08 --> URI Class Initialized
INFO - 2022-11-11 14:13:08 --> Router Class Initialized
INFO - 2022-11-11 14:13:08 --> Output Class Initialized
INFO - 2022-11-11 14:13:08 --> Security Class Initialized
DEBUG - 2022-11-11 14:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-11 14:13:08 --> Input Class Initialized
INFO - 2022-11-11 14:13:08 --> Language Class Initialized
INFO - 2022-11-11 14:13:08 --> Loader Class Initialized
INFO - 2022-11-11 14:13:08 --> Helper loaded: url_helper
INFO - 2022-11-11 14:13:08 --> Controller Class Initialized
INFO - 2022-11-11 14:13:08 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\hello.php
INFO - 2022-11-11 14:13:08 --> Final output sent to browser
DEBUG - 2022-11-11 14:13:08 --> Total execution time: 0.0201
INFO - 2022-11-11 14:15:03 --> Config Class Initialized
INFO - 2022-11-11 14:15:03 --> Hooks Class Initialized
DEBUG - 2022-11-11 14:15:03 --> UTF-8 Support Enabled
INFO - 2022-11-11 14:15:03 --> Utf8 Class Initialized
INFO - 2022-11-11 14:15:03 --> URI Class Initialized
INFO - 2022-11-11 14:15:03 --> Router Class Initialized
INFO - 2022-11-11 14:15:03 --> Output Class Initialized
INFO - 2022-11-11 14:15:03 --> Security Class Initialized
DEBUG - 2022-11-11 14:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-11 14:15:03 --> Input Class Initialized
INFO - 2022-11-11 14:15:03 --> Language Class Initialized
INFO - 2022-11-11 14:15:03 --> Loader Class Initialized
INFO - 2022-11-11 14:15:03 --> Helper loaded: url_helper
INFO - 2022-11-11 14:15:03 --> Controller Class Initialized
INFO - 2022-11-11 14:15:03 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\hello.php
INFO - 2022-11-11 14:15:03 --> Final output sent to browser
DEBUG - 2022-11-11 14:15:03 --> Total execution time: 0.0562
INFO - 2022-11-11 14:26:37 --> Config Class Initialized
INFO - 2022-11-11 14:26:37 --> Hooks Class Initialized
DEBUG - 2022-11-11 14:26:37 --> UTF-8 Support Enabled
INFO - 2022-11-11 14:26:37 --> Utf8 Class Initialized
INFO - 2022-11-11 14:26:37 --> URI Class Initialized
INFO - 2022-11-11 14:26:37 --> Router Class Initialized
INFO - 2022-11-11 14:26:37 --> Output Class Initialized
INFO - 2022-11-11 14:26:37 --> Security Class Initialized
DEBUG - 2022-11-11 14:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-11 14:26:37 --> Input Class Initialized
INFO - 2022-11-11 14:26:37 --> Language Class Initialized
INFO - 2022-11-11 14:26:37 --> Loader Class Initialized
INFO - 2022-11-11 14:26:37 --> Helper loaded: url_helper
INFO - 2022-11-11 14:26:37 --> Controller Class Initialized
INFO - 2022-11-11 14:26:37 --> Final output sent to browser
DEBUG - 2022-11-11 14:26:37 --> Total execution time: 0.0250
INFO - 2022-11-11 14:27:12 --> Config Class Initialized
INFO - 2022-11-11 14:27:12 --> Hooks Class Initialized
DEBUG - 2022-11-11 14:27:12 --> UTF-8 Support Enabled
INFO - 2022-11-11 14:27:12 --> Utf8 Class Initialized
INFO - 2022-11-11 14:27:12 --> URI Class Initialized
INFO - 2022-11-11 14:27:12 --> Router Class Initialized
INFO - 2022-11-11 14:27:12 --> Output Class Initialized
INFO - 2022-11-11 14:27:12 --> Security Class Initialized
DEBUG - 2022-11-11 14:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-11 14:27:12 --> Input Class Initialized
INFO - 2022-11-11 14:27:12 --> Language Class Initialized
INFO - 2022-11-11 14:27:12 --> Loader Class Initialized
INFO - 2022-11-11 14:27:12 --> Helper loaded: url_helper
INFO - 2022-11-11 14:27:12 --> Controller Class Initialized
INFO - 2022-11-11 14:27:12 --> Final output sent to browser
DEBUG - 2022-11-11 14:27:12 --> Total execution time: 0.0175
INFO - 2022-11-11 14:27:13 --> Config Class Initialized
INFO - 2022-11-11 14:27:13 --> Hooks Class Initialized
DEBUG - 2022-11-11 14:27:13 --> UTF-8 Support Enabled
INFO - 2022-11-11 14:27:13 --> Utf8 Class Initialized
INFO - 2022-11-11 14:27:13 --> URI Class Initialized
INFO - 2022-11-11 14:27:13 --> Router Class Initialized
INFO - 2022-11-11 14:27:13 --> Output Class Initialized
INFO - 2022-11-11 14:27:13 --> Security Class Initialized
DEBUG - 2022-11-11 14:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-11 14:27:13 --> Input Class Initialized
INFO - 2022-11-11 14:27:13 --> Language Class Initialized
INFO - 2022-11-11 14:27:13 --> Loader Class Initialized
INFO - 2022-11-11 14:27:13 --> Helper loaded: url_helper
INFO - 2022-11-11 14:27:13 --> Controller Class Initialized
INFO - 2022-11-11 14:27:13 --> Final output sent to browser
DEBUG - 2022-11-11 14:27:13 --> Total execution time: 0.0212
INFO - 2022-11-11 14:27:16 --> Config Class Initialized
INFO - 2022-11-11 14:27:16 --> Hooks Class Initialized
DEBUG - 2022-11-11 14:27:16 --> UTF-8 Support Enabled
INFO - 2022-11-11 14:27:16 --> Utf8 Class Initialized
INFO - 2022-11-11 14:27:16 --> URI Class Initialized
INFO - 2022-11-11 14:27:16 --> Router Class Initialized
INFO - 2022-11-11 14:27:16 --> Output Class Initialized
INFO - 2022-11-11 14:27:16 --> Security Class Initialized
DEBUG - 2022-11-11 14:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-11 14:27:16 --> Input Class Initialized
INFO - 2022-11-11 14:27:16 --> Language Class Initialized
INFO - 2022-11-11 14:27:16 --> Loader Class Initialized
INFO - 2022-11-11 14:27:16 --> Helper loaded: url_helper
INFO - 2022-11-11 14:27:16 --> Controller Class Initialized
INFO - 2022-11-11 14:27:16 --> Final output sent to browser
DEBUG - 2022-11-11 14:27:16 --> Total execution time: 0.0223
INFO - 2022-11-11 14:28:06 --> Config Class Initialized
INFO - 2022-11-11 14:28:06 --> Hooks Class Initialized
DEBUG - 2022-11-11 14:28:06 --> UTF-8 Support Enabled
INFO - 2022-11-11 14:28:06 --> Utf8 Class Initialized
INFO - 2022-11-11 14:28:06 --> URI Class Initialized
INFO - 2022-11-11 14:28:06 --> Router Class Initialized
INFO - 2022-11-11 14:28:06 --> Output Class Initialized
INFO - 2022-11-11 14:28:06 --> Security Class Initialized
DEBUG - 2022-11-11 14:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-11 14:28:06 --> Input Class Initialized
INFO - 2022-11-11 14:28:06 --> Language Class Initialized
INFO - 2022-11-11 14:28:06 --> Loader Class Initialized
INFO - 2022-11-11 14:28:06 --> Helper loaded: url_helper
INFO - 2022-11-11 14:28:06 --> Controller Class Initialized
INFO - 2022-11-11 14:28:06 --> Final output sent to browser
DEBUG - 2022-11-11 14:28:06 --> Total execution time: 0.0266
