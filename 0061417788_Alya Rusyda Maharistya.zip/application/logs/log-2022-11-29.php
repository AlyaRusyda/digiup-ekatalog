<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-11-29 08:27:05 --> Config Class Initialized
INFO - 2022-11-29 08:27:05 --> Hooks Class Initialized
DEBUG - 2022-11-29 08:27:05 --> UTF-8 Support Enabled
INFO - 2022-11-29 08:27:05 --> Utf8 Class Initialized
INFO - 2022-11-29 08:27:06 --> URI Class Initialized
DEBUG - 2022-11-29 08:27:06 --> No URI present. Default controller set.
INFO - 2022-11-29 08:27:06 --> Router Class Initialized
INFO - 2022-11-29 08:27:06 --> Output Class Initialized
INFO - 2022-11-29 08:27:06 --> Security Class Initialized
DEBUG - 2022-11-29 08:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 08:27:06 --> Input Class Initialized
INFO - 2022-11-29 08:27:06 --> Language Class Initialized
INFO - 2022-11-29 08:27:06 --> Loader Class Initialized
INFO - 2022-11-29 08:27:06 --> Helper loaded: url_helper
INFO - 2022-11-29 08:27:06 --> Controller Class Initialized
INFO - 2022-11-29 08:27:06 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-29 08:27:06 --> Final output sent to browser
DEBUG - 2022-11-29 08:27:06 --> Total execution time: 0.5181
INFO - 2022-11-29 08:53:04 --> Config Class Initialized
INFO - 2022-11-29 08:53:04 --> Hooks Class Initialized
DEBUG - 2022-11-29 08:53:04 --> UTF-8 Support Enabled
INFO - 2022-11-29 08:53:04 --> Utf8 Class Initialized
INFO - 2022-11-29 08:53:04 --> URI Class Initialized
INFO - 2022-11-29 08:53:04 --> Router Class Initialized
INFO - 2022-11-29 08:53:04 --> Output Class Initialized
INFO - 2022-11-29 08:53:04 --> Security Class Initialized
DEBUG - 2022-11-29 08:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 08:53:04 --> Input Class Initialized
INFO - 2022-11-29 08:53:04 --> Language Class Initialized
INFO - 2022-11-29 08:53:04 --> Loader Class Initialized
INFO - 2022-11-29 08:53:04 --> Helper loaded: url_helper
INFO - 2022-11-29 08:53:04 --> Database Driver Class Initialized
INFO - 2022-11-29 08:53:04 --> Helper loaded: form_helper
INFO - 2022-11-29 08:53:04 --> Form Validation Class Initialized
INFO - 2022-11-29 08:53:04 --> Controller Class Initialized
INFO - 2022-11-29 08:53:04 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 08:53:04 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 08:53:04 --> Final output sent to browser
DEBUG - 2022-11-29 08:53:04 --> Total execution time: 0.2557
INFO - 2022-11-29 08:57:34 --> Config Class Initialized
INFO - 2022-11-29 08:57:34 --> Hooks Class Initialized
DEBUG - 2022-11-29 08:57:34 --> UTF-8 Support Enabled
INFO - 2022-11-29 08:57:34 --> Utf8 Class Initialized
INFO - 2022-11-29 08:57:34 --> URI Class Initialized
INFO - 2022-11-29 08:57:34 --> Router Class Initialized
INFO - 2022-11-29 08:57:34 --> Output Class Initialized
INFO - 2022-11-29 08:57:34 --> Security Class Initialized
DEBUG - 2022-11-29 08:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 08:57:34 --> Input Class Initialized
INFO - 2022-11-29 08:57:34 --> Language Class Initialized
INFO - 2022-11-29 08:57:34 --> Loader Class Initialized
INFO - 2022-11-29 08:57:34 --> Helper loaded: url_helper
INFO - 2022-11-29 08:57:34 --> Database Driver Class Initialized
INFO - 2022-11-29 08:57:34 --> Helper loaded: form_helper
INFO - 2022-11-29 08:57:34 --> Form Validation Class Initialized
INFO - 2022-11-29 08:57:34 --> Controller Class Initialized
INFO - 2022-11-29 08:57:34 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 08:57:34 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 08:57:34 --> Final output sent to browser
DEBUG - 2022-11-29 08:57:34 --> Total execution time: 0.0520
INFO - 2022-11-29 08:57:36 --> Config Class Initialized
INFO - 2022-11-29 08:57:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 08:57:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 08:57:36 --> Utf8 Class Initialized
INFO - 2022-11-29 08:57:36 --> URI Class Initialized
INFO - 2022-11-29 08:57:36 --> Router Class Initialized
INFO - 2022-11-29 08:57:36 --> Output Class Initialized
INFO - 2022-11-29 08:57:36 --> Security Class Initialized
DEBUG - 2022-11-29 08:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 08:57:36 --> Input Class Initialized
INFO - 2022-11-29 08:57:36 --> Language Class Initialized
INFO - 2022-11-29 08:57:36 --> Loader Class Initialized
INFO - 2022-11-29 08:57:36 --> Helper loaded: url_helper
INFO - 2022-11-29 08:57:36 --> Database Driver Class Initialized
INFO - 2022-11-29 08:57:36 --> Helper loaded: form_helper
INFO - 2022-11-29 08:57:36 --> Form Validation Class Initialized
INFO - 2022-11-29 08:57:36 --> Controller Class Initialized
INFO - 2022-11-29 08:57:36 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 08:57:36 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-29 08:57:36 --> Final output sent to browser
DEBUG - 2022-11-29 08:57:36 --> Total execution time: 0.0604
INFO - 2022-11-29 08:57:55 --> Config Class Initialized
INFO - 2022-11-29 08:57:55 --> Hooks Class Initialized
DEBUG - 2022-11-29 08:57:55 --> UTF-8 Support Enabled
INFO - 2022-11-29 08:57:55 --> Utf8 Class Initialized
INFO - 2022-11-29 08:57:55 --> URI Class Initialized
INFO - 2022-11-29 08:57:55 --> Router Class Initialized
INFO - 2022-11-29 08:57:55 --> Output Class Initialized
INFO - 2022-11-29 08:57:55 --> Security Class Initialized
DEBUG - 2022-11-29 08:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 08:57:55 --> Input Class Initialized
INFO - 2022-11-29 08:57:55 --> Language Class Initialized
INFO - 2022-11-29 08:57:55 --> Loader Class Initialized
INFO - 2022-11-29 08:57:55 --> Helper loaded: url_helper
INFO - 2022-11-29 08:57:55 --> Database Driver Class Initialized
INFO - 2022-11-29 08:57:55 --> Helper loaded: form_helper
INFO - 2022-11-29 08:57:55 --> Form Validation Class Initialized
INFO - 2022-11-29 08:57:55 --> Controller Class Initialized
INFO - 2022-11-29 08:57:55 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 08:57:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-11-29 08:57:55 --> Config Class Initialized
INFO - 2022-11-29 08:57:55 --> Hooks Class Initialized
DEBUG - 2022-11-29 08:57:55 --> UTF-8 Support Enabled
INFO - 2022-11-29 08:57:55 --> Utf8 Class Initialized
INFO - 2022-11-29 08:57:55 --> URI Class Initialized
INFO - 2022-11-29 08:57:55 --> Router Class Initialized
INFO - 2022-11-29 08:57:55 --> Output Class Initialized
INFO - 2022-11-29 08:57:55 --> Security Class Initialized
DEBUG - 2022-11-29 08:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 08:57:55 --> Input Class Initialized
INFO - 2022-11-29 08:57:55 --> Language Class Initialized
INFO - 2022-11-29 08:57:55 --> Loader Class Initialized
INFO - 2022-11-29 08:57:55 --> Helper loaded: url_helper
INFO - 2022-11-29 08:57:55 --> Database Driver Class Initialized
INFO - 2022-11-29 08:57:55 --> Helper loaded: form_helper
INFO - 2022-11-29 08:57:55 --> Form Validation Class Initialized
INFO - 2022-11-29 08:57:55 --> Controller Class Initialized
INFO - 2022-11-29 08:57:55 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 08:57:55 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 08:57:55 --> Final output sent to browser
DEBUG - 2022-11-29 08:57:55 --> Total execution time: 0.0679
INFO - 2022-11-29 09:00:50 --> Config Class Initialized
INFO - 2022-11-29 09:00:50 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:00:50 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:00:50 --> Utf8 Class Initialized
INFO - 2022-11-29 09:00:50 --> URI Class Initialized
INFO - 2022-11-29 09:00:50 --> Router Class Initialized
INFO - 2022-11-29 09:00:50 --> Output Class Initialized
INFO - 2022-11-29 09:00:50 --> Security Class Initialized
DEBUG - 2022-11-29 09:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:00:50 --> Input Class Initialized
INFO - 2022-11-29 09:00:50 --> Language Class Initialized
INFO - 2022-11-29 09:00:50 --> Loader Class Initialized
INFO - 2022-11-29 09:00:50 --> Helper loaded: url_helper
INFO - 2022-11-29 09:00:50 --> Database Driver Class Initialized
ERROR - 2022-11-29 09:00:50 --> Severity: error --> Exception: Unknown database 'ekatalog' C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 201
INFO - 2022-11-29 09:01:09 --> Config Class Initialized
INFO - 2022-11-29 09:01:09 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:01:09 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:01:09 --> Utf8 Class Initialized
INFO - 2022-11-29 09:01:09 --> URI Class Initialized
DEBUG - 2022-11-29 09:01:09 --> No URI present. Default controller set.
INFO - 2022-11-29 09:01:09 --> Router Class Initialized
INFO - 2022-11-29 09:01:09 --> Output Class Initialized
INFO - 2022-11-29 09:01:09 --> Security Class Initialized
DEBUG - 2022-11-29 09:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:01:09 --> Input Class Initialized
INFO - 2022-11-29 09:01:09 --> Language Class Initialized
INFO - 2022-11-29 09:01:09 --> Loader Class Initialized
INFO - 2022-11-29 09:01:09 --> Helper loaded: url_helper
INFO - 2022-11-29 09:01:09 --> Database Driver Class Initialized
ERROR - 2022-11-29 09:01:09 --> Severity: error --> Exception: Unknown database 'ekatalog' C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 201
INFO - 2022-11-29 09:01:18 --> Config Class Initialized
INFO - 2022-11-29 09:01:18 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:01:18 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:01:18 --> Utf8 Class Initialized
INFO - 2022-11-29 09:01:18 --> URI Class Initialized
DEBUG - 2022-11-29 09:01:18 --> No URI present. Default controller set.
INFO - 2022-11-29 09:01:18 --> Router Class Initialized
INFO - 2022-11-29 09:01:18 --> Output Class Initialized
INFO - 2022-11-29 09:01:18 --> Security Class Initialized
DEBUG - 2022-11-29 09:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:01:18 --> Input Class Initialized
INFO - 2022-11-29 09:01:18 --> Language Class Initialized
INFO - 2022-11-29 09:01:18 --> Loader Class Initialized
INFO - 2022-11-29 09:01:18 --> Helper loaded: url_helper
INFO - 2022-11-29 09:01:18 --> Database Driver Class Initialized
ERROR - 2022-11-29 09:01:18 --> Severity: error --> Exception: Unknown database 'ekatalog' C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 201
INFO - 2022-11-29 09:01:18 --> Config Class Initialized
INFO - 2022-11-29 09:01:18 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:01:18 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:01:18 --> Utf8 Class Initialized
INFO - 2022-11-29 09:01:18 --> URI Class Initialized
DEBUG - 2022-11-29 09:01:18 --> No URI present. Default controller set.
INFO - 2022-11-29 09:01:18 --> Router Class Initialized
INFO - 2022-11-29 09:01:18 --> Output Class Initialized
INFO - 2022-11-29 09:01:18 --> Security Class Initialized
DEBUG - 2022-11-29 09:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:01:18 --> Input Class Initialized
INFO - 2022-11-29 09:01:18 --> Language Class Initialized
INFO - 2022-11-29 09:01:18 --> Loader Class Initialized
INFO - 2022-11-29 09:01:18 --> Helper loaded: url_helper
INFO - 2022-11-29 09:01:18 --> Database Driver Class Initialized
ERROR - 2022-11-29 09:01:18 --> Severity: error --> Exception: Unknown database 'ekatalog' C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 201
INFO - 2022-11-29 09:01:19 --> Config Class Initialized
INFO - 2022-11-29 09:01:19 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:01:19 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:01:19 --> Utf8 Class Initialized
INFO - 2022-11-29 09:01:19 --> URI Class Initialized
DEBUG - 2022-11-29 09:01:19 --> No URI present. Default controller set.
INFO - 2022-11-29 09:01:19 --> Router Class Initialized
INFO - 2022-11-29 09:01:19 --> Output Class Initialized
INFO - 2022-11-29 09:01:19 --> Security Class Initialized
DEBUG - 2022-11-29 09:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:01:19 --> Input Class Initialized
INFO - 2022-11-29 09:01:19 --> Language Class Initialized
INFO - 2022-11-29 09:01:19 --> Loader Class Initialized
INFO - 2022-11-29 09:01:19 --> Helper loaded: url_helper
INFO - 2022-11-29 09:01:19 --> Database Driver Class Initialized
ERROR - 2022-11-29 09:01:19 --> Severity: error --> Exception: Unknown database 'ekatalog' C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 201
INFO - 2022-11-29 09:02:01 --> Config Class Initialized
INFO - 2022-11-29 09:02:01 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:02:01 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:02:01 --> Utf8 Class Initialized
INFO - 2022-11-29 09:02:01 --> URI Class Initialized
DEBUG - 2022-11-29 09:02:01 --> No URI present. Default controller set.
INFO - 2022-11-29 09:02:01 --> Router Class Initialized
INFO - 2022-11-29 09:02:01 --> Output Class Initialized
INFO - 2022-11-29 09:02:01 --> Security Class Initialized
DEBUG - 2022-11-29 09:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:02:01 --> Input Class Initialized
INFO - 2022-11-29 09:02:01 --> Language Class Initialized
INFO - 2022-11-29 09:02:01 --> Loader Class Initialized
INFO - 2022-11-29 09:02:01 --> Helper loaded: url_helper
INFO - 2022-11-29 09:02:01 --> Database Driver Class Initialized
INFO - 2022-11-29 09:02:01 --> Helper loaded: form_helper
INFO - 2022-11-29 09:02:01 --> Form Validation Class Initialized
INFO - 2022-11-29 09:02:01 --> Controller Class Initialized
INFO - 2022-11-29 09:02:01 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-29 09:02:01 --> Final output sent to browser
DEBUG - 2022-11-29 09:02:01 --> Total execution time: 0.0639
INFO - 2022-11-29 09:06:49 --> Config Class Initialized
INFO - 2022-11-29 09:06:49 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:06:49 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:06:49 --> Utf8 Class Initialized
INFO - 2022-11-29 09:06:49 --> URI Class Initialized
DEBUG - 2022-11-29 09:06:49 --> No URI present. Default controller set.
INFO - 2022-11-29 09:06:49 --> Router Class Initialized
INFO - 2022-11-29 09:06:49 --> Output Class Initialized
INFO - 2022-11-29 09:06:49 --> Security Class Initialized
DEBUG - 2022-11-29 09:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:06:49 --> Input Class Initialized
INFO - 2022-11-29 09:06:49 --> Language Class Initialized
INFO - 2022-11-29 09:06:49 --> Loader Class Initialized
INFO - 2022-11-29 09:06:49 --> Helper loaded: url_helper
INFO - 2022-11-29 09:06:49 --> Database Driver Class Initialized
INFO - 2022-11-29 09:06:49 --> Helper loaded: form_helper
INFO - 2022-11-29 09:06:49 --> Form Validation Class Initialized
INFO - 2022-11-29 09:06:49 --> Controller Class Initialized
INFO - 2022-11-29 09:06:49 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-29 09:06:49 --> Final output sent to browser
DEBUG - 2022-11-29 09:06:49 --> Total execution time: 0.0355
INFO - 2022-11-29 09:06:55 --> Config Class Initialized
INFO - 2022-11-29 09:06:55 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:06:55 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:06:55 --> Utf8 Class Initialized
INFO - 2022-11-29 09:06:55 --> URI Class Initialized
INFO - 2022-11-29 09:06:55 --> Router Class Initialized
INFO - 2022-11-29 09:06:55 --> Output Class Initialized
INFO - 2022-11-29 09:06:55 --> Security Class Initialized
DEBUG - 2022-11-29 09:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:06:55 --> Input Class Initialized
INFO - 2022-11-29 09:06:55 --> Language Class Initialized
INFO - 2022-11-29 09:06:55 --> Loader Class Initialized
INFO - 2022-11-29 09:06:55 --> Helper loaded: url_helper
INFO - 2022-11-29 09:06:55 --> Database Driver Class Initialized
INFO - 2022-11-29 09:06:55 --> Helper loaded: form_helper
INFO - 2022-11-29 09:06:55 --> Form Validation Class Initialized
INFO - 2022-11-29 09:06:55 --> Controller Class Initialized
INFO - 2022-11-29 09:06:55 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 09:06:55 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 09:06:55 --> Final output sent to browser
DEBUG - 2022-11-29 09:06:55 --> Total execution time: 0.0624
INFO - 2022-11-29 09:06:57 --> Config Class Initialized
INFO - 2022-11-29 09:06:57 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:06:57 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:06:57 --> Utf8 Class Initialized
INFO - 2022-11-29 09:06:57 --> URI Class Initialized
INFO - 2022-11-29 09:06:57 --> Router Class Initialized
INFO - 2022-11-29 09:06:57 --> Output Class Initialized
INFO - 2022-11-29 09:06:57 --> Security Class Initialized
DEBUG - 2022-11-29 09:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:06:57 --> Input Class Initialized
INFO - 2022-11-29 09:06:57 --> Language Class Initialized
INFO - 2022-11-29 09:06:57 --> Loader Class Initialized
INFO - 2022-11-29 09:06:57 --> Helper loaded: url_helper
INFO - 2022-11-29 09:06:57 --> Database Driver Class Initialized
INFO - 2022-11-29 09:06:57 --> Helper loaded: form_helper
INFO - 2022-11-29 09:06:57 --> Form Validation Class Initialized
INFO - 2022-11-29 09:06:57 --> Controller Class Initialized
INFO - 2022-11-29 09:06:57 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 09:06:57 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-29 09:06:57 --> Final output sent to browser
DEBUG - 2022-11-29 09:06:57 --> Total execution time: 0.0506
INFO - 2022-11-29 09:07:01 --> Config Class Initialized
INFO - 2022-11-29 09:07:01 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:07:01 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:07:01 --> Utf8 Class Initialized
INFO - 2022-11-29 09:07:01 --> URI Class Initialized
INFO - 2022-11-29 09:07:01 --> Router Class Initialized
INFO - 2022-11-29 09:07:01 --> Output Class Initialized
INFO - 2022-11-29 09:07:01 --> Security Class Initialized
DEBUG - 2022-11-29 09:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:07:01 --> Input Class Initialized
INFO - 2022-11-29 09:07:01 --> Language Class Initialized
INFO - 2022-11-29 09:07:01 --> Loader Class Initialized
INFO - 2022-11-29 09:07:01 --> Helper loaded: url_helper
INFO - 2022-11-29 09:07:01 --> Database Driver Class Initialized
INFO - 2022-11-29 09:07:01 --> Helper loaded: form_helper
INFO - 2022-11-29 09:07:01 --> Form Validation Class Initialized
INFO - 2022-11-29 09:07:01 --> Controller Class Initialized
INFO - 2022-11-29 09:07:01 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 09:07:01 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-29 09:07:01 --> Final output sent to browser
DEBUG - 2022-11-29 09:07:01 --> Total execution time: 0.0470
INFO - 2022-11-29 09:07:13 --> Config Class Initialized
INFO - 2022-11-29 09:07:13 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:07:13 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:07:13 --> Utf8 Class Initialized
INFO - 2022-11-29 09:07:13 --> URI Class Initialized
INFO - 2022-11-29 09:07:13 --> Router Class Initialized
INFO - 2022-11-29 09:07:13 --> Output Class Initialized
INFO - 2022-11-29 09:07:13 --> Security Class Initialized
DEBUG - 2022-11-29 09:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:07:13 --> Input Class Initialized
INFO - 2022-11-29 09:07:13 --> Language Class Initialized
INFO - 2022-11-29 09:07:13 --> Loader Class Initialized
INFO - 2022-11-29 09:07:13 --> Helper loaded: url_helper
INFO - 2022-11-29 09:07:13 --> Database Driver Class Initialized
INFO - 2022-11-29 09:07:13 --> Helper loaded: form_helper
INFO - 2022-11-29 09:07:13 --> Form Validation Class Initialized
INFO - 2022-11-29 09:07:13 --> Controller Class Initialized
INFO - 2022-11-29 09:07:13 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 09:07:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-11-29 09:07:13 --> Config Class Initialized
INFO - 2022-11-29 09:07:13 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:07:13 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:07:13 --> Utf8 Class Initialized
INFO - 2022-11-29 09:07:13 --> URI Class Initialized
INFO - 2022-11-29 09:07:13 --> Router Class Initialized
INFO - 2022-11-29 09:07:13 --> Output Class Initialized
INFO - 2022-11-29 09:07:13 --> Security Class Initialized
DEBUG - 2022-11-29 09:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:07:13 --> Input Class Initialized
INFO - 2022-11-29 09:07:13 --> Language Class Initialized
INFO - 2022-11-29 09:07:13 --> Loader Class Initialized
INFO - 2022-11-29 09:07:13 --> Helper loaded: url_helper
INFO - 2022-11-29 09:07:13 --> Database Driver Class Initialized
INFO - 2022-11-29 09:07:13 --> Helper loaded: form_helper
INFO - 2022-11-29 09:07:13 --> Form Validation Class Initialized
INFO - 2022-11-29 09:07:13 --> Controller Class Initialized
INFO - 2022-11-29 09:07:13 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 09:07:13 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 09:07:13 --> Final output sent to browser
DEBUG - 2022-11-29 09:07:13 --> Total execution time: 0.0367
INFO - 2022-11-29 09:07:26 --> Config Class Initialized
INFO - 2022-11-29 09:07:26 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:07:26 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:07:26 --> Utf8 Class Initialized
INFO - 2022-11-29 09:07:26 --> URI Class Initialized
INFO - 2022-11-29 09:07:26 --> Router Class Initialized
INFO - 2022-11-29 09:07:26 --> Output Class Initialized
INFO - 2022-11-29 09:07:26 --> Security Class Initialized
DEBUG - 2022-11-29 09:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:07:26 --> Input Class Initialized
INFO - 2022-11-29 09:07:26 --> Language Class Initialized
INFO - 2022-11-29 09:07:26 --> Loader Class Initialized
INFO - 2022-11-29 09:07:26 --> Helper loaded: url_helper
INFO - 2022-11-29 09:07:26 --> Database Driver Class Initialized
INFO - 2022-11-29 09:07:26 --> Helper loaded: form_helper
INFO - 2022-11-29 09:07:26 --> Form Validation Class Initialized
INFO - 2022-11-29 09:07:26 --> Controller Class Initialized
INFO - 2022-11-29 09:07:26 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 09:07:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 09:07:26 --> Final output sent to browser
DEBUG - 2022-11-29 09:07:26 --> Total execution time: 0.0568
INFO - 2022-11-29 09:07:28 --> Config Class Initialized
INFO - 2022-11-29 09:07:28 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:07:28 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:07:28 --> Utf8 Class Initialized
INFO - 2022-11-29 09:07:28 --> URI Class Initialized
INFO - 2022-11-29 09:07:28 --> Router Class Initialized
INFO - 2022-11-29 09:07:28 --> Output Class Initialized
INFO - 2022-11-29 09:07:28 --> Security Class Initialized
DEBUG - 2022-11-29 09:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:07:28 --> Input Class Initialized
INFO - 2022-11-29 09:07:28 --> Language Class Initialized
INFO - 2022-11-29 09:07:28 --> Loader Class Initialized
INFO - 2022-11-29 09:07:28 --> Helper loaded: url_helper
INFO - 2022-11-29 09:07:28 --> Database Driver Class Initialized
INFO - 2022-11-29 09:07:28 --> Helper loaded: form_helper
INFO - 2022-11-29 09:07:28 --> Form Validation Class Initialized
INFO - 2022-11-29 09:07:28 --> Controller Class Initialized
INFO - 2022-11-29 09:07:28 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 09:07:28 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 09:07:28 --> Final output sent to browser
DEBUG - 2022-11-29 09:07:28 --> Total execution time: 0.0387
INFO - 2022-11-29 09:07:36 --> Config Class Initialized
INFO - 2022-11-29 09:07:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:07:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:07:36 --> Utf8 Class Initialized
INFO - 2022-11-29 09:07:36 --> URI Class Initialized
INFO - 2022-11-29 09:07:36 --> Router Class Initialized
INFO - 2022-11-29 09:07:36 --> Output Class Initialized
INFO - 2022-11-29 09:07:36 --> Security Class Initialized
DEBUG - 2022-11-29 09:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:07:36 --> Input Class Initialized
INFO - 2022-11-29 09:07:36 --> Language Class Initialized
INFO - 2022-11-29 09:07:36 --> Loader Class Initialized
INFO - 2022-11-29 09:07:36 --> Helper loaded: url_helper
INFO - 2022-11-29 09:07:36 --> Database Driver Class Initialized
INFO - 2022-11-29 09:07:36 --> Helper loaded: form_helper
INFO - 2022-11-29 09:07:36 --> Form Validation Class Initialized
INFO - 2022-11-29 09:07:36 --> Controller Class Initialized
INFO - 2022-11-29 09:07:36 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 09:07:36 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 09:07:36 --> Final output sent to browser
DEBUG - 2022-11-29 09:07:36 --> Total execution time: 0.0569
INFO - 2022-11-29 09:32:21 --> Config Class Initialized
INFO - 2022-11-29 09:32:21 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:32:21 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:32:21 --> Utf8 Class Initialized
INFO - 2022-11-29 09:32:21 --> URI Class Initialized
INFO - 2022-11-29 09:32:21 --> Router Class Initialized
INFO - 2022-11-29 09:32:21 --> Output Class Initialized
INFO - 2022-11-29 09:32:21 --> Security Class Initialized
DEBUG - 2022-11-29 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:32:21 --> Input Class Initialized
INFO - 2022-11-29 09:32:21 --> Language Class Initialized
INFO - 2022-11-29 09:32:21 --> Loader Class Initialized
INFO - 2022-11-29 09:32:21 --> Helper loaded: url_helper
INFO - 2022-11-29 09:32:21 --> Database Driver Class Initialized
INFO - 2022-11-29 09:32:21 --> Helper loaded: form_helper
INFO - 2022-11-29 09:32:21 --> Form Validation Class Initialized
INFO - 2022-11-29 09:32:21 --> Controller Class Initialized
ERROR - 2022-11-29 09:32:21 --> Severity: error --> Exception: C:\xampp\htdocs\ekatalog\application\models/Buku_model.php exists, but doesn't declare class Buku_model C:\xampp\htdocs\ekatalog\system\core\Loader.php 340
INFO - 2022-11-29 09:32:37 --> Config Class Initialized
INFO - 2022-11-29 09:32:37 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:32:37 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:32:37 --> Utf8 Class Initialized
INFO - 2022-11-29 09:32:37 --> URI Class Initialized
INFO - 2022-11-29 09:32:37 --> Router Class Initialized
INFO - 2022-11-29 09:32:37 --> Output Class Initialized
INFO - 2022-11-29 09:32:37 --> Security Class Initialized
DEBUG - 2022-11-29 09:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:32:37 --> Input Class Initialized
INFO - 2022-11-29 09:32:37 --> Language Class Initialized
INFO - 2022-11-29 09:32:37 --> Loader Class Initialized
INFO - 2022-11-29 09:32:37 --> Helper loaded: url_helper
INFO - 2022-11-29 09:32:37 --> Database Driver Class Initialized
INFO - 2022-11-29 09:32:37 --> Helper loaded: form_helper
INFO - 2022-11-29 09:32:37 --> Form Validation Class Initialized
INFO - 2022-11-29 09:32:37 --> Controller Class Initialized
INFO - 2022-11-29 09:32:37 --> Model "Buku_model" initialized
ERROR - 2022-11-29 09:32:37 --> Severity: Warning --> Undefined array key "isbn" C:\xampp\htdocs\ekatalog\application\views\buku\index.php 24
ERROR - 2022-11-29 09:32:37 --> Severity: Warning --> Undefined array key "judul" C:\xampp\htdocs\ekatalog\application\views\buku\index.php 25
ERROR - 2022-11-29 09:32:37 --> Severity: Warning --> Undefined array key "pengarang" C:\xampp\htdocs\ekatalog\application\views\buku\index.php 26
ERROR - 2022-11-29 09:32:37 --> Severity: Warning --> Undefined array key "tanggal_rilis" C:\xampp\htdocs\ekatalog\application\views\buku\index.php 27
ERROR - 2022-11-29 09:32:37 --> Severity: Warning --> Undefined array key "jumlah_halaman" C:\xampp\htdocs\ekatalog\application\views\buku\index.php 28
ERROR - 2022-11-29 09:32:37 --> Severity: Warning --> Undefined array key "sinopsis" C:\xampp\htdocs\ekatalog\application\views\buku\index.php 29
ERROR - 2022-11-29 09:32:37 --> Severity: Warning --> Undefined array key "id_penerbit" C:\xampp\htdocs\ekatalog\application\views\buku\index.php 30
ERROR - 2022-11-29 09:32:37 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\views\buku\index.php 31
ERROR - 2022-11-29 09:32:37 --> Severity: Warning --> Undefined array key "tersedia" C:\xampp\htdocs\ekatalog\application\views\buku\index.php 32
INFO - 2022-11-29 09:32:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 09:32:37 --> Final output sent to browser
DEBUG - 2022-11-29 09:32:37 --> Total execution time: 0.0820
INFO - 2022-11-29 09:32:43 --> Config Class Initialized
INFO - 2022-11-29 09:32:43 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:32:43 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:32:43 --> Utf8 Class Initialized
INFO - 2022-11-29 09:32:43 --> URI Class Initialized
INFO - 2022-11-29 09:32:43 --> Router Class Initialized
INFO - 2022-11-29 09:32:43 --> Output Class Initialized
INFO - 2022-11-29 09:32:43 --> Security Class Initialized
DEBUG - 2022-11-29 09:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:32:43 --> Input Class Initialized
INFO - 2022-11-29 09:32:43 --> Language Class Initialized
INFO - 2022-11-29 09:32:43 --> Loader Class Initialized
INFO - 2022-11-29 09:32:43 --> Helper loaded: url_helper
INFO - 2022-11-29 09:32:43 --> Database Driver Class Initialized
INFO - 2022-11-29 09:32:43 --> Helper loaded: form_helper
INFO - 2022-11-29 09:32:43 --> Form Validation Class Initialized
INFO - 2022-11-29 09:32:43 --> Controller Class Initialized
INFO - 2022-11-29 09:32:43 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:32:43 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 09:32:43 --> Final output sent to browser
DEBUG - 2022-11-29 09:32:43 --> Total execution time: 0.0684
INFO - 2022-11-29 09:32:57 --> Config Class Initialized
INFO - 2022-11-29 09:32:57 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:32:57 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:32:57 --> Utf8 Class Initialized
INFO - 2022-11-29 09:32:57 --> URI Class Initialized
INFO - 2022-11-29 09:32:57 --> Router Class Initialized
INFO - 2022-11-29 09:32:57 --> Output Class Initialized
INFO - 2022-11-29 09:32:57 --> Security Class Initialized
DEBUG - 2022-11-29 09:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:32:57 --> Input Class Initialized
INFO - 2022-11-29 09:32:57 --> Language Class Initialized
INFO - 2022-11-29 09:32:57 --> Loader Class Initialized
INFO - 2022-11-29 09:32:57 --> Helper loaded: url_helper
INFO - 2022-11-29 09:32:57 --> Database Driver Class Initialized
INFO - 2022-11-29 09:32:57 --> Helper loaded: form_helper
INFO - 2022-11-29 09:32:57 --> Form Validation Class Initialized
INFO - 2022-11-29 09:32:57 --> Controller Class Initialized
ERROR - 2022-11-29 09:32:57 --> Severity: error --> Exception: C:\xampp\htdocs\ekatalog\application\models/Penerbit_model.php exists, but doesn't declare class Penerbit_model C:\xampp\htdocs\ekatalog\system\core\Loader.php 340
INFO - 2022-11-29 09:33:24 --> Config Class Initialized
INFO - 2022-11-29 09:33:24 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:33:24 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:33:24 --> Utf8 Class Initialized
INFO - 2022-11-29 09:33:24 --> URI Class Initialized
INFO - 2022-11-29 09:33:24 --> Router Class Initialized
INFO - 2022-11-29 09:33:24 --> Output Class Initialized
INFO - 2022-11-29 09:33:24 --> Security Class Initialized
DEBUG - 2022-11-29 09:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:33:24 --> Input Class Initialized
INFO - 2022-11-29 09:33:24 --> Language Class Initialized
INFO - 2022-11-29 09:33:24 --> Loader Class Initialized
INFO - 2022-11-29 09:33:24 --> Helper loaded: url_helper
INFO - 2022-11-29 09:33:24 --> Database Driver Class Initialized
INFO - 2022-11-29 09:33:24 --> Helper loaded: form_helper
INFO - 2022-11-29 09:33:24 --> Form Validation Class Initialized
INFO - 2022-11-29 09:33:24 --> Controller Class Initialized
INFO - 2022-11-29 09:33:24 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 09:33:24 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 09:33:24 --> Final output sent to browser
DEBUG - 2022-11-29 09:33:24 --> Total execution time: 0.0551
INFO - 2022-11-29 09:33:26 --> Config Class Initialized
INFO - 2022-11-29 09:33:26 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:33:26 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:33:26 --> Utf8 Class Initialized
INFO - 2022-11-29 09:33:26 --> URI Class Initialized
INFO - 2022-11-29 09:33:26 --> Router Class Initialized
INFO - 2022-11-29 09:33:26 --> Output Class Initialized
INFO - 2022-11-29 09:33:26 --> Security Class Initialized
DEBUG - 2022-11-29 09:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:33:26 --> Input Class Initialized
INFO - 2022-11-29 09:33:26 --> Language Class Initialized
INFO - 2022-11-29 09:33:26 --> Loader Class Initialized
INFO - 2022-11-29 09:33:26 --> Helper loaded: url_helper
INFO - 2022-11-29 09:33:26 --> Database Driver Class Initialized
INFO - 2022-11-29 09:33:26 --> Helper loaded: form_helper
INFO - 2022-11-29 09:33:26 --> Form Validation Class Initialized
INFO - 2022-11-29 09:33:26 --> Controller Class Initialized
INFO - 2022-11-29 09:33:26 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:33:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 09:33:26 --> Final output sent to browser
DEBUG - 2022-11-29 09:33:26 --> Total execution time: 0.0515
INFO - 2022-11-29 09:33:27 --> Config Class Initialized
INFO - 2022-11-29 09:33:27 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:33:27 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:33:27 --> Utf8 Class Initialized
INFO - 2022-11-29 09:33:27 --> URI Class Initialized
INFO - 2022-11-29 09:33:27 --> Router Class Initialized
INFO - 2022-11-29 09:33:27 --> Output Class Initialized
INFO - 2022-11-29 09:33:27 --> Security Class Initialized
DEBUG - 2022-11-29 09:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:33:27 --> Input Class Initialized
INFO - 2022-11-29 09:33:27 --> Language Class Initialized
INFO - 2022-11-29 09:33:27 --> Loader Class Initialized
INFO - 2022-11-29 09:33:27 --> Helper loaded: url_helper
INFO - 2022-11-29 09:33:27 --> Database Driver Class Initialized
INFO - 2022-11-29 09:33:27 --> Helper loaded: form_helper
INFO - 2022-11-29 09:33:27 --> Form Validation Class Initialized
INFO - 2022-11-29 09:33:27 --> Controller Class Initialized
INFO - 2022-11-29 09:33:27 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 09:33:27 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 09:33:27 --> Final output sent to browser
DEBUG - 2022-11-29 09:33:27 --> Total execution time: 0.0648
INFO - 2022-11-29 09:33:28 --> Config Class Initialized
INFO - 2022-11-29 09:33:28 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:33:28 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:33:28 --> Utf8 Class Initialized
INFO - 2022-11-29 09:33:28 --> URI Class Initialized
INFO - 2022-11-29 09:33:28 --> Router Class Initialized
INFO - 2022-11-29 09:33:28 --> Output Class Initialized
INFO - 2022-11-29 09:33:28 --> Security Class Initialized
DEBUG - 2022-11-29 09:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:33:28 --> Input Class Initialized
INFO - 2022-11-29 09:33:28 --> Language Class Initialized
INFO - 2022-11-29 09:33:28 --> Loader Class Initialized
INFO - 2022-11-29 09:33:28 --> Helper loaded: url_helper
INFO - 2022-11-29 09:33:28 --> Database Driver Class Initialized
INFO - 2022-11-29 09:33:28 --> Helper loaded: form_helper
INFO - 2022-11-29 09:33:28 --> Form Validation Class Initialized
INFO - 2022-11-29 09:33:28 --> Controller Class Initialized
INFO - 2022-11-29 09:33:28 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:33:28 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 09:33:28 --> Final output sent to browser
DEBUG - 2022-11-29 09:33:28 --> Total execution time: 0.0789
INFO - 2022-11-29 09:34:59 --> Config Class Initialized
INFO - 2022-11-29 09:34:59 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:34:59 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:34:59 --> Utf8 Class Initialized
INFO - 2022-11-29 09:34:59 --> URI Class Initialized
INFO - 2022-11-29 09:34:59 --> Router Class Initialized
INFO - 2022-11-29 09:34:59 --> Output Class Initialized
INFO - 2022-11-29 09:34:59 --> Security Class Initialized
DEBUG - 2022-11-29 09:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:34:59 --> Input Class Initialized
INFO - 2022-11-29 09:34:59 --> Language Class Initialized
INFO - 2022-11-29 09:34:59 --> Loader Class Initialized
INFO - 2022-11-29 09:34:59 --> Helper loaded: url_helper
INFO - 2022-11-29 09:34:59 --> Database Driver Class Initialized
INFO - 2022-11-29 09:34:59 --> Helper loaded: form_helper
INFO - 2022-11-29 09:34:59 --> Form Validation Class Initialized
INFO - 2022-11-29 09:34:59 --> Controller Class Initialized
INFO - 2022-11-29 09:34:59 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 09:34:59 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 09:34:59 --> Final output sent to browser
DEBUG - 2022-11-29 09:34:59 --> Total execution time: 0.0622
INFO - 2022-11-29 09:35:01 --> Config Class Initialized
INFO - 2022-11-29 09:35:01 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:35:01 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:35:01 --> Utf8 Class Initialized
INFO - 2022-11-29 09:35:01 --> URI Class Initialized
INFO - 2022-11-29 09:35:01 --> Router Class Initialized
INFO - 2022-11-29 09:35:01 --> Output Class Initialized
INFO - 2022-11-29 09:35:01 --> Security Class Initialized
DEBUG - 2022-11-29 09:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:35:01 --> Input Class Initialized
INFO - 2022-11-29 09:35:01 --> Language Class Initialized
INFO - 2022-11-29 09:35:01 --> Loader Class Initialized
INFO - 2022-11-29 09:35:01 --> Helper loaded: url_helper
INFO - 2022-11-29 09:35:01 --> Database Driver Class Initialized
INFO - 2022-11-29 09:35:01 --> Helper loaded: form_helper
INFO - 2022-11-29 09:35:01 --> Form Validation Class Initialized
INFO - 2022-11-29 09:35:01 --> Controller Class Initialized
INFO - 2022-11-29 09:35:01 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 09:35:01 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-29 09:35:01 --> Final output sent to browser
DEBUG - 2022-11-29 09:35:01 --> Total execution time: 0.0904
INFO - 2022-11-29 09:38:13 --> Config Class Initialized
INFO - 2022-11-29 09:38:13 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:38:13 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:38:13 --> Utf8 Class Initialized
INFO - 2022-11-29 09:38:13 --> URI Class Initialized
INFO - 2022-11-29 09:38:13 --> Router Class Initialized
INFO - 2022-11-29 09:38:13 --> Output Class Initialized
INFO - 2022-11-29 09:38:13 --> Security Class Initialized
DEBUG - 2022-11-29 09:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:38:13 --> Input Class Initialized
INFO - 2022-11-29 09:38:13 --> Language Class Initialized
INFO - 2022-11-29 09:38:13 --> Loader Class Initialized
INFO - 2022-11-29 09:38:13 --> Helper loaded: url_helper
INFO - 2022-11-29 09:38:13 --> Database Driver Class Initialized
INFO - 2022-11-29 09:38:13 --> Helper loaded: form_helper
INFO - 2022-11-29 09:38:13 --> Form Validation Class Initialized
INFO - 2022-11-29 09:38:13 --> Controller Class Initialized
INFO - 2022-11-29 09:38:13 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:38:13 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 09:38:13 --> Final output sent to browser
DEBUG - 2022-11-29 09:38:13 --> Total execution time: 0.0569
INFO - 2022-11-29 09:38:14 --> Config Class Initialized
INFO - 2022-11-29 09:38:14 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:38:14 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:38:14 --> Utf8 Class Initialized
INFO - 2022-11-29 09:38:14 --> URI Class Initialized
INFO - 2022-11-29 09:38:14 --> Router Class Initialized
INFO - 2022-11-29 09:38:14 --> Output Class Initialized
INFO - 2022-11-29 09:38:14 --> Security Class Initialized
DEBUG - 2022-11-29 09:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:38:14 --> Input Class Initialized
INFO - 2022-11-29 09:38:14 --> Language Class Initialized
INFO - 2022-11-29 09:38:14 --> Loader Class Initialized
INFO - 2022-11-29 09:38:14 --> Helper loaded: url_helper
INFO - 2022-11-29 09:38:14 --> Database Driver Class Initialized
INFO - 2022-11-29 09:38:14 --> Helper loaded: form_helper
INFO - 2022-11-29 09:38:14 --> Form Validation Class Initialized
INFO - 2022-11-29 09:38:14 --> Controller Class Initialized
INFO - 2022-11-29 09:38:14 --> Model "Buku_model" initialized
ERROR - 2022-11-29 09:38:14 --> Severity: Warning --> Undefined variable $tanggal_rilis C:\xampp\htdocs\ekatalog\application\views\buku\form.php 40
INFO - 2022-11-29 09:38:14 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 09:38:14 --> Final output sent to browser
DEBUG - 2022-11-29 09:38:14 --> Total execution time: 0.0489
INFO - 2022-11-29 09:39:45 --> Config Class Initialized
INFO - 2022-11-29 09:39:45 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:39:45 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:39:45 --> Utf8 Class Initialized
INFO - 2022-11-29 09:39:45 --> URI Class Initialized
INFO - 2022-11-29 09:39:45 --> Router Class Initialized
INFO - 2022-11-29 09:39:45 --> Output Class Initialized
INFO - 2022-11-29 09:39:45 --> Security Class Initialized
DEBUG - 2022-11-29 09:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:39:45 --> Input Class Initialized
INFO - 2022-11-29 09:39:45 --> Language Class Initialized
INFO - 2022-11-29 09:39:45 --> Loader Class Initialized
INFO - 2022-11-29 09:39:45 --> Helper loaded: url_helper
INFO - 2022-11-29 09:39:45 --> Database Driver Class Initialized
INFO - 2022-11-29 09:39:45 --> Helper loaded: form_helper
INFO - 2022-11-29 09:39:45 --> Form Validation Class Initialized
INFO - 2022-11-29 09:39:45 --> Controller Class Initialized
INFO - 2022-11-29 09:39:45 --> Model "Buku_model" initialized
ERROR - 2022-11-29 09:39:45 --> Severity: Warning --> Undefined variable $rilis C:\xampp\htdocs\ekatalog\application\views\buku\form.php 40
INFO - 2022-11-29 09:39:45 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 09:39:45 --> Final output sent to browser
DEBUG - 2022-11-29 09:39:45 --> Total execution time: 0.0731
INFO - 2022-11-29 09:40:09 --> Config Class Initialized
INFO - 2022-11-29 09:40:09 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:40:09 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:40:09 --> Utf8 Class Initialized
INFO - 2022-11-29 09:40:09 --> URI Class Initialized
INFO - 2022-11-29 09:40:09 --> Router Class Initialized
INFO - 2022-11-29 09:40:09 --> Output Class Initialized
INFO - 2022-11-29 09:40:09 --> Security Class Initialized
DEBUG - 2022-11-29 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:40:09 --> Input Class Initialized
INFO - 2022-11-29 09:40:09 --> Language Class Initialized
INFO - 2022-11-29 09:40:09 --> Loader Class Initialized
INFO - 2022-11-29 09:40:09 --> Helper loaded: url_helper
INFO - 2022-11-29 09:40:09 --> Database Driver Class Initialized
INFO - 2022-11-29 09:40:09 --> Helper loaded: form_helper
INFO - 2022-11-29 09:40:09 --> Form Validation Class Initialized
INFO - 2022-11-29 09:40:09 --> Controller Class Initialized
INFO - 2022-11-29 09:40:09 --> Model "Buku_model" initialized
ERROR - 2022-11-29 09:40:09 --> Severity: Warning --> Undefined variable $tanggal_rilis C:\xampp\htdocs\ekatalog\application\views\buku\form.php 40
INFO - 2022-11-29 09:40:09 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 09:40:09 --> Final output sent to browser
DEBUG - 2022-11-29 09:40:09 --> Total execution time: 0.0601
INFO - 2022-11-29 09:40:29 --> Config Class Initialized
INFO - 2022-11-29 09:40:29 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:40:29 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:40:29 --> Utf8 Class Initialized
INFO - 2022-11-29 09:40:29 --> URI Class Initialized
INFO - 2022-11-29 09:40:29 --> Router Class Initialized
INFO - 2022-11-29 09:40:29 --> Output Class Initialized
INFO - 2022-11-29 09:40:29 --> Security Class Initialized
DEBUG - 2022-11-29 09:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:40:29 --> Input Class Initialized
INFO - 2022-11-29 09:40:29 --> Language Class Initialized
INFO - 2022-11-29 09:40:29 --> Loader Class Initialized
INFO - 2022-11-29 09:40:29 --> Helper loaded: url_helper
INFO - 2022-11-29 09:40:29 --> Database Driver Class Initialized
INFO - 2022-11-29 09:40:29 --> Helper loaded: form_helper
INFO - 2022-11-29 09:40:29 --> Form Validation Class Initialized
INFO - 2022-11-29 09:40:29 --> Controller Class Initialized
INFO - 2022-11-29 09:40:29 --> Model "Buku_model" initialized
ERROR - 2022-11-29 09:40:29 --> Severity: Warning --> Undefined variable $tanggal_rilis C:\xampp\htdocs\ekatalog\application\views\buku\form.php 40
INFO - 2022-11-29 09:40:29 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 09:40:29 --> Final output sent to browser
DEBUG - 2022-11-29 09:40:29 --> Total execution time: 0.0549
INFO - 2022-11-29 09:41:52 --> Config Class Initialized
INFO - 2022-11-29 09:41:52 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:41:52 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:41:52 --> Utf8 Class Initialized
INFO - 2022-11-29 09:41:52 --> URI Class Initialized
INFO - 2022-11-29 09:41:52 --> Router Class Initialized
INFO - 2022-11-29 09:41:52 --> Output Class Initialized
INFO - 2022-11-29 09:41:52 --> Security Class Initialized
DEBUG - 2022-11-29 09:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:41:52 --> Input Class Initialized
INFO - 2022-11-29 09:41:52 --> Language Class Initialized
INFO - 2022-11-29 09:41:52 --> Loader Class Initialized
INFO - 2022-11-29 09:41:52 --> Helper loaded: url_helper
INFO - 2022-11-29 09:41:52 --> Database Driver Class Initialized
INFO - 2022-11-29 09:41:52 --> Helper loaded: form_helper
INFO - 2022-11-29 09:41:52 --> Form Validation Class Initialized
INFO - 2022-11-29 09:41:52 --> Controller Class Initialized
INFO - 2022-11-29 09:41:52 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:41:52 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 09:41:52 --> Final output sent to browser
DEBUG - 2022-11-29 09:41:52 --> Total execution time: 0.0586
INFO - 2022-11-29 09:42:18 --> Config Class Initialized
INFO - 2022-11-29 09:42:18 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:42:18 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:42:18 --> Utf8 Class Initialized
INFO - 2022-11-29 09:42:18 --> URI Class Initialized
INFO - 2022-11-29 09:42:18 --> Router Class Initialized
INFO - 2022-11-29 09:42:18 --> Output Class Initialized
INFO - 2022-11-29 09:42:18 --> Security Class Initialized
DEBUG - 2022-11-29 09:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:42:18 --> Input Class Initialized
INFO - 2022-11-29 09:42:18 --> Language Class Initialized
INFO - 2022-11-29 09:42:18 --> Loader Class Initialized
INFO - 2022-11-29 09:42:18 --> Helper loaded: url_helper
INFO - 2022-11-29 09:42:18 --> Database Driver Class Initialized
INFO - 2022-11-29 09:42:18 --> Helper loaded: form_helper
INFO - 2022-11-29 09:42:18 --> Form Validation Class Initialized
INFO - 2022-11-29 09:42:18 --> Controller Class Initialized
INFO - 2022-11-29 09:42:18 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:42:18 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 09:42:18 --> Final output sent to browser
DEBUG - 2022-11-29 09:42:18 --> Total execution time: 0.0483
INFO - 2022-11-29 09:43:38 --> Config Class Initialized
INFO - 2022-11-29 09:43:38 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:43:38 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:43:38 --> Utf8 Class Initialized
INFO - 2022-11-29 09:43:38 --> URI Class Initialized
INFO - 2022-11-29 09:43:38 --> Router Class Initialized
INFO - 2022-11-29 09:43:38 --> Output Class Initialized
INFO - 2022-11-29 09:43:38 --> Security Class Initialized
DEBUG - 2022-11-29 09:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:43:38 --> Input Class Initialized
INFO - 2022-11-29 09:43:38 --> Language Class Initialized
INFO - 2022-11-29 09:43:38 --> Loader Class Initialized
INFO - 2022-11-29 09:43:38 --> Helper loaded: url_helper
INFO - 2022-11-29 09:43:38 --> Database Driver Class Initialized
INFO - 2022-11-29 09:43:38 --> Helper loaded: form_helper
INFO - 2022-11-29 09:43:38 --> Form Validation Class Initialized
INFO - 2022-11-29 09:43:38 --> Controller Class Initialized
INFO - 2022-11-29 09:43:38 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:43:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-11-29 09:43:38 --> Config Class Initialized
INFO - 2022-11-29 09:43:38 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:43:38 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:43:38 --> Utf8 Class Initialized
INFO - 2022-11-29 09:43:38 --> URI Class Initialized
INFO - 2022-11-29 09:43:38 --> Router Class Initialized
INFO - 2022-11-29 09:43:38 --> Output Class Initialized
INFO - 2022-11-29 09:43:38 --> Security Class Initialized
DEBUG - 2022-11-29 09:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:43:38 --> Input Class Initialized
INFO - 2022-11-29 09:43:38 --> Language Class Initialized
INFO - 2022-11-29 09:43:38 --> Loader Class Initialized
INFO - 2022-11-29 09:43:38 --> Helper loaded: url_helper
INFO - 2022-11-29 09:43:38 --> Database Driver Class Initialized
INFO - 2022-11-29 09:43:38 --> Helper loaded: form_helper
INFO - 2022-11-29 09:43:38 --> Form Validation Class Initialized
INFO - 2022-11-29 09:43:38 --> Controller Class Initialized
INFO - 2022-11-29 09:43:38 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:43:38 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 09:43:38 --> Final output sent to browser
DEBUG - 2022-11-29 09:43:38 --> Total execution time: 0.0389
INFO - 2022-11-29 09:44:20 --> Config Class Initialized
INFO - 2022-11-29 09:44:20 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:44:20 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:44:20 --> Utf8 Class Initialized
INFO - 2022-11-29 09:44:20 --> URI Class Initialized
INFO - 2022-11-29 09:44:20 --> Router Class Initialized
INFO - 2022-11-29 09:44:20 --> Output Class Initialized
INFO - 2022-11-29 09:44:20 --> Security Class Initialized
DEBUG - 2022-11-29 09:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:44:20 --> Input Class Initialized
INFO - 2022-11-29 09:44:20 --> Language Class Initialized
INFO - 2022-11-29 09:44:20 --> Loader Class Initialized
INFO - 2022-11-29 09:44:20 --> Helper loaded: url_helper
INFO - 2022-11-29 09:44:20 --> Database Driver Class Initialized
INFO - 2022-11-29 09:44:20 --> Helper loaded: form_helper
INFO - 2022-11-29 09:44:20 --> Form Validation Class Initialized
INFO - 2022-11-29 09:44:20 --> Controller Class Initialized
INFO - 2022-11-29 09:44:20 --> Model "Buku_model" initialized
ERROR - 2022-11-29 09:44:20 --> Severity: Warning --> Undefined property: Buku::$penerbit C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 27
ERROR - 2022-11-29 09:44:20 --> Severity: error --> Exception: Call to a member function find_by_id() on null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 27
INFO - 2022-11-29 09:44:39 --> Config Class Initialized
INFO - 2022-11-29 09:44:39 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:44:39 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:44:39 --> Utf8 Class Initialized
INFO - 2022-11-29 09:44:39 --> URI Class Initialized
INFO - 2022-11-29 09:44:39 --> Router Class Initialized
INFO - 2022-11-29 09:44:39 --> Output Class Initialized
INFO - 2022-11-29 09:44:39 --> Security Class Initialized
DEBUG - 2022-11-29 09:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:44:39 --> Input Class Initialized
INFO - 2022-11-29 09:44:39 --> Language Class Initialized
INFO - 2022-11-29 09:44:39 --> Loader Class Initialized
INFO - 2022-11-29 09:44:39 --> Helper loaded: url_helper
INFO - 2022-11-29 09:44:39 --> Database Driver Class Initialized
INFO - 2022-11-29 09:44:39 --> Helper loaded: form_helper
INFO - 2022-11-29 09:44:39 --> Form Validation Class Initialized
INFO - 2022-11-29 09:44:39 --> Controller Class Initialized
INFO - 2022-11-29 09:44:39 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:44:39 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 09:44:39 --> Final output sent to browser
DEBUG - 2022-11-29 09:44:39 --> Total execution time: 0.0452
INFO - 2022-11-29 09:44:46 --> Config Class Initialized
INFO - 2022-11-29 09:44:46 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:44:46 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:44:46 --> Utf8 Class Initialized
INFO - 2022-11-29 09:44:46 --> URI Class Initialized
INFO - 2022-11-29 09:44:46 --> Router Class Initialized
INFO - 2022-11-29 09:44:46 --> Output Class Initialized
INFO - 2022-11-29 09:44:46 --> Security Class Initialized
DEBUG - 2022-11-29 09:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:44:46 --> Input Class Initialized
INFO - 2022-11-29 09:44:46 --> Language Class Initialized
INFO - 2022-11-29 09:44:46 --> Loader Class Initialized
INFO - 2022-11-29 09:44:46 --> Helper loaded: url_helper
INFO - 2022-11-29 09:44:46 --> Database Driver Class Initialized
INFO - 2022-11-29 09:44:46 --> Helper loaded: form_helper
INFO - 2022-11-29 09:44:46 --> Form Validation Class Initialized
INFO - 2022-11-29 09:44:46 --> Controller Class Initialized
INFO - 2022-11-29 09:44:46 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:44:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-11-29 09:44:46 --> Config Class Initialized
INFO - 2022-11-29 09:44:46 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:44:46 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:44:46 --> Utf8 Class Initialized
INFO - 2022-11-29 09:44:46 --> URI Class Initialized
INFO - 2022-11-29 09:44:46 --> Router Class Initialized
INFO - 2022-11-29 09:44:46 --> Output Class Initialized
INFO - 2022-11-29 09:44:46 --> Security Class Initialized
DEBUG - 2022-11-29 09:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:44:46 --> Input Class Initialized
INFO - 2022-11-29 09:44:46 --> Language Class Initialized
INFO - 2022-11-29 09:44:46 --> Loader Class Initialized
INFO - 2022-11-29 09:44:46 --> Helper loaded: url_helper
INFO - 2022-11-29 09:44:46 --> Database Driver Class Initialized
INFO - 2022-11-29 09:44:46 --> Helper loaded: form_helper
INFO - 2022-11-29 09:44:46 --> Form Validation Class Initialized
INFO - 2022-11-29 09:44:46 --> Controller Class Initialized
INFO - 2022-11-29 09:44:46 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:44:46 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 09:44:46 --> Final output sent to browser
DEBUG - 2022-11-29 09:44:46 --> Total execution time: 0.0639
INFO - 2022-11-29 09:50:13 --> Config Class Initialized
INFO - 2022-11-29 09:50:13 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:50:13 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:50:13 --> Utf8 Class Initialized
INFO - 2022-11-29 09:50:13 --> URI Class Initialized
INFO - 2022-11-29 09:50:14 --> Router Class Initialized
INFO - 2022-11-29 09:50:14 --> Output Class Initialized
INFO - 2022-11-29 09:50:14 --> Security Class Initialized
DEBUG - 2022-11-29 09:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:50:14 --> Input Class Initialized
INFO - 2022-11-29 09:50:14 --> Language Class Initialized
INFO - 2022-11-29 09:50:14 --> Loader Class Initialized
INFO - 2022-11-29 09:50:14 --> Helper loaded: url_helper
INFO - 2022-11-29 09:50:14 --> Database Driver Class Initialized
INFO - 2022-11-29 09:50:14 --> Helper loaded: form_helper
INFO - 2022-11-29 09:50:14 --> Form Validation Class Initialized
INFO - 2022-11-29 09:50:14 --> Controller Class Initialized
INFO - 2022-11-29 09:50:14 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:50:14 --> Config Class Initialized
INFO - 2022-11-29 09:50:14 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:50:14 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:50:14 --> Utf8 Class Initialized
INFO - 2022-11-29 09:50:14 --> URI Class Initialized
INFO - 2022-11-29 09:50:14 --> Router Class Initialized
INFO - 2022-11-29 09:50:14 --> Output Class Initialized
INFO - 2022-11-29 09:50:14 --> Security Class Initialized
DEBUG - 2022-11-29 09:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:50:14 --> Input Class Initialized
INFO - 2022-11-29 09:50:14 --> Language Class Initialized
INFO - 2022-11-29 09:50:14 --> Loader Class Initialized
INFO - 2022-11-29 09:50:14 --> Helper loaded: url_helper
INFO - 2022-11-29 09:50:14 --> Database Driver Class Initialized
INFO - 2022-11-29 09:50:14 --> Helper loaded: form_helper
INFO - 2022-11-29 09:50:14 --> Form Validation Class Initialized
INFO - 2022-11-29 09:50:14 --> Controller Class Initialized
INFO - 2022-11-29 09:50:14 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:50:14 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 09:50:14 --> Final output sent to browser
DEBUG - 2022-11-29 09:50:14 --> Total execution time: 0.0860
INFO - 2022-11-29 09:50:15 --> Config Class Initialized
INFO - 2022-11-29 09:50:15 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:50:15 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:50:15 --> Utf8 Class Initialized
INFO - 2022-11-29 09:50:15 --> URI Class Initialized
INFO - 2022-11-29 09:50:15 --> Router Class Initialized
INFO - 2022-11-29 09:50:15 --> Output Class Initialized
INFO - 2022-11-29 09:50:15 --> Security Class Initialized
DEBUG - 2022-11-29 09:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:50:15 --> Input Class Initialized
INFO - 2022-11-29 09:50:15 --> Language Class Initialized
INFO - 2022-11-29 09:50:15 --> Loader Class Initialized
INFO - 2022-11-29 09:50:15 --> Helper loaded: url_helper
INFO - 2022-11-29 09:50:15 --> Database Driver Class Initialized
INFO - 2022-11-29 09:50:15 --> Helper loaded: form_helper
INFO - 2022-11-29 09:50:15 --> Form Validation Class Initialized
INFO - 2022-11-29 09:50:15 --> Controller Class Initialized
INFO - 2022-11-29 09:50:15 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:50:15 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 09:50:15 --> Final output sent to browser
DEBUG - 2022-11-29 09:50:15 --> Total execution time: 0.0444
INFO - 2022-11-29 09:54:09 --> Config Class Initialized
INFO - 2022-11-29 09:54:09 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:54:09 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:54:09 --> Utf8 Class Initialized
INFO - 2022-11-29 09:54:09 --> URI Class Initialized
INFO - 2022-11-29 09:54:09 --> Router Class Initialized
INFO - 2022-11-29 09:54:09 --> Output Class Initialized
INFO - 2022-11-29 09:54:09 --> Security Class Initialized
DEBUG - 2022-11-29 09:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:54:09 --> Input Class Initialized
INFO - 2022-11-29 09:54:09 --> Language Class Initialized
INFO - 2022-11-29 09:54:09 --> Loader Class Initialized
INFO - 2022-11-29 09:54:09 --> Helper loaded: url_helper
INFO - 2022-11-29 09:54:09 --> Database Driver Class Initialized
INFO - 2022-11-29 09:54:09 --> Helper loaded: form_helper
INFO - 2022-11-29 09:54:09 --> Form Validation Class Initialized
INFO - 2022-11-29 09:54:09 --> Controller Class Initialized
INFO - 2022-11-29 09:54:09 --> Model "Buku_model" initialized
ERROR - 2022-11-29 09:54:09 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 59
ERROR - 2022-11-29 09:54:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 59
ERROR - 2022-11-29 09:54:09 --> Severity: Warning --> Undefined variable $file_name C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 76
INFO - 2022-11-29 09:54:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 09:54:09 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 09:54:45 --> Config Class Initialized
INFO - 2022-11-29 09:54:45 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:54:45 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:54:45 --> Utf8 Class Initialized
INFO - 2022-11-29 09:54:45 --> URI Class Initialized
INFO - 2022-11-29 09:54:45 --> Router Class Initialized
INFO - 2022-11-29 09:54:45 --> Output Class Initialized
INFO - 2022-11-29 09:54:45 --> Security Class Initialized
DEBUG - 2022-11-29 09:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:54:45 --> Input Class Initialized
INFO - 2022-11-29 09:54:45 --> Language Class Initialized
INFO - 2022-11-29 09:54:45 --> Loader Class Initialized
INFO - 2022-11-29 09:54:45 --> Helper loaded: url_helper
INFO - 2022-11-29 09:54:45 --> Database Driver Class Initialized
INFO - 2022-11-29 09:54:46 --> Helper loaded: form_helper
INFO - 2022-11-29 09:54:46 --> Form Validation Class Initialized
INFO - 2022-11-29 09:54:46 --> Controller Class Initialized
INFO - 2022-11-29 09:54:46 --> Model "Buku_model" initialized
ERROR - 2022-11-29 09:54:46 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 58
ERROR - 2022-11-29 09:54:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 58
ERROR - 2022-11-29 09:54:46 --> Severity: Warning --> Undefined variable $file_name C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 75
INFO - 2022-11-29 09:54:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 09:54:46 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 09:54:49 --> Config Class Initialized
INFO - 2022-11-29 09:54:49 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:54:49 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:54:49 --> Utf8 Class Initialized
INFO - 2022-11-29 09:54:49 --> URI Class Initialized
INFO - 2022-11-29 09:54:49 --> Router Class Initialized
INFO - 2022-11-29 09:54:49 --> Output Class Initialized
INFO - 2022-11-29 09:54:49 --> Security Class Initialized
DEBUG - 2022-11-29 09:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:54:49 --> Input Class Initialized
INFO - 2022-11-29 09:54:49 --> Language Class Initialized
INFO - 2022-11-29 09:54:49 --> Loader Class Initialized
INFO - 2022-11-29 09:54:49 --> Helper loaded: url_helper
INFO - 2022-11-29 09:54:49 --> Database Driver Class Initialized
INFO - 2022-11-29 09:54:49 --> Helper loaded: form_helper
INFO - 2022-11-29 09:54:49 --> Form Validation Class Initialized
INFO - 2022-11-29 09:54:49 --> Controller Class Initialized
INFO - 2022-11-29 09:54:49 --> Model "Buku_model" initialized
ERROR - 2022-11-29 09:54:49 --> Severity: Warning --> Undefined variable $gambar C:\xampp\htdocs\ekatalog\application\views\buku\form.php 68
INFO - 2022-11-29 09:54:49 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 09:54:49 --> Final output sent to browser
DEBUG - 2022-11-29 09:54:49 --> Total execution time: 0.0508
INFO - 2022-11-29 09:55:23 --> Config Class Initialized
INFO - 2022-11-29 09:55:23 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:55:23 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:55:23 --> Utf8 Class Initialized
INFO - 2022-11-29 09:55:23 --> URI Class Initialized
INFO - 2022-11-29 09:55:23 --> Router Class Initialized
INFO - 2022-11-29 09:55:23 --> Output Class Initialized
INFO - 2022-11-29 09:55:23 --> Security Class Initialized
DEBUG - 2022-11-29 09:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:55:23 --> Input Class Initialized
INFO - 2022-11-29 09:55:23 --> Language Class Initialized
INFO - 2022-11-29 09:55:23 --> Loader Class Initialized
INFO - 2022-11-29 09:55:23 --> Helper loaded: url_helper
INFO - 2022-11-29 09:55:23 --> Database Driver Class Initialized
INFO - 2022-11-29 09:55:23 --> Helper loaded: form_helper
INFO - 2022-11-29 09:55:23 --> Form Validation Class Initialized
INFO - 2022-11-29 09:55:23 --> Controller Class Initialized
INFO - 2022-11-29 09:55:23 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:55:23 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 09:55:23 --> Final output sent to browser
DEBUG - 2022-11-29 09:55:23 --> Total execution time: 0.0670
INFO - 2022-11-29 09:55:42 --> Config Class Initialized
INFO - 2022-11-29 09:55:42 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:55:42 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:55:42 --> Utf8 Class Initialized
INFO - 2022-11-29 09:55:42 --> URI Class Initialized
INFO - 2022-11-29 09:55:42 --> Router Class Initialized
INFO - 2022-11-29 09:55:42 --> Output Class Initialized
INFO - 2022-11-29 09:55:42 --> Security Class Initialized
DEBUG - 2022-11-29 09:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:55:42 --> Input Class Initialized
INFO - 2022-11-29 09:55:42 --> Language Class Initialized
INFO - 2022-11-29 09:55:42 --> Loader Class Initialized
INFO - 2022-11-29 09:55:42 --> Helper loaded: url_helper
INFO - 2022-11-29 09:55:42 --> Database Driver Class Initialized
INFO - 2022-11-29 09:55:42 --> Helper loaded: form_helper
INFO - 2022-11-29 09:55:42 --> Form Validation Class Initialized
INFO - 2022-11-29 09:55:42 --> Controller Class Initialized
INFO - 2022-11-29 09:55:42 --> Model "Buku_model" initialized
ERROR - 2022-11-29 09:55:42 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 58
ERROR - 2022-11-29 09:55:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 58
ERROR - 2022-11-29 09:55:42 --> Severity: Warning --> Undefined variable $file_name C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 75
INFO - 2022-11-29 09:55:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 09:55:42 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 09:57:52 --> Config Class Initialized
INFO - 2022-11-29 09:57:52 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:57:52 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:57:52 --> Utf8 Class Initialized
INFO - 2022-11-29 09:57:52 --> URI Class Initialized
INFO - 2022-11-29 09:57:52 --> Router Class Initialized
INFO - 2022-11-29 09:57:52 --> Output Class Initialized
INFO - 2022-11-29 09:57:52 --> Security Class Initialized
DEBUG - 2022-11-29 09:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:57:52 --> Input Class Initialized
INFO - 2022-11-29 09:57:52 --> Language Class Initialized
ERROR - 2022-11-29 09:57:52 --> Severity: error --> Exception: syntax error, unexpected token "[", expecting identifier or variable or "{" or "$" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 31
INFO - 2022-11-29 09:58:20 --> Config Class Initialized
INFO - 2022-11-29 09:58:20 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:58:20 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:58:20 --> Utf8 Class Initialized
INFO - 2022-11-29 09:58:20 --> URI Class Initialized
INFO - 2022-11-29 09:58:20 --> Router Class Initialized
INFO - 2022-11-29 09:58:20 --> Output Class Initialized
INFO - 2022-11-29 09:58:20 --> Security Class Initialized
DEBUG - 2022-11-29 09:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:58:20 --> Input Class Initialized
INFO - 2022-11-29 09:58:20 --> Language Class Initialized
INFO - 2022-11-29 09:58:20 --> Loader Class Initialized
INFO - 2022-11-29 09:58:20 --> Helper loaded: url_helper
INFO - 2022-11-29 09:58:20 --> Database Driver Class Initialized
INFO - 2022-11-29 09:58:20 --> Helper loaded: form_helper
INFO - 2022-11-29 09:58:20 --> Form Validation Class Initialized
INFO - 2022-11-29 09:58:20 --> Controller Class Initialized
INFO - 2022-11-29 09:58:20 --> Model "Buku_model" initialized
ERROR - 2022-11-29 09:58:20 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 53
ERROR - 2022-11-29 09:58:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 53
INFO - 2022-11-29 09:58:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 09:58:20 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 09:58:23 --> Config Class Initialized
INFO - 2022-11-29 09:58:23 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:58:23 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:58:23 --> Utf8 Class Initialized
INFO - 2022-11-29 09:58:23 --> URI Class Initialized
INFO - 2022-11-29 09:58:23 --> Router Class Initialized
INFO - 2022-11-29 09:58:23 --> Output Class Initialized
INFO - 2022-11-29 09:58:23 --> Security Class Initialized
DEBUG - 2022-11-29 09:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:58:23 --> Input Class Initialized
INFO - 2022-11-29 09:58:23 --> Language Class Initialized
INFO - 2022-11-29 09:58:23 --> Loader Class Initialized
INFO - 2022-11-29 09:58:23 --> Helper loaded: url_helper
INFO - 2022-11-29 09:58:23 --> Database Driver Class Initialized
INFO - 2022-11-29 09:58:23 --> Helper loaded: form_helper
INFO - 2022-11-29 09:58:23 --> Form Validation Class Initialized
INFO - 2022-11-29 09:58:23 --> Controller Class Initialized
INFO - 2022-11-29 09:58:23 --> Model "Buku_model" initialized
ERROR - 2022-11-29 09:58:23 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 53
ERROR - 2022-11-29 09:58:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 53
INFO - 2022-11-29 09:58:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 09:58:23 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 09:58:42 --> Config Class Initialized
INFO - 2022-11-29 09:58:42 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:58:42 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:58:42 --> Utf8 Class Initialized
INFO - 2022-11-29 09:58:42 --> URI Class Initialized
INFO - 2022-11-29 09:58:42 --> Router Class Initialized
INFO - 2022-11-29 09:58:42 --> Output Class Initialized
INFO - 2022-11-29 09:58:42 --> Security Class Initialized
DEBUG - 2022-11-29 09:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:58:42 --> Input Class Initialized
INFO - 2022-11-29 09:58:42 --> Language Class Initialized
INFO - 2022-11-29 09:58:42 --> Loader Class Initialized
INFO - 2022-11-29 09:58:42 --> Helper loaded: url_helper
INFO - 2022-11-29 09:58:42 --> Database Driver Class Initialized
INFO - 2022-11-29 09:58:42 --> Helper loaded: form_helper
INFO - 2022-11-29 09:58:42 --> Form Validation Class Initialized
INFO - 2022-11-29 09:58:42 --> Controller Class Initialized
INFO - 2022-11-29 09:58:42 --> Model "Buku_model" initialized
INFO - 2022-11-29 09:58:42 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 09:58:42 --> Final output sent to browser
DEBUG - 2022-11-29 09:58:42 --> Total execution time: 0.0551
INFO - 2022-11-29 09:58:56 --> Config Class Initialized
INFO - 2022-11-29 09:58:56 --> Hooks Class Initialized
DEBUG - 2022-11-29 09:58:56 --> UTF-8 Support Enabled
INFO - 2022-11-29 09:58:56 --> Utf8 Class Initialized
INFO - 2022-11-29 09:58:56 --> URI Class Initialized
INFO - 2022-11-29 09:58:56 --> Router Class Initialized
INFO - 2022-11-29 09:58:56 --> Output Class Initialized
INFO - 2022-11-29 09:58:56 --> Security Class Initialized
DEBUG - 2022-11-29 09:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 09:58:56 --> Input Class Initialized
INFO - 2022-11-29 09:58:56 --> Language Class Initialized
INFO - 2022-11-29 09:58:56 --> Loader Class Initialized
INFO - 2022-11-29 09:58:56 --> Helper loaded: url_helper
INFO - 2022-11-29 09:58:56 --> Database Driver Class Initialized
INFO - 2022-11-29 09:58:56 --> Helper loaded: form_helper
INFO - 2022-11-29 09:58:56 --> Form Validation Class Initialized
INFO - 2022-11-29 09:58:56 --> Controller Class Initialized
INFO - 2022-11-29 09:58:56 --> Model "Buku_model" initialized
ERROR - 2022-11-29 09:58:56 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 53
ERROR - 2022-11-29 09:58:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 53
INFO - 2022-11-29 09:58:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 09:58:56 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:03:56 --> Config Class Initialized
INFO - 2022-11-29 10:03:56 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:03:56 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:03:56 --> Utf8 Class Initialized
INFO - 2022-11-29 10:03:56 --> URI Class Initialized
INFO - 2022-11-29 10:03:56 --> Router Class Initialized
INFO - 2022-11-29 10:03:56 --> Output Class Initialized
INFO - 2022-11-29 10:03:56 --> Security Class Initialized
DEBUG - 2022-11-29 10:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:03:56 --> Input Class Initialized
INFO - 2022-11-29 10:03:56 --> Language Class Initialized
INFO - 2022-11-29 10:03:56 --> Loader Class Initialized
INFO - 2022-11-29 10:03:56 --> Helper loaded: url_helper
INFO - 2022-11-29 10:03:56 --> Database Driver Class Initialized
INFO - 2022-11-29 10:03:56 --> Helper loaded: form_helper
INFO - 2022-11-29 10:03:56 --> Form Validation Class Initialized
INFO - 2022-11-29 10:03:56 --> Controller Class Initialized
INFO - 2022-11-29 10:03:56 --> Model "Buku_model" initialized
ERROR - 2022-11-29 10:03:56 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 53
ERROR - 2022-11-29 10:03:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 53
INFO - 2022-11-29 10:03:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:03:56 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:04:00 --> Config Class Initialized
INFO - 2022-11-29 10:04:00 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:04:00 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:04:00 --> Utf8 Class Initialized
INFO - 2022-11-29 10:04:00 --> URI Class Initialized
INFO - 2022-11-29 10:04:00 --> Router Class Initialized
INFO - 2022-11-29 10:04:00 --> Output Class Initialized
INFO - 2022-11-29 10:04:00 --> Security Class Initialized
DEBUG - 2022-11-29 10:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:04:00 --> Input Class Initialized
INFO - 2022-11-29 10:04:00 --> Language Class Initialized
INFO - 2022-11-29 10:04:00 --> Loader Class Initialized
INFO - 2022-11-29 10:04:00 --> Helper loaded: url_helper
INFO - 2022-11-29 10:04:00 --> Database Driver Class Initialized
INFO - 2022-11-29 10:04:00 --> Helper loaded: form_helper
INFO - 2022-11-29 10:04:00 --> Form Validation Class Initialized
INFO - 2022-11-29 10:04:00 --> Controller Class Initialized
INFO - 2022-11-29 10:04:00 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:04:00 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 10:04:00 --> Final output sent to browser
DEBUG - 2022-11-29 10:04:00 --> Total execution time: 0.0436
INFO - 2022-11-29 10:04:14 --> Config Class Initialized
INFO - 2022-11-29 10:04:14 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:04:14 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:04:14 --> Utf8 Class Initialized
INFO - 2022-11-29 10:04:14 --> URI Class Initialized
INFO - 2022-11-29 10:04:14 --> Router Class Initialized
INFO - 2022-11-29 10:04:14 --> Output Class Initialized
INFO - 2022-11-29 10:04:14 --> Security Class Initialized
DEBUG - 2022-11-29 10:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:04:14 --> Input Class Initialized
INFO - 2022-11-29 10:04:14 --> Language Class Initialized
INFO - 2022-11-29 10:04:14 --> Loader Class Initialized
INFO - 2022-11-29 10:04:14 --> Helper loaded: url_helper
INFO - 2022-11-29 10:04:14 --> Database Driver Class Initialized
INFO - 2022-11-29 10:04:14 --> Helper loaded: form_helper
INFO - 2022-11-29 10:04:14 --> Form Validation Class Initialized
INFO - 2022-11-29 10:04:14 --> Controller Class Initialized
INFO - 2022-11-29 10:04:14 --> Model "Buku_model" initialized
ERROR - 2022-11-29 10:04:14 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 53
ERROR - 2022-11-29 10:04:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 53
INFO - 2022-11-29 10:04:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:04:14 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:09:33 --> Config Class Initialized
INFO - 2022-11-29 10:09:33 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:09:33 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:09:33 --> Utf8 Class Initialized
INFO - 2022-11-29 10:09:33 --> URI Class Initialized
INFO - 2022-11-29 10:09:33 --> Router Class Initialized
INFO - 2022-11-29 10:09:33 --> Output Class Initialized
INFO - 2022-11-29 10:09:33 --> Security Class Initialized
DEBUG - 2022-11-29 10:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:09:33 --> Input Class Initialized
INFO - 2022-11-29 10:09:33 --> Language Class Initialized
INFO - 2022-11-29 10:09:33 --> Loader Class Initialized
INFO - 2022-11-29 10:09:33 --> Helper loaded: url_helper
INFO - 2022-11-29 10:09:33 --> Database Driver Class Initialized
INFO - 2022-11-29 10:09:33 --> Helper loaded: form_helper
INFO - 2022-11-29 10:09:33 --> Form Validation Class Initialized
INFO - 2022-11-29 10:09:33 --> Controller Class Initialized
INFO - 2022-11-29 10:09:33 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:09:33 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:09:33 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
ERROR - 2022-11-29 10:09:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
INFO - 2022-11-29 10:09:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:09:33 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:09:36 --> Config Class Initialized
INFO - 2022-11-29 10:09:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:09:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:09:36 --> Utf8 Class Initialized
INFO - 2022-11-29 10:09:36 --> URI Class Initialized
INFO - 2022-11-29 10:09:36 --> Router Class Initialized
INFO - 2022-11-29 10:09:36 --> Output Class Initialized
INFO - 2022-11-29 10:09:36 --> Security Class Initialized
DEBUG - 2022-11-29 10:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:09:36 --> Input Class Initialized
INFO - 2022-11-29 10:09:36 --> Language Class Initialized
INFO - 2022-11-29 10:09:36 --> Loader Class Initialized
INFO - 2022-11-29 10:09:36 --> Helper loaded: url_helper
INFO - 2022-11-29 10:09:36 --> Database Driver Class Initialized
INFO - 2022-11-29 10:09:36 --> Helper loaded: form_helper
INFO - 2022-11-29 10:09:36 --> Form Validation Class Initialized
INFO - 2022-11-29 10:09:36 --> Controller Class Initialized
INFO - 2022-11-29 10:09:36 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:09:36 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:09:36 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
ERROR - 2022-11-29 10:09:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
INFO - 2022-11-29 10:09:36 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:09:36 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:11:33 --> Config Class Initialized
INFO - 2022-11-29 10:11:33 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:11:33 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:11:33 --> Utf8 Class Initialized
INFO - 2022-11-29 10:11:33 --> URI Class Initialized
INFO - 2022-11-29 10:11:33 --> Router Class Initialized
INFO - 2022-11-29 10:11:33 --> Output Class Initialized
INFO - 2022-11-29 10:11:33 --> Security Class Initialized
DEBUG - 2022-11-29 10:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:11:33 --> Input Class Initialized
INFO - 2022-11-29 10:11:33 --> Language Class Initialized
INFO - 2022-11-29 10:11:33 --> Loader Class Initialized
INFO - 2022-11-29 10:11:33 --> Helper loaded: url_helper
INFO - 2022-11-29 10:11:33 --> Database Driver Class Initialized
INFO - 2022-11-29 10:11:33 --> Helper loaded: form_helper
INFO - 2022-11-29 10:11:33 --> Form Validation Class Initialized
INFO - 2022-11-29 10:11:33 --> Controller Class Initialized
INFO - 2022-11-29 10:11:33 --> Model "Buku_model" initialized
ERROR - 2022-11-29 10:11:33 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
ERROR - 2022-11-29 10:11:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
INFO - 2022-11-29 10:11:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:11:33 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:11:36 --> Config Class Initialized
INFO - 2022-11-29 10:11:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:11:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:11:36 --> Utf8 Class Initialized
INFO - 2022-11-29 10:11:36 --> URI Class Initialized
INFO - 2022-11-29 10:11:36 --> Router Class Initialized
INFO - 2022-11-29 10:11:36 --> Output Class Initialized
INFO - 2022-11-29 10:11:36 --> Security Class Initialized
DEBUG - 2022-11-29 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:11:36 --> Input Class Initialized
INFO - 2022-11-29 10:11:36 --> Language Class Initialized
INFO - 2022-11-29 10:11:36 --> Loader Class Initialized
INFO - 2022-11-29 10:11:36 --> Helper loaded: url_helper
INFO - 2022-11-29 10:11:36 --> Database Driver Class Initialized
INFO - 2022-11-29 10:11:36 --> Helper loaded: form_helper
INFO - 2022-11-29 10:11:36 --> Form Validation Class Initialized
INFO - 2022-11-29 10:11:36 --> Controller Class Initialized
INFO - 2022-11-29 10:11:36 --> Model "Buku_model" initialized
ERROR - 2022-11-29 10:11:36 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
ERROR - 2022-11-29 10:11:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
INFO - 2022-11-29 10:11:36 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:11:36 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:16:36 --> Config Class Initialized
INFO - 2022-11-29 10:16:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:16:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:16:36 --> Utf8 Class Initialized
INFO - 2022-11-29 10:16:36 --> URI Class Initialized
INFO - 2022-11-29 10:16:36 --> Router Class Initialized
INFO - 2022-11-29 10:16:36 --> Output Class Initialized
INFO - 2022-11-29 10:16:36 --> Security Class Initialized
DEBUG - 2022-11-29 10:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:16:36 --> Input Class Initialized
INFO - 2022-11-29 10:16:36 --> Language Class Initialized
INFO - 2022-11-29 10:16:36 --> Loader Class Initialized
INFO - 2022-11-29 10:16:36 --> Helper loaded: url_helper
INFO - 2022-11-29 10:16:36 --> Database Driver Class Initialized
INFO - 2022-11-29 10:16:36 --> Helper loaded: form_helper
INFO - 2022-11-29 10:16:36 --> Form Validation Class Initialized
INFO - 2022-11-29 10:16:36 --> Controller Class Initialized
INFO - 2022-11-29 10:16:36 --> Model "Buku_model" initialized
ERROR - 2022-11-29 10:16:36 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
ERROR - 2022-11-29 10:16:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
INFO - 2022-11-29 10:16:36 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:16:36 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:21:04 --> Config Class Initialized
INFO - 2022-11-29 10:21:04 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:21:04 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:21:04 --> Utf8 Class Initialized
INFO - 2022-11-29 10:21:04 --> URI Class Initialized
INFO - 2022-11-29 10:21:04 --> Router Class Initialized
INFO - 2022-11-29 10:21:04 --> Output Class Initialized
INFO - 2022-11-29 10:21:04 --> Security Class Initialized
DEBUG - 2022-11-29 10:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:21:04 --> Input Class Initialized
INFO - 2022-11-29 10:21:04 --> Language Class Initialized
INFO - 2022-11-29 10:21:04 --> Loader Class Initialized
INFO - 2022-11-29 10:21:04 --> Helper loaded: url_helper
INFO - 2022-11-29 10:21:04 --> Database Driver Class Initialized
INFO - 2022-11-29 10:21:04 --> Helper loaded: form_helper
INFO - 2022-11-29 10:21:04 --> Form Validation Class Initialized
INFO - 2022-11-29 10:21:04 --> Controller Class Initialized
INFO - 2022-11-29 10:21:04 --> Model "Buku_model" initialized
ERROR - 2022-11-29 10:21:04 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
ERROR - 2022-11-29 10:21:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
INFO - 2022-11-29 10:21:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:21:04 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:25:23 --> Config Class Initialized
INFO - 2022-11-29 10:25:23 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:25:23 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:25:23 --> Utf8 Class Initialized
INFO - 2022-11-29 10:25:23 --> URI Class Initialized
INFO - 2022-11-29 10:25:23 --> Router Class Initialized
INFO - 2022-11-29 10:25:23 --> Output Class Initialized
INFO - 2022-11-29 10:25:23 --> Security Class Initialized
DEBUG - 2022-11-29 10:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:25:23 --> Input Class Initialized
INFO - 2022-11-29 10:25:23 --> Language Class Initialized
INFO - 2022-11-29 10:25:23 --> Loader Class Initialized
INFO - 2022-11-29 10:25:23 --> Helper loaded: url_helper
INFO - 2022-11-29 10:25:23 --> Database Driver Class Initialized
INFO - 2022-11-29 10:25:23 --> Helper loaded: form_helper
INFO - 2022-11-29 10:25:23 --> Form Validation Class Initialized
INFO - 2022-11-29 10:25:23 --> Controller Class Initialized
INFO - 2022-11-29 10:25:23 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:25:23 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 10:25:23 --> Final output sent to browser
DEBUG - 2022-11-29 10:25:23 --> Total execution time: 0.0552
INFO - 2022-11-29 10:25:24 --> Config Class Initialized
INFO - 2022-11-29 10:25:24 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:25:24 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:25:24 --> Utf8 Class Initialized
INFO - 2022-11-29 10:25:24 --> URI Class Initialized
INFO - 2022-11-29 10:25:24 --> Router Class Initialized
INFO - 2022-11-29 10:25:24 --> Output Class Initialized
INFO - 2022-11-29 10:25:24 --> Security Class Initialized
DEBUG - 2022-11-29 10:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:25:24 --> Input Class Initialized
INFO - 2022-11-29 10:25:24 --> Language Class Initialized
INFO - 2022-11-29 10:25:24 --> Loader Class Initialized
INFO - 2022-11-29 10:25:24 --> Helper loaded: url_helper
INFO - 2022-11-29 10:25:24 --> Database Driver Class Initialized
INFO - 2022-11-29 10:25:24 --> Helper loaded: form_helper
INFO - 2022-11-29 10:25:24 --> Form Validation Class Initialized
INFO - 2022-11-29 10:25:24 --> Controller Class Initialized
INFO - 2022-11-29 10:25:24 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:25:24 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 10:25:24 --> Final output sent to browser
DEBUG - 2022-11-29 10:25:24 --> Total execution time: 0.0500
INFO - 2022-11-29 10:25:26 --> Config Class Initialized
INFO - 2022-11-29 10:25:26 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:25:26 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:25:26 --> Utf8 Class Initialized
INFO - 2022-11-29 10:25:26 --> URI Class Initialized
INFO - 2022-11-29 10:25:26 --> Router Class Initialized
INFO - 2022-11-29 10:25:26 --> Output Class Initialized
INFO - 2022-11-29 10:25:26 --> Security Class Initialized
DEBUG - 2022-11-29 10:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:25:26 --> Input Class Initialized
INFO - 2022-11-29 10:25:26 --> Language Class Initialized
INFO - 2022-11-29 10:25:26 --> Loader Class Initialized
INFO - 2022-11-29 10:25:26 --> Helper loaded: url_helper
INFO - 2022-11-29 10:25:26 --> Database Driver Class Initialized
INFO - 2022-11-29 10:25:26 --> Helper loaded: form_helper
INFO - 2022-11-29 10:25:26 --> Form Validation Class Initialized
INFO - 2022-11-29 10:25:26 --> Controller Class Initialized
INFO - 2022-11-29 10:25:26 --> Model "Buku_model" initialized
ERROR - 2022-11-29 10:25:26 --> Severity: Warning --> Undefined property: Buku::$penerbit C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 32
ERROR - 2022-11-29 10:25:26 --> Severity: error --> Exception: Call to a member function find_all() on null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 32
INFO - 2022-11-29 10:25:56 --> Config Class Initialized
INFO - 2022-11-29 10:25:56 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:25:56 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:25:56 --> Utf8 Class Initialized
INFO - 2022-11-29 10:25:56 --> URI Class Initialized
INFO - 2022-11-29 10:25:56 --> Router Class Initialized
INFO - 2022-11-29 10:25:56 --> Output Class Initialized
INFO - 2022-11-29 10:25:56 --> Security Class Initialized
DEBUG - 2022-11-29 10:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:25:56 --> Input Class Initialized
INFO - 2022-11-29 10:25:56 --> Language Class Initialized
INFO - 2022-11-29 10:25:56 --> Loader Class Initialized
INFO - 2022-11-29 10:25:56 --> Helper loaded: url_helper
INFO - 2022-11-29 10:25:56 --> Database Driver Class Initialized
INFO - 2022-11-29 10:25:56 --> Helper loaded: form_helper
INFO - 2022-11-29 10:25:56 --> Form Validation Class Initialized
INFO - 2022-11-29 10:25:56 --> Controller Class Initialized
INFO - 2022-11-29 10:25:56 --> Model "Buku_model" initialized
ERROR - 2022-11-29 10:25:56 --> Severity: Warning --> Undefined property: Buku::$penerbit C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 32
ERROR - 2022-11-29 10:25:56 --> Severity: error --> Exception: Call to a member function find_all() on null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 32
INFO - 2022-11-29 10:26:37 --> Config Class Initialized
INFO - 2022-11-29 10:26:37 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:26:37 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:26:37 --> Utf8 Class Initialized
INFO - 2022-11-29 10:26:37 --> URI Class Initialized
INFO - 2022-11-29 10:26:37 --> Router Class Initialized
INFO - 2022-11-29 10:26:37 --> Output Class Initialized
INFO - 2022-11-29 10:26:37 --> Security Class Initialized
DEBUG - 2022-11-29 10:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:26:37 --> Input Class Initialized
INFO - 2022-11-29 10:26:37 --> Language Class Initialized
INFO - 2022-11-29 10:26:37 --> Loader Class Initialized
INFO - 2022-11-29 10:26:37 --> Helper loaded: url_helper
INFO - 2022-11-29 10:26:37 --> Database Driver Class Initialized
INFO - 2022-11-29 10:26:37 --> Helper loaded: form_helper
INFO - 2022-11-29 10:26:37 --> Form Validation Class Initialized
INFO - 2022-11-29 10:26:37 --> Controller Class Initialized
INFO - 2022-11-29 10:26:37 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:26:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:26:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 10:26:37 --> Final output sent to browser
DEBUG - 2022-11-29 10:26:37 --> Total execution time: 0.0569
INFO - 2022-11-29 10:26:58 --> Config Class Initialized
INFO - 2022-11-29 10:26:58 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:26:58 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:26:58 --> Utf8 Class Initialized
INFO - 2022-11-29 10:26:58 --> URI Class Initialized
INFO - 2022-11-29 10:26:58 --> Router Class Initialized
INFO - 2022-11-29 10:26:58 --> Output Class Initialized
INFO - 2022-11-29 10:26:58 --> Security Class Initialized
DEBUG - 2022-11-29 10:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:26:58 --> Input Class Initialized
INFO - 2022-11-29 10:26:58 --> Language Class Initialized
INFO - 2022-11-29 10:26:58 --> Loader Class Initialized
INFO - 2022-11-29 10:26:58 --> Helper loaded: url_helper
INFO - 2022-11-29 10:26:58 --> Database Driver Class Initialized
INFO - 2022-11-29 10:26:58 --> Helper loaded: form_helper
INFO - 2022-11-29 10:26:58 --> Form Validation Class Initialized
INFO - 2022-11-29 10:26:58 --> Controller Class Initialized
INFO - 2022-11-29 10:26:58 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:26:58 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:26:58 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
ERROR - 2022-11-29 10:26:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
INFO - 2022-11-29 10:26:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:26:58 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:28:01 --> Config Class Initialized
INFO - 2022-11-29 10:28:01 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:28:01 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:28:01 --> Utf8 Class Initialized
INFO - 2022-11-29 10:28:01 --> URI Class Initialized
INFO - 2022-11-29 10:28:01 --> Router Class Initialized
INFO - 2022-11-29 10:28:01 --> Output Class Initialized
INFO - 2022-11-29 10:28:01 --> Security Class Initialized
DEBUG - 2022-11-29 10:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:28:01 --> Input Class Initialized
INFO - 2022-11-29 10:28:01 --> Language Class Initialized
INFO - 2022-11-29 10:28:01 --> Loader Class Initialized
INFO - 2022-11-29 10:28:01 --> Helper loaded: url_helper
INFO - 2022-11-29 10:28:01 --> Database Driver Class Initialized
INFO - 2022-11-29 10:28:01 --> Helper loaded: form_helper
INFO - 2022-11-29 10:28:01 --> Form Validation Class Initialized
INFO - 2022-11-29 10:28:01 --> Controller Class Initialized
INFO - 2022-11-29 10:28:01 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:28:01 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:28:01 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
ERROR - 2022-11-29 10:28:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
INFO - 2022-11-29 10:28:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:28:01 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:28:55 --> Config Class Initialized
INFO - 2022-11-29 10:28:55 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:28:55 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:28:55 --> Utf8 Class Initialized
INFO - 2022-11-29 10:28:55 --> URI Class Initialized
INFO - 2022-11-29 10:28:55 --> Router Class Initialized
INFO - 2022-11-29 10:28:55 --> Output Class Initialized
INFO - 2022-11-29 10:28:55 --> Security Class Initialized
DEBUG - 2022-11-29 10:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:28:55 --> Input Class Initialized
INFO - 2022-11-29 10:28:55 --> Language Class Initialized
INFO - 2022-11-29 10:28:55 --> Loader Class Initialized
INFO - 2022-11-29 10:28:55 --> Helper loaded: url_helper
INFO - 2022-11-29 10:28:55 --> Database Driver Class Initialized
INFO - 2022-11-29 10:28:55 --> Helper loaded: form_helper
INFO - 2022-11-29 10:28:55 --> Form Validation Class Initialized
INFO - 2022-11-29 10:28:55 --> Controller Class Initialized
INFO - 2022-11-29 10:28:55 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:28:55 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:28:55 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 10:28:55 --> Final output sent to browser
DEBUG - 2022-11-29 10:28:55 --> Total execution time: 0.1108
INFO - 2022-11-29 10:28:59 --> Config Class Initialized
INFO - 2022-11-29 10:28:59 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:28:59 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:28:59 --> Utf8 Class Initialized
INFO - 2022-11-29 10:28:59 --> URI Class Initialized
INFO - 2022-11-29 10:28:59 --> Router Class Initialized
INFO - 2022-11-29 10:28:59 --> Output Class Initialized
INFO - 2022-11-29 10:28:59 --> Security Class Initialized
DEBUG - 2022-11-29 10:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:28:59 --> Input Class Initialized
INFO - 2022-11-29 10:28:59 --> Language Class Initialized
INFO - 2022-11-29 10:28:59 --> Loader Class Initialized
INFO - 2022-11-29 10:28:59 --> Helper loaded: url_helper
INFO - 2022-11-29 10:28:59 --> Database Driver Class Initialized
INFO - 2022-11-29 10:28:59 --> Helper loaded: form_helper
INFO - 2022-11-29 10:28:59 --> Form Validation Class Initialized
INFO - 2022-11-29 10:28:59 --> Controller Class Initialized
INFO - 2022-11-29 10:28:59 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:28:59 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:28:59 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 10:28:59 --> Final output sent to browser
DEBUG - 2022-11-29 10:28:59 --> Total execution time: 0.0953
INFO - 2022-11-29 10:29:37 --> Config Class Initialized
INFO - 2022-11-29 10:29:37 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:29:37 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:29:37 --> Utf8 Class Initialized
INFO - 2022-11-29 10:29:37 --> URI Class Initialized
INFO - 2022-11-29 10:29:37 --> Router Class Initialized
INFO - 2022-11-29 10:29:37 --> Output Class Initialized
INFO - 2022-11-29 10:29:37 --> Security Class Initialized
DEBUG - 2022-11-29 10:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:29:37 --> Input Class Initialized
INFO - 2022-11-29 10:29:37 --> Language Class Initialized
INFO - 2022-11-29 10:29:37 --> Loader Class Initialized
INFO - 2022-11-29 10:29:37 --> Helper loaded: url_helper
INFO - 2022-11-29 10:29:37 --> Database Driver Class Initialized
INFO - 2022-11-29 10:29:37 --> Helper loaded: form_helper
INFO - 2022-11-29 10:29:37 --> Form Validation Class Initialized
INFO - 2022-11-29 10:29:37 --> Controller Class Initialized
INFO - 2022-11-29 10:29:37 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:29:37 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:29:37 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
ERROR - 2022-11-29 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
INFO - 2022-11-29 10:29:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:29:37 --> Severity: error --> Exception: Column 'tersedia' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:30:51 --> Config Class Initialized
INFO - 2022-11-29 10:30:51 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:30:51 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:30:51 --> Utf8 Class Initialized
INFO - 2022-11-29 10:30:51 --> URI Class Initialized
INFO - 2022-11-29 10:30:51 --> Router Class Initialized
INFO - 2022-11-29 10:30:51 --> Output Class Initialized
INFO - 2022-11-29 10:30:51 --> Security Class Initialized
DEBUG - 2022-11-29 10:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:30:51 --> Input Class Initialized
INFO - 2022-11-29 10:30:51 --> Language Class Initialized
INFO - 2022-11-29 10:30:51 --> Loader Class Initialized
INFO - 2022-11-29 10:30:51 --> Helper loaded: url_helper
INFO - 2022-11-29 10:30:51 --> Database Driver Class Initialized
INFO - 2022-11-29 10:30:51 --> Helper loaded: form_helper
INFO - 2022-11-29 10:30:51 --> Form Validation Class Initialized
INFO - 2022-11-29 10:30:51 --> Controller Class Initialized
INFO - 2022-11-29 10:30:51 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:30:51 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:30:51 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
ERROR - 2022-11-29 10:30:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 55
INFO - 2022-11-29 10:30:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:30:51 --> Severity: error --> Exception: Column 'tersedia' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:32:03 --> Config Class Initialized
INFO - 2022-11-29 10:32:03 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:32:03 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:32:03 --> Utf8 Class Initialized
INFO - 2022-11-29 10:32:03 --> URI Class Initialized
INFO - 2022-11-29 10:32:03 --> Router Class Initialized
INFO - 2022-11-29 10:32:03 --> Output Class Initialized
INFO - 2022-11-29 10:32:03 --> Security Class Initialized
DEBUG - 2022-11-29 10:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:32:03 --> Input Class Initialized
INFO - 2022-11-29 10:32:03 --> Language Class Initialized
INFO - 2022-11-29 10:32:03 --> Loader Class Initialized
INFO - 2022-11-29 10:32:03 --> Helper loaded: url_helper
INFO - 2022-11-29 10:32:03 --> Database Driver Class Initialized
INFO - 2022-11-29 10:32:03 --> Helper loaded: form_helper
INFO - 2022-11-29 10:32:03 --> Form Validation Class Initialized
INFO - 2022-11-29 10:32:03 --> Controller Class Initialized
INFO - 2022-11-29 10:32:03 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:32:03 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:32:03 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
ERROR - 2022-11-29 10:32:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
INFO - 2022-11-29 10:32:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:32:03 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:32:08 --> Config Class Initialized
INFO - 2022-11-29 10:32:08 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:32:08 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:32:08 --> Utf8 Class Initialized
INFO - 2022-11-29 10:32:08 --> URI Class Initialized
INFO - 2022-11-29 10:32:08 --> Router Class Initialized
INFO - 2022-11-29 10:32:08 --> Output Class Initialized
INFO - 2022-11-29 10:32:08 --> Security Class Initialized
DEBUG - 2022-11-29 10:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:32:08 --> Input Class Initialized
INFO - 2022-11-29 10:32:08 --> Language Class Initialized
INFO - 2022-11-29 10:32:08 --> Loader Class Initialized
INFO - 2022-11-29 10:32:08 --> Helper loaded: url_helper
INFO - 2022-11-29 10:32:08 --> Database Driver Class Initialized
INFO - 2022-11-29 10:32:08 --> Helper loaded: form_helper
INFO - 2022-11-29 10:32:08 --> Form Validation Class Initialized
INFO - 2022-11-29 10:32:08 --> Controller Class Initialized
INFO - 2022-11-29 10:32:08 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:32:08 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:32:08 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 10:32:08 --> Final output sent to browser
DEBUG - 2022-11-29 10:32:08 --> Total execution time: 0.0641
INFO - 2022-11-29 10:32:22 --> Config Class Initialized
INFO - 2022-11-29 10:32:22 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:32:22 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:32:22 --> Utf8 Class Initialized
INFO - 2022-11-29 10:32:22 --> URI Class Initialized
INFO - 2022-11-29 10:32:23 --> Router Class Initialized
INFO - 2022-11-29 10:32:23 --> Output Class Initialized
INFO - 2022-11-29 10:32:23 --> Security Class Initialized
DEBUG - 2022-11-29 10:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:32:23 --> Input Class Initialized
INFO - 2022-11-29 10:32:23 --> Language Class Initialized
INFO - 2022-11-29 10:32:23 --> Loader Class Initialized
INFO - 2022-11-29 10:32:23 --> Helper loaded: url_helper
INFO - 2022-11-29 10:32:23 --> Database Driver Class Initialized
INFO - 2022-11-29 10:32:23 --> Helper loaded: form_helper
INFO - 2022-11-29 10:32:23 --> Form Validation Class Initialized
INFO - 2022-11-29 10:32:23 --> Controller Class Initialized
INFO - 2022-11-29 10:32:23 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:32:23 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:32:23 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
ERROR - 2022-11-29 10:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
INFO - 2022-11-29 10:32:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:32:23 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:33:19 --> Config Class Initialized
INFO - 2022-11-29 10:33:19 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:33:19 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:33:19 --> Utf8 Class Initialized
INFO - 2022-11-29 10:33:19 --> URI Class Initialized
INFO - 2022-11-29 10:33:19 --> Router Class Initialized
INFO - 2022-11-29 10:33:19 --> Output Class Initialized
INFO - 2022-11-29 10:33:19 --> Security Class Initialized
DEBUG - 2022-11-29 10:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:33:19 --> Input Class Initialized
INFO - 2022-11-29 10:33:19 --> Language Class Initialized
INFO - 2022-11-29 10:33:19 --> Loader Class Initialized
INFO - 2022-11-29 10:33:19 --> Helper loaded: url_helper
INFO - 2022-11-29 10:33:19 --> Database Driver Class Initialized
INFO - 2022-11-29 10:33:19 --> Helper loaded: form_helper
INFO - 2022-11-29 10:33:19 --> Form Validation Class Initialized
INFO - 2022-11-29 10:33:19 --> Controller Class Initialized
INFO - 2022-11-29 10:33:19 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:33:19 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:33:19 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
ERROR - 2022-11-29 10:33:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
INFO - 2022-11-29 10:33:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:33:19 --> Severity: error --> Exception: Column 'tersedia' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:33:23 --> Config Class Initialized
INFO - 2022-11-29 10:33:23 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:33:23 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:33:23 --> Utf8 Class Initialized
INFO - 2022-11-29 10:33:23 --> URI Class Initialized
INFO - 2022-11-29 10:33:23 --> Router Class Initialized
INFO - 2022-11-29 10:33:23 --> Output Class Initialized
INFO - 2022-11-29 10:33:23 --> Security Class Initialized
DEBUG - 2022-11-29 10:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:33:23 --> Input Class Initialized
INFO - 2022-11-29 10:33:23 --> Language Class Initialized
INFO - 2022-11-29 10:33:23 --> Loader Class Initialized
INFO - 2022-11-29 10:33:23 --> Helper loaded: url_helper
INFO - 2022-11-29 10:33:23 --> Database Driver Class Initialized
INFO - 2022-11-29 10:33:23 --> Helper loaded: form_helper
INFO - 2022-11-29 10:33:23 --> Form Validation Class Initialized
INFO - 2022-11-29 10:33:23 --> Controller Class Initialized
INFO - 2022-11-29 10:33:23 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:33:23 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:33:23 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 10:33:23 --> Final output sent to browser
DEBUG - 2022-11-29 10:33:23 --> Total execution time: 0.0790
INFO - 2022-11-29 10:33:47 --> Config Class Initialized
INFO - 2022-11-29 10:33:47 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:33:47 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:33:47 --> Utf8 Class Initialized
INFO - 2022-11-29 10:33:47 --> URI Class Initialized
INFO - 2022-11-29 10:33:47 --> Router Class Initialized
INFO - 2022-11-29 10:33:47 --> Output Class Initialized
INFO - 2022-11-29 10:33:47 --> Security Class Initialized
DEBUG - 2022-11-29 10:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:33:47 --> Input Class Initialized
INFO - 2022-11-29 10:33:47 --> Language Class Initialized
INFO - 2022-11-29 10:33:47 --> Loader Class Initialized
INFO - 2022-11-29 10:33:47 --> Helper loaded: url_helper
INFO - 2022-11-29 10:33:47 --> Database Driver Class Initialized
INFO - 2022-11-29 10:33:47 --> Helper loaded: form_helper
INFO - 2022-11-29 10:33:47 --> Form Validation Class Initialized
INFO - 2022-11-29 10:33:47 --> Controller Class Initialized
INFO - 2022-11-29 10:33:47 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:33:47 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:33:47 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 10:33:47 --> Final output sent to browser
DEBUG - 2022-11-29 10:33:47 --> Total execution time: 0.0797
INFO - 2022-11-29 10:33:56 --> Config Class Initialized
INFO - 2022-11-29 10:33:56 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:33:56 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:33:56 --> Utf8 Class Initialized
INFO - 2022-11-29 10:33:56 --> URI Class Initialized
INFO - 2022-11-29 10:33:56 --> Router Class Initialized
INFO - 2022-11-29 10:33:56 --> Output Class Initialized
INFO - 2022-11-29 10:33:56 --> Security Class Initialized
DEBUG - 2022-11-29 10:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:33:56 --> Input Class Initialized
INFO - 2022-11-29 10:33:56 --> Language Class Initialized
INFO - 2022-11-29 10:33:56 --> Loader Class Initialized
INFO - 2022-11-29 10:33:56 --> Helper loaded: url_helper
INFO - 2022-11-29 10:33:56 --> Database Driver Class Initialized
INFO - 2022-11-29 10:33:56 --> Helper loaded: form_helper
INFO - 2022-11-29 10:33:56 --> Form Validation Class Initialized
INFO - 2022-11-29 10:33:56 --> Controller Class Initialized
INFO - 2022-11-29 10:33:56 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:33:56 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:33:56 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
ERROR - 2022-11-29 10:33:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
INFO - 2022-11-29 10:33:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:33:56 --> Severity: error --> Exception: Column 'tersedia' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:37:49 --> Config Class Initialized
INFO - 2022-11-29 10:37:49 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:37:49 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:37:49 --> Utf8 Class Initialized
INFO - 2022-11-29 10:37:49 --> URI Class Initialized
INFO - 2022-11-29 10:37:49 --> Router Class Initialized
INFO - 2022-11-29 10:37:49 --> Output Class Initialized
INFO - 2022-11-29 10:37:49 --> Security Class Initialized
DEBUG - 2022-11-29 10:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:37:49 --> Input Class Initialized
INFO - 2022-11-29 10:37:49 --> Language Class Initialized
INFO - 2022-11-29 10:37:49 --> Loader Class Initialized
INFO - 2022-11-29 10:37:49 --> Helper loaded: url_helper
INFO - 2022-11-29 10:37:49 --> Database Driver Class Initialized
INFO - 2022-11-29 10:37:49 --> Helper loaded: form_helper
INFO - 2022-11-29 10:37:49 --> Form Validation Class Initialized
INFO - 2022-11-29 10:37:49 --> Controller Class Initialized
INFO - 2022-11-29 10:37:49 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:37:49 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:37:49 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 10:37:49 --> Final output sent to browser
DEBUG - 2022-11-29 10:37:49 --> Total execution time: 0.0788
INFO - 2022-11-29 10:37:53 --> Config Class Initialized
INFO - 2022-11-29 10:37:53 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:37:53 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:37:53 --> Utf8 Class Initialized
INFO - 2022-11-29 10:37:53 --> URI Class Initialized
INFO - 2022-11-29 10:37:53 --> Router Class Initialized
INFO - 2022-11-29 10:37:54 --> Output Class Initialized
INFO - 2022-11-29 10:37:54 --> Security Class Initialized
DEBUG - 2022-11-29 10:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:37:54 --> Input Class Initialized
INFO - 2022-11-29 10:37:54 --> Language Class Initialized
INFO - 2022-11-29 10:37:54 --> Loader Class Initialized
INFO - 2022-11-29 10:37:54 --> Helper loaded: url_helper
INFO - 2022-11-29 10:37:54 --> Database Driver Class Initialized
INFO - 2022-11-29 10:37:54 --> Helper loaded: form_helper
INFO - 2022-11-29 10:37:54 --> Form Validation Class Initialized
INFO - 2022-11-29 10:37:54 --> Controller Class Initialized
INFO - 2022-11-29 10:37:54 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:37:54 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:37:54 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 10:37:54 --> Final output sent to browser
DEBUG - 2022-11-29 10:37:54 --> Total execution time: 0.0611
INFO - 2022-11-29 10:38:04 --> Config Class Initialized
INFO - 2022-11-29 10:38:04 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:38:04 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:38:04 --> Utf8 Class Initialized
INFO - 2022-11-29 10:38:04 --> URI Class Initialized
INFO - 2022-11-29 10:38:04 --> Router Class Initialized
INFO - 2022-11-29 10:38:04 --> Output Class Initialized
INFO - 2022-11-29 10:38:04 --> Security Class Initialized
DEBUG - 2022-11-29 10:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:38:04 --> Input Class Initialized
INFO - 2022-11-29 10:38:04 --> Language Class Initialized
INFO - 2022-11-29 10:38:04 --> Loader Class Initialized
INFO - 2022-11-29 10:38:04 --> Helper loaded: url_helper
INFO - 2022-11-29 10:38:04 --> Database Driver Class Initialized
INFO - 2022-11-29 10:38:04 --> Helper loaded: form_helper
INFO - 2022-11-29 10:38:04 --> Form Validation Class Initialized
INFO - 2022-11-29 10:38:04 --> Controller Class Initialized
INFO - 2022-11-29 10:38:04 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:38:04 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:38:04 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
ERROR - 2022-11-29 10:38:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
INFO - 2022-11-29 10:38:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-11-29 10:38:04 --> Config Class Initialized
INFO - 2022-11-29 10:38:04 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:38:04 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:38:04 --> Utf8 Class Initialized
INFO - 2022-11-29 10:38:04 --> URI Class Initialized
INFO - 2022-11-29 10:38:04 --> Router Class Initialized
INFO - 2022-11-29 10:38:04 --> Output Class Initialized
INFO - 2022-11-29 10:38:04 --> Security Class Initialized
DEBUG - 2022-11-29 10:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:38:04 --> Input Class Initialized
INFO - 2022-11-29 10:38:04 --> Language Class Initialized
INFO - 2022-11-29 10:38:04 --> Loader Class Initialized
INFO - 2022-11-29 10:38:04 --> Helper loaded: url_helper
INFO - 2022-11-29 10:38:04 --> Database Driver Class Initialized
INFO - 2022-11-29 10:38:04 --> Helper loaded: form_helper
INFO - 2022-11-29 10:38:04 --> Form Validation Class Initialized
INFO - 2022-11-29 10:38:04 --> Controller Class Initialized
INFO - 2022-11-29 10:38:04 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:38:04 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:38:04 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 10:38:04 --> Final output sent to browser
DEBUG - 2022-11-29 10:38:04 --> Total execution time: 0.0660
INFO - 2022-11-29 10:38:08 --> Config Class Initialized
INFO - 2022-11-29 10:38:08 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:38:08 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:38:08 --> Utf8 Class Initialized
INFO - 2022-11-29 10:38:08 --> URI Class Initialized
INFO - 2022-11-29 10:38:08 --> Router Class Initialized
INFO - 2022-11-29 10:38:08 --> Output Class Initialized
INFO - 2022-11-29 10:38:08 --> Security Class Initialized
DEBUG - 2022-11-29 10:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:38:08 --> Input Class Initialized
INFO - 2022-11-29 10:38:08 --> Language Class Initialized
INFO - 2022-11-29 10:38:08 --> Loader Class Initialized
INFO - 2022-11-29 10:38:08 --> Helper loaded: url_helper
INFO - 2022-11-29 10:38:08 --> Database Driver Class Initialized
INFO - 2022-11-29 10:38:08 --> Helper loaded: form_helper
INFO - 2022-11-29 10:38:08 --> Form Validation Class Initialized
INFO - 2022-11-29 10:38:08 --> Controller Class Initialized
INFO - 2022-11-29 10:38:08 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:38:08 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:38:08 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 10:38:08 --> Final output sent to browser
DEBUG - 2022-11-29 10:38:08 --> Total execution time: 0.0595
INFO - 2022-11-29 10:38:26 --> Config Class Initialized
INFO - 2022-11-29 10:38:26 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:38:26 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:38:26 --> Utf8 Class Initialized
INFO - 2022-11-29 10:38:26 --> URI Class Initialized
INFO - 2022-11-29 10:38:26 --> Router Class Initialized
INFO - 2022-11-29 10:38:26 --> Output Class Initialized
INFO - 2022-11-29 10:38:26 --> Security Class Initialized
DEBUG - 2022-11-29 10:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:38:26 --> Input Class Initialized
INFO - 2022-11-29 10:38:26 --> Language Class Initialized
INFO - 2022-11-29 10:38:26 --> Loader Class Initialized
INFO - 2022-11-29 10:38:26 --> Helper loaded: url_helper
INFO - 2022-11-29 10:38:26 --> Database Driver Class Initialized
INFO - 2022-11-29 10:38:26 --> Helper loaded: form_helper
INFO - 2022-11-29 10:38:26 --> Form Validation Class Initialized
INFO - 2022-11-29 10:38:26 --> Controller Class Initialized
INFO - 2022-11-29 10:38:26 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:38:26 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:38:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 10:38:26 --> Final output sent to browser
DEBUG - 2022-11-29 10:38:26 --> Total execution time: 0.0714
INFO - 2022-11-29 10:38:41 --> Config Class Initialized
INFO - 2022-11-29 10:38:41 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:38:41 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:38:41 --> Utf8 Class Initialized
INFO - 2022-11-29 10:38:41 --> URI Class Initialized
INFO - 2022-11-29 10:38:41 --> Router Class Initialized
INFO - 2022-11-29 10:38:41 --> Output Class Initialized
INFO - 2022-11-29 10:38:41 --> Security Class Initialized
DEBUG - 2022-11-29 10:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:38:41 --> Input Class Initialized
INFO - 2022-11-29 10:38:41 --> Language Class Initialized
INFO - 2022-11-29 10:38:41 --> Loader Class Initialized
INFO - 2022-11-29 10:38:41 --> Helper loaded: url_helper
INFO - 2022-11-29 10:38:41 --> Database Driver Class Initialized
INFO - 2022-11-29 10:38:41 --> Helper loaded: form_helper
INFO - 2022-11-29 10:38:41 --> Form Validation Class Initialized
INFO - 2022-11-29 10:38:41 --> Controller Class Initialized
INFO - 2022-11-29 10:38:41 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:38:41 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:38:41 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
ERROR - 2022-11-29 10:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
INFO - 2022-11-29 10:38:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:38:41 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:40:13 --> Config Class Initialized
INFO - 2022-11-29 10:40:13 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:40:13 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:40:13 --> Utf8 Class Initialized
INFO - 2022-11-29 10:40:13 --> URI Class Initialized
INFO - 2022-11-29 10:40:13 --> Router Class Initialized
INFO - 2022-11-29 10:40:13 --> Output Class Initialized
INFO - 2022-11-29 10:40:13 --> Security Class Initialized
DEBUG - 2022-11-29 10:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:40:13 --> Input Class Initialized
INFO - 2022-11-29 10:40:13 --> Language Class Initialized
INFO - 2022-11-29 10:40:13 --> Loader Class Initialized
INFO - 2022-11-29 10:40:13 --> Helper loaded: url_helper
INFO - 2022-11-29 10:40:13 --> Database Driver Class Initialized
INFO - 2022-11-29 10:40:13 --> Helper loaded: form_helper
INFO - 2022-11-29 10:40:13 --> Form Validation Class Initialized
INFO - 2022-11-29 10:40:13 --> Controller Class Initialized
INFO - 2022-11-29 10:40:13 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:40:13 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:40:13 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
ERROR - 2022-11-29 10:40:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
INFO - 2022-11-29 10:40:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-11-29 10:40:13 --> Severity: error --> Exception: Column 'gambar' cannot be null C:\xampp\htdocs\ekatalog\system\database\drivers\mysqli\mysqli_driver.php 305
INFO - 2022-11-29 10:40:25 --> Config Class Initialized
INFO - 2022-11-29 10:40:25 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:40:25 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:40:25 --> Utf8 Class Initialized
INFO - 2022-11-29 10:40:25 --> URI Class Initialized
INFO - 2022-11-29 10:40:25 --> Router Class Initialized
INFO - 2022-11-29 10:40:25 --> Output Class Initialized
INFO - 2022-11-29 10:40:25 --> Security Class Initialized
DEBUG - 2022-11-29 10:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:40:25 --> Input Class Initialized
INFO - 2022-11-29 10:40:26 --> Language Class Initialized
INFO - 2022-11-29 10:40:26 --> Loader Class Initialized
INFO - 2022-11-29 10:40:26 --> Helper loaded: url_helper
INFO - 2022-11-29 10:40:26 --> Database Driver Class Initialized
INFO - 2022-11-29 10:40:26 --> Helper loaded: form_helper
INFO - 2022-11-29 10:40:26 --> Form Validation Class Initialized
INFO - 2022-11-29 10:40:26 --> Controller Class Initialized
INFO - 2022-11-29 10:40:26 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:40:26 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:40:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 10:40:26 --> Final output sent to browser
DEBUG - 2022-11-29 10:40:26 --> Total execution time: 0.0627
INFO - 2022-11-29 10:40:33 --> Config Class Initialized
INFO - 2022-11-29 10:40:33 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:40:33 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:40:33 --> Utf8 Class Initialized
INFO - 2022-11-29 10:40:33 --> URI Class Initialized
INFO - 2022-11-29 10:40:33 --> Router Class Initialized
INFO - 2022-11-29 10:40:33 --> Output Class Initialized
INFO - 2022-11-29 10:40:33 --> Security Class Initialized
DEBUG - 2022-11-29 10:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:40:33 --> Input Class Initialized
INFO - 2022-11-29 10:40:33 --> Language Class Initialized
INFO - 2022-11-29 10:40:33 --> Loader Class Initialized
INFO - 2022-11-29 10:40:33 --> Helper loaded: url_helper
INFO - 2022-11-29 10:40:33 --> Database Driver Class Initialized
INFO - 2022-11-29 10:40:33 --> Helper loaded: form_helper
INFO - 2022-11-29 10:40:33 --> Form Validation Class Initialized
INFO - 2022-11-29 10:40:33 --> Controller Class Initialized
INFO - 2022-11-29 10:40:33 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:40:33 --> Model "Penerbit_model" initialized
ERROR - 2022-11-29 10:40:33 --> Severity: Warning --> Undefined array key "gambar" C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
ERROR - 2022-11-29 10:40:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ekatalog\application\controllers\Buku.php 56
INFO - 2022-11-29 10:40:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-11-29 10:40:33 --> Config Class Initialized
INFO - 2022-11-29 10:40:33 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:40:33 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:40:33 --> Utf8 Class Initialized
INFO - 2022-11-29 10:40:33 --> URI Class Initialized
INFO - 2022-11-29 10:40:33 --> Router Class Initialized
INFO - 2022-11-29 10:40:33 --> Output Class Initialized
INFO - 2022-11-29 10:40:33 --> Security Class Initialized
DEBUG - 2022-11-29 10:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:40:33 --> Input Class Initialized
INFO - 2022-11-29 10:40:33 --> Language Class Initialized
INFO - 2022-11-29 10:40:33 --> Loader Class Initialized
INFO - 2022-11-29 10:40:33 --> Helper loaded: url_helper
INFO - 2022-11-29 10:40:33 --> Database Driver Class Initialized
INFO - 2022-11-29 10:40:33 --> Helper loaded: form_helper
INFO - 2022-11-29 10:40:33 --> Form Validation Class Initialized
INFO - 2022-11-29 10:40:33 --> Controller Class Initialized
INFO - 2022-11-29 10:40:33 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:40:33 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:40:33 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 10:40:33 --> Final output sent to browser
DEBUG - 2022-11-29 10:40:33 --> Total execution time: 0.0576
INFO - 2022-11-29 10:40:40 --> Config Class Initialized
INFO - 2022-11-29 10:40:40 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:40:40 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:40:40 --> Utf8 Class Initialized
INFO - 2022-11-29 10:40:40 --> URI Class Initialized
INFO - 2022-11-29 10:40:40 --> Router Class Initialized
INFO - 2022-11-29 10:40:40 --> Output Class Initialized
INFO - 2022-11-29 10:40:40 --> Security Class Initialized
DEBUG - 2022-11-29 10:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:40:40 --> Input Class Initialized
INFO - 2022-11-29 10:40:40 --> Language Class Initialized
INFO - 2022-11-29 10:40:40 --> Loader Class Initialized
INFO - 2022-11-29 10:40:40 --> Helper loaded: url_helper
INFO - 2022-11-29 10:40:40 --> Database Driver Class Initialized
INFO - 2022-11-29 10:40:40 --> Helper loaded: form_helper
INFO - 2022-11-29 10:40:40 --> Form Validation Class Initialized
INFO - 2022-11-29 10:40:40 --> Controller Class Initialized
INFO - 2022-11-29 10:40:40 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:40:40 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:40:40 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 10:40:40 --> Final output sent to browser
DEBUG - 2022-11-29 10:40:40 --> Total execution time: 0.0510
INFO - 2022-11-29 10:43:51 --> Config Class Initialized
INFO - 2022-11-29 10:43:51 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:43:51 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:43:51 --> Utf8 Class Initialized
INFO - 2022-11-29 10:43:51 --> URI Class Initialized
INFO - 2022-11-29 10:43:51 --> Router Class Initialized
INFO - 2022-11-29 10:43:51 --> Output Class Initialized
INFO - 2022-11-29 10:43:51 --> Security Class Initialized
DEBUG - 2022-11-29 10:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:43:51 --> Input Class Initialized
INFO - 2022-11-29 10:43:51 --> Language Class Initialized
INFO - 2022-11-29 10:43:51 --> Loader Class Initialized
INFO - 2022-11-29 10:43:51 --> Helper loaded: url_helper
INFO - 2022-11-29 10:43:51 --> Database Driver Class Initialized
INFO - 2022-11-29 10:43:51 --> Helper loaded: form_helper
INFO - 2022-11-29 10:43:51 --> Form Validation Class Initialized
INFO - 2022-11-29 10:43:51 --> Controller Class Initialized
INFO - 2022-11-29 10:43:51 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:43:51 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:43:51 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 10:43:51 --> Final output sent to browser
DEBUG - 2022-11-29 10:43:51 --> Total execution time: 0.0613
INFO - 2022-11-29 10:44:34 --> Config Class Initialized
INFO - 2022-11-29 10:44:34 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:44:34 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:44:34 --> Utf8 Class Initialized
INFO - 2022-11-29 10:44:34 --> URI Class Initialized
INFO - 2022-11-29 10:44:34 --> Router Class Initialized
INFO - 2022-11-29 10:44:34 --> Output Class Initialized
INFO - 2022-11-29 10:44:34 --> Security Class Initialized
DEBUG - 2022-11-29 10:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:44:34 --> Input Class Initialized
INFO - 2022-11-29 10:44:34 --> Language Class Initialized
INFO - 2022-11-29 10:44:34 --> Loader Class Initialized
INFO - 2022-11-29 10:44:34 --> Helper loaded: url_helper
INFO - 2022-11-29 10:44:34 --> Database Driver Class Initialized
INFO - 2022-11-29 10:44:34 --> Helper loaded: form_helper
INFO - 2022-11-29 10:44:34 --> Form Validation Class Initialized
INFO - 2022-11-29 10:44:34 --> Controller Class Initialized
INFO - 2022-11-29 10:44:34 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:44:34 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:44:34 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 10:44:34 --> Final output sent to browser
DEBUG - 2022-11-29 10:44:34 --> Total execution time: 0.0905
INFO - 2022-11-29 10:45:22 --> Config Class Initialized
INFO - 2022-11-29 10:45:22 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:45:22 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:45:22 --> Utf8 Class Initialized
INFO - 2022-11-29 10:45:22 --> URI Class Initialized
INFO - 2022-11-29 10:45:22 --> Router Class Initialized
INFO - 2022-11-29 10:45:22 --> Output Class Initialized
INFO - 2022-11-29 10:45:22 --> Security Class Initialized
DEBUG - 2022-11-29 10:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:45:22 --> Input Class Initialized
INFO - 2022-11-29 10:45:22 --> Language Class Initialized
INFO - 2022-11-29 10:45:22 --> Loader Class Initialized
INFO - 2022-11-29 10:45:22 --> Helper loaded: url_helper
INFO - 2022-11-29 10:45:22 --> Database Driver Class Initialized
INFO - 2022-11-29 10:45:22 --> Helper loaded: form_helper
INFO - 2022-11-29 10:45:22 --> Form Validation Class Initialized
INFO - 2022-11-29 10:45:22 --> Controller Class Initialized
INFO - 2022-11-29 10:45:23 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:45:23 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:45:23 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 10:45:23 --> Final output sent to browser
DEBUG - 2022-11-29 10:45:23 --> Total execution time: 0.0343
INFO - 2022-11-29 10:52:59 --> Config Class Initialized
INFO - 2022-11-29 10:52:59 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:52:59 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:52:59 --> Utf8 Class Initialized
INFO - 2022-11-29 10:52:59 --> URI Class Initialized
INFO - 2022-11-29 10:52:59 --> Router Class Initialized
INFO - 2022-11-29 10:52:59 --> Output Class Initialized
INFO - 2022-11-29 10:52:59 --> Security Class Initialized
DEBUG - 2022-11-29 10:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:52:59 --> Input Class Initialized
INFO - 2022-11-29 10:52:59 --> Language Class Initialized
INFO - 2022-11-29 10:52:59 --> Loader Class Initialized
INFO - 2022-11-29 10:52:59 --> Helper loaded: url_helper
INFO - 2022-11-29 10:52:59 --> Database Driver Class Initialized
INFO - 2022-11-29 10:52:59 --> Helper loaded: form_helper
INFO - 2022-11-29 10:52:59 --> Form Validation Class Initialized
INFO - 2022-11-29 10:52:59 --> Controller Class Initialized
INFO - 2022-11-29 10:52:59 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:52:59 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:52:59 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 10:52:59 --> Final output sent to browser
DEBUG - 2022-11-29 10:52:59 --> Total execution time: 0.0454
INFO - 2022-11-29 10:53:00 --> Config Class Initialized
INFO - 2022-11-29 10:53:00 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:53:00 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:53:00 --> Utf8 Class Initialized
INFO - 2022-11-29 10:53:00 --> URI Class Initialized
INFO - 2022-11-29 10:53:00 --> Router Class Initialized
INFO - 2022-11-29 10:53:00 --> Output Class Initialized
INFO - 2022-11-29 10:53:00 --> Security Class Initialized
DEBUG - 2022-11-29 10:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:53:00 --> Input Class Initialized
INFO - 2022-11-29 10:53:00 --> Language Class Initialized
INFO - 2022-11-29 10:53:00 --> Loader Class Initialized
INFO - 2022-11-29 10:53:00 --> Helper loaded: url_helper
INFO - 2022-11-29 10:53:00 --> Database Driver Class Initialized
INFO - 2022-11-29 10:53:00 --> Helper loaded: form_helper
INFO - 2022-11-29 10:53:00 --> Form Validation Class Initialized
INFO - 2022-11-29 10:53:00 --> Controller Class Initialized
INFO - 2022-11-29 10:53:00 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:53:00 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:53:00 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 10:53:00 --> Final output sent to browser
DEBUG - 2022-11-29 10:53:00 --> Total execution time: 0.0528
INFO - 2022-11-29 10:53:46 --> Config Class Initialized
INFO - 2022-11-29 10:53:46 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:53:46 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:53:46 --> Utf8 Class Initialized
INFO - 2022-11-29 10:53:46 --> URI Class Initialized
INFO - 2022-11-29 10:53:46 --> Router Class Initialized
INFO - 2022-11-29 10:53:46 --> Output Class Initialized
INFO - 2022-11-29 10:53:46 --> Security Class Initialized
DEBUG - 2022-11-29 10:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:53:46 --> Input Class Initialized
INFO - 2022-11-29 10:53:46 --> Language Class Initialized
INFO - 2022-11-29 10:53:46 --> Loader Class Initialized
INFO - 2022-11-29 10:53:46 --> Helper loaded: url_helper
INFO - 2022-11-29 10:53:46 --> Database Driver Class Initialized
INFO - 2022-11-29 10:53:46 --> Helper loaded: form_helper
INFO - 2022-11-29 10:53:46 --> Form Validation Class Initialized
INFO - 2022-11-29 10:53:46 --> Controller Class Initialized
INFO - 2022-11-29 10:53:46 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:53:46 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:53:46 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 10:53:46 --> Final output sent to browser
DEBUG - 2022-11-29 10:53:46 --> Total execution time: 0.1355
INFO - 2022-11-29 10:54:25 --> Config Class Initialized
INFO - 2022-11-29 10:54:25 --> Hooks Class Initialized
DEBUG - 2022-11-29 10:54:25 --> UTF-8 Support Enabled
INFO - 2022-11-29 10:54:25 --> Utf8 Class Initialized
INFO - 2022-11-29 10:54:25 --> URI Class Initialized
INFO - 2022-11-29 10:54:25 --> Router Class Initialized
INFO - 2022-11-29 10:54:25 --> Output Class Initialized
INFO - 2022-11-29 10:54:25 --> Security Class Initialized
DEBUG - 2022-11-29 10:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 10:54:25 --> Input Class Initialized
INFO - 2022-11-29 10:54:25 --> Language Class Initialized
INFO - 2022-11-29 10:54:25 --> Loader Class Initialized
INFO - 2022-11-29 10:54:25 --> Helper loaded: url_helper
INFO - 2022-11-29 10:54:25 --> Database Driver Class Initialized
INFO - 2022-11-29 10:54:25 --> Helper loaded: form_helper
INFO - 2022-11-29 10:54:25 --> Form Validation Class Initialized
INFO - 2022-11-29 10:54:25 --> Controller Class Initialized
INFO - 2022-11-29 10:54:25 --> Model "Buku_model" initialized
INFO - 2022-11-29 10:54:25 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 10:54:25 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 10:54:25 --> Final output sent to browser
DEBUG - 2022-11-29 10:54:25 --> Total execution time: 0.0441
INFO - 2022-11-29 11:03:12 --> Config Class Initialized
INFO - 2022-11-29 11:03:12 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:03:12 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:03:12 --> Utf8 Class Initialized
INFO - 2022-11-29 11:03:12 --> URI Class Initialized
INFO - 2022-11-29 11:03:12 --> Router Class Initialized
INFO - 2022-11-29 11:03:12 --> Output Class Initialized
INFO - 2022-11-29 11:03:12 --> Security Class Initialized
DEBUG - 2022-11-29 11:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:03:12 --> Input Class Initialized
INFO - 2022-11-29 11:03:12 --> Language Class Initialized
INFO - 2022-11-29 11:03:12 --> Loader Class Initialized
INFO - 2022-11-29 11:03:12 --> Helper loaded: url_helper
INFO - 2022-11-29 11:03:12 --> Database Driver Class Initialized
INFO - 2022-11-29 11:03:12 --> Helper loaded: form_helper
INFO - 2022-11-29 11:03:12 --> Form Validation Class Initialized
INFO - 2022-11-29 11:03:12 --> Controller Class Initialized
INFO - 2022-11-29 11:03:12 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:03:12 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:03:12 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:03:12 --> Final output sent to browser
DEBUG - 2022-11-29 11:03:12 --> Total execution time: 0.0545
INFO - 2022-11-29 11:03:18 --> Config Class Initialized
INFO - 2022-11-29 11:03:18 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:03:18 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:03:18 --> Utf8 Class Initialized
INFO - 2022-11-29 11:03:18 --> URI Class Initialized
INFO - 2022-11-29 11:03:18 --> Router Class Initialized
INFO - 2022-11-29 11:03:18 --> Output Class Initialized
INFO - 2022-11-29 11:03:18 --> Security Class Initialized
DEBUG - 2022-11-29 11:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:03:18 --> Input Class Initialized
INFO - 2022-11-29 11:03:18 --> Language Class Initialized
INFO - 2022-11-29 11:03:18 --> Loader Class Initialized
INFO - 2022-11-29 11:03:18 --> Helper loaded: url_helper
INFO - 2022-11-29 11:03:18 --> Database Driver Class Initialized
INFO - 2022-11-29 11:03:18 --> Helper loaded: form_helper
INFO - 2022-11-29 11:03:18 --> Form Validation Class Initialized
INFO - 2022-11-29 11:03:18 --> Controller Class Initialized
INFO - 2022-11-29 11:03:18 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:03:18 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:03:18 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:03:18 --> Final output sent to browser
DEBUG - 2022-11-29 11:03:18 --> Total execution time: 0.0327
INFO - 2022-11-29 11:03:38 --> Config Class Initialized
INFO - 2022-11-29 11:03:38 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:03:38 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:03:38 --> Utf8 Class Initialized
INFO - 2022-11-29 11:03:38 --> URI Class Initialized
INFO - 2022-11-29 11:03:38 --> Router Class Initialized
INFO - 2022-11-29 11:03:38 --> Output Class Initialized
INFO - 2022-11-29 11:03:38 --> Security Class Initialized
DEBUG - 2022-11-29 11:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:03:38 --> Input Class Initialized
INFO - 2022-11-29 11:03:38 --> Language Class Initialized
INFO - 2022-11-29 11:03:38 --> Loader Class Initialized
INFO - 2022-11-29 11:03:38 --> Helper loaded: url_helper
INFO - 2022-11-29 11:03:38 --> Database Driver Class Initialized
INFO - 2022-11-29 11:03:38 --> Helper loaded: form_helper
INFO - 2022-11-29 11:03:38 --> Form Validation Class Initialized
INFO - 2022-11-29 11:03:38 --> Controller Class Initialized
INFO - 2022-11-29 11:03:38 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:03:38 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:03:38 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:03:38 --> Final output sent to browser
DEBUG - 2022-11-29 11:03:38 --> Total execution time: 0.0396
INFO - 2022-11-29 11:04:06 --> Config Class Initialized
INFO - 2022-11-29 11:04:06 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:04:06 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:04:06 --> Utf8 Class Initialized
INFO - 2022-11-29 11:04:06 --> URI Class Initialized
INFO - 2022-11-29 11:04:06 --> Router Class Initialized
INFO - 2022-11-29 11:04:06 --> Output Class Initialized
INFO - 2022-11-29 11:04:06 --> Security Class Initialized
DEBUG - 2022-11-29 11:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:04:06 --> Input Class Initialized
INFO - 2022-11-29 11:04:06 --> Language Class Initialized
INFO - 2022-11-29 11:04:06 --> Loader Class Initialized
INFO - 2022-11-29 11:04:06 --> Helper loaded: url_helper
INFO - 2022-11-29 11:04:06 --> Database Driver Class Initialized
INFO - 2022-11-29 11:04:06 --> Helper loaded: form_helper
INFO - 2022-11-29 11:04:06 --> Form Validation Class Initialized
INFO - 2022-11-29 11:04:06 --> Controller Class Initialized
INFO - 2022-11-29 11:04:06 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:04:06 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:04:06 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:04:06 --> Final output sent to browser
DEBUG - 2022-11-29 11:04:06 --> Total execution time: 0.0360
INFO - 2022-11-29 11:04:07 --> Config Class Initialized
INFO - 2022-11-29 11:04:07 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:04:07 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:04:07 --> Utf8 Class Initialized
INFO - 2022-11-29 11:04:07 --> URI Class Initialized
INFO - 2022-11-29 11:04:07 --> Router Class Initialized
INFO - 2022-11-29 11:04:07 --> Output Class Initialized
INFO - 2022-11-29 11:04:07 --> Security Class Initialized
DEBUG - 2022-11-29 11:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:04:07 --> Input Class Initialized
INFO - 2022-11-29 11:04:07 --> Language Class Initialized
INFO - 2022-11-29 11:04:07 --> Loader Class Initialized
INFO - 2022-11-29 11:04:07 --> Helper loaded: url_helper
INFO - 2022-11-29 11:04:07 --> Database Driver Class Initialized
INFO - 2022-11-29 11:04:07 --> Helper loaded: form_helper
INFO - 2022-11-29 11:04:07 --> Form Validation Class Initialized
INFO - 2022-11-29 11:04:07 --> Controller Class Initialized
INFO - 2022-11-29 11:04:07 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:04:07 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:04:07 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:04:07 --> Final output sent to browser
DEBUG - 2022-11-29 11:04:07 --> Total execution time: 0.0522
INFO - 2022-11-29 11:04:07 --> Config Class Initialized
INFO - 2022-11-29 11:04:07 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:04:07 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:04:07 --> Utf8 Class Initialized
INFO - 2022-11-29 11:04:07 --> URI Class Initialized
INFO - 2022-11-29 11:04:07 --> Router Class Initialized
INFO - 2022-11-29 11:04:07 --> Output Class Initialized
INFO - 2022-11-29 11:04:07 --> Security Class Initialized
DEBUG - 2022-11-29 11:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:04:07 --> Input Class Initialized
INFO - 2022-11-29 11:04:07 --> Language Class Initialized
INFO - 2022-11-29 11:04:07 --> Loader Class Initialized
INFO - 2022-11-29 11:04:07 --> Helper loaded: url_helper
INFO - 2022-11-29 11:04:07 --> Database Driver Class Initialized
INFO - 2022-11-29 11:04:07 --> Helper loaded: form_helper
INFO - 2022-11-29 11:04:07 --> Form Validation Class Initialized
INFO - 2022-11-29 11:04:07 --> Controller Class Initialized
INFO - 2022-11-29 11:04:07 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:04:07 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:04:07 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:04:07 --> Final output sent to browser
DEBUG - 2022-11-29 11:04:07 --> Total execution time: 0.0455
INFO - 2022-11-29 11:04:36 --> Config Class Initialized
INFO - 2022-11-29 11:04:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:04:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:04:36 --> Utf8 Class Initialized
INFO - 2022-11-29 11:04:36 --> URI Class Initialized
INFO - 2022-11-29 11:04:36 --> Router Class Initialized
INFO - 2022-11-29 11:04:36 --> Output Class Initialized
INFO - 2022-11-29 11:04:36 --> Security Class Initialized
DEBUG - 2022-11-29 11:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:04:36 --> Input Class Initialized
INFO - 2022-11-29 11:04:36 --> Language Class Initialized
INFO - 2022-11-29 11:04:36 --> Loader Class Initialized
INFO - 2022-11-29 11:04:36 --> Helper loaded: url_helper
INFO - 2022-11-29 11:04:36 --> Database Driver Class Initialized
INFO - 2022-11-29 11:04:36 --> Helper loaded: form_helper
INFO - 2022-11-29 11:04:36 --> Form Validation Class Initialized
INFO - 2022-11-29 11:04:36 --> Controller Class Initialized
INFO - 2022-11-29 11:04:36 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:04:36 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:04:36 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:04:36 --> Final output sent to browser
DEBUG - 2022-11-29 11:04:36 --> Total execution time: 0.0433
INFO - 2022-11-29 11:04:36 --> Config Class Initialized
INFO - 2022-11-29 11:04:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:04:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:04:36 --> Utf8 Class Initialized
INFO - 2022-11-29 11:04:36 --> URI Class Initialized
INFO - 2022-11-29 11:04:36 --> Router Class Initialized
INFO - 2022-11-29 11:04:36 --> Output Class Initialized
INFO - 2022-11-29 11:04:36 --> Security Class Initialized
DEBUG - 2022-11-29 11:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:04:36 --> Input Class Initialized
INFO - 2022-11-29 11:04:36 --> Language Class Initialized
INFO - 2022-11-29 11:04:36 --> Loader Class Initialized
INFO - 2022-11-29 11:04:36 --> Helper loaded: url_helper
INFO - 2022-11-29 11:04:36 --> Database Driver Class Initialized
INFO - 2022-11-29 11:04:36 --> Helper loaded: form_helper
INFO - 2022-11-29 11:04:36 --> Form Validation Class Initialized
INFO - 2022-11-29 11:04:36 --> Controller Class Initialized
INFO - 2022-11-29 11:04:36 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:04:36 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:04:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:04:37 --> Final output sent to browser
DEBUG - 2022-11-29 11:04:37 --> Total execution time: 0.0462
INFO - 2022-11-29 11:04:37 --> Config Class Initialized
INFO - 2022-11-29 11:04:37 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:04:37 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:04:37 --> Utf8 Class Initialized
INFO - 2022-11-29 11:04:37 --> URI Class Initialized
INFO - 2022-11-29 11:04:37 --> Router Class Initialized
INFO - 2022-11-29 11:04:37 --> Output Class Initialized
INFO - 2022-11-29 11:04:37 --> Security Class Initialized
DEBUG - 2022-11-29 11:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:04:37 --> Input Class Initialized
INFO - 2022-11-29 11:04:37 --> Language Class Initialized
INFO - 2022-11-29 11:04:37 --> Loader Class Initialized
INFO - 2022-11-29 11:04:37 --> Helper loaded: url_helper
INFO - 2022-11-29 11:04:37 --> Database Driver Class Initialized
INFO - 2022-11-29 11:04:37 --> Helper loaded: form_helper
INFO - 2022-11-29 11:04:37 --> Form Validation Class Initialized
INFO - 2022-11-29 11:04:37 --> Controller Class Initialized
INFO - 2022-11-29 11:04:37 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:04:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:04:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:04:37 --> Final output sent to browser
DEBUG - 2022-11-29 11:04:37 --> Total execution time: 0.0481
INFO - 2022-11-29 11:05:06 --> Config Class Initialized
INFO - 2022-11-29 11:05:06 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:05:06 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:05:06 --> Utf8 Class Initialized
INFO - 2022-11-29 11:05:06 --> URI Class Initialized
INFO - 2022-11-29 11:05:06 --> Router Class Initialized
INFO - 2022-11-29 11:05:06 --> Output Class Initialized
INFO - 2022-11-29 11:05:06 --> Security Class Initialized
DEBUG - 2022-11-29 11:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:05:07 --> Input Class Initialized
INFO - 2022-11-29 11:05:07 --> Language Class Initialized
INFO - 2022-11-29 11:05:07 --> Loader Class Initialized
INFO - 2022-11-29 11:05:07 --> Helper loaded: url_helper
INFO - 2022-11-29 11:05:07 --> Database Driver Class Initialized
INFO - 2022-11-29 11:05:07 --> Helper loaded: form_helper
INFO - 2022-11-29 11:05:07 --> Form Validation Class Initialized
INFO - 2022-11-29 11:05:07 --> Controller Class Initialized
INFO - 2022-11-29 11:05:07 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:05:07 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:05:07 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:05:07 --> Final output sent to browser
DEBUG - 2022-11-29 11:05:07 --> Total execution time: 0.0362
INFO - 2022-11-29 11:05:07 --> Config Class Initialized
INFO - 2022-11-29 11:05:07 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:05:07 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:05:07 --> Utf8 Class Initialized
INFO - 2022-11-29 11:05:07 --> URI Class Initialized
INFO - 2022-11-29 11:05:07 --> Router Class Initialized
INFO - 2022-11-29 11:05:07 --> Output Class Initialized
INFO - 2022-11-29 11:05:07 --> Security Class Initialized
DEBUG - 2022-11-29 11:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:05:07 --> Input Class Initialized
INFO - 2022-11-29 11:05:07 --> Language Class Initialized
INFO - 2022-11-29 11:05:07 --> Loader Class Initialized
INFO - 2022-11-29 11:05:07 --> Helper loaded: url_helper
INFO - 2022-11-29 11:05:07 --> Database Driver Class Initialized
INFO - 2022-11-29 11:05:07 --> Helper loaded: form_helper
INFO - 2022-11-29 11:05:07 --> Form Validation Class Initialized
INFO - 2022-11-29 11:05:07 --> Controller Class Initialized
INFO - 2022-11-29 11:05:07 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:05:07 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:05:07 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:05:07 --> Final output sent to browser
DEBUG - 2022-11-29 11:05:07 --> Total execution time: 0.0391
INFO - 2022-11-29 11:05:17 --> Config Class Initialized
INFO - 2022-11-29 11:05:17 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:05:17 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:05:17 --> Utf8 Class Initialized
INFO - 2022-11-29 11:05:17 --> URI Class Initialized
INFO - 2022-11-29 11:05:17 --> Router Class Initialized
INFO - 2022-11-29 11:05:17 --> Output Class Initialized
INFO - 2022-11-29 11:05:17 --> Security Class Initialized
DEBUG - 2022-11-29 11:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:05:17 --> Input Class Initialized
INFO - 2022-11-29 11:05:17 --> Language Class Initialized
INFO - 2022-11-29 11:05:17 --> Loader Class Initialized
INFO - 2022-11-29 11:05:17 --> Helper loaded: url_helper
INFO - 2022-11-29 11:05:17 --> Database Driver Class Initialized
INFO - 2022-11-29 11:05:17 --> Helper loaded: form_helper
INFO - 2022-11-29 11:05:17 --> Form Validation Class Initialized
INFO - 2022-11-29 11:05:17 --> Controller Class Initialized
INFO - 2022-11-29 11:05:17 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:05:17 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:05:17 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:05:17 --> Final output sent to browser
DEBUG - 2022-11-29 11:05:17 --> Total execution time: 0.0408
INFO - 2022-11-29 11:05:18 --> Config Class Initialized
INFO - 2022-11-29 11:05:18 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:05:18 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:05:18 --> Utf8 Class Initialized
INFO - 2022-11-29 11:05:18 --> URI Class Initialized
INFO - 2022-11-29 11:05:18 --> Router Class Initialized
INFO - 2022-11-29 11:05:18 --> Output Class Initialized
INFO - 2022-11-29 11:05:18 --> Security Class Initialized
DEBUG - 2022-11-29 11:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:05:18 --> Input Class Initialized
INFO - 2022-11-29 11:05:18 --> Language Class Initialized
INFO - 2022-11-29 11:05:18 --> Loader Class Initialized
INFO - 2022-11-29 11:05:18 --> Helper loaded: url_helper
INFO - 2022-11-29 11:05:18 --> Database Driver Class Initialized
INFO - 2022-11-29 11:05:18 --> Helper loaded: form_helper
INFO - 2022-11-29 11:05:18 --> Form Validation Class Initialized
INFO - 2022-11-29 11:05:18 --> Controller Class Initialized
INFO - 2022-11-29 11:05:18 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:05:18 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:05:18 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:05:18 --> Final output sent to browser
DEBUG - 2022-11-29 11:05:18 --> Total execution time: 0.0346
INFO - 2022-11-29 11:05:46 --> Config Class Initialized
INFO - 2022-11-29 11:05:46 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:05:46 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:05:46 --> Utf8 Class Initialized
INFO - 2022-11-29 11:05:46 --> URI Class Initialized
INFO - 2022-11-29 11:05:46 --> Router Class Initialized
INFO - 2022-11-29 11:05:46 --> Output Class Initialized
INFO - 2022-11-29 11:05:46 --> Security Class Initialized
DEBUG - 2022-11-29 11:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:05:46 --> Input Class Initialized
INFO - 2022-11-29 11:05:46 --> Language Class Initialized
INFO - 2022-11-29 11:05:46 --> Loader Class Initialized
INFO - 2022-11-29 11:05:46 --> Helper loaded: url_helper
INFO - 2022-11-29 11:05:46 --> Database Driver Class Initialized
INFO - 2022-11-29 11:05:46 --> Helper loaded: form_helper
INFO - 2022-11-29 11:05:46 --> Form Validation Class Initialized
INFO - 2022-11-29 11:05:46 --> Controller Class Initialized
INFO - 2022-11-29 11:05:46 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:05:46 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:05:46 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:05:46 --> Final output sent to browser
DEBUG - 2022-11-29 11:05:46 --> Total execution time: 0.0563
INFO - 2022-11-29 11:05:47 --> Config Class Initialized
INFO - 2022-11-29 11:05:47 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:05:47 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:05:47 --> Utf8 Class Initialized
INFO - 2022-11-29 11:05:47 --> URI Class Initialized
INFO - 2022-11-29 11:05:47 --> Router Class Initialized
INFO - 2022-11-29 11:05:47 --> Output Class Initialized
INFO - 2022-11-29 11:05:47 --> Security Class Initialized
DEBUG - 2022-11-29 11:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:05:47 --> Input Class Initialized
INFO - 2022-11-29 11:05:47 --> Language Class Initialized
INFO - 2022-11-29 11:05:47 --> Loader Class Initialized
INFO - 2022-11-29 11:05:47 --> Helper loaded: url_helper
INFO - 2022-11-29 11:05:47 --> Database Driver Class Initialized
INFO - 2022-11-29 11:05:47 --> Helper loaded: form_helper
INFO - 2022-11-29 11:05:47 --> Form Validation Class Initialized
INFO - 2022-11-29 11:05:47 --> Controller Class Initialized
INFO - 2022-11-29 11:05:47 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:05:47 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:05:47 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:05:47 --> Final output sent to browser
DEBUG - 2022-11-29 11:05:47 --> Total execution time: 0.0533
INFO - 2022-11-29 11:05:47 --> Config Class Initialized
INFO - 2022-11-29 11:05:47 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:05:47 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:05:47 --> Utf8 Class Initialized
INFO - 2022-11-29 11:05:47 --> URI Class Initialized
INFO - 2022-11-29 11:05:47 --> Router Class Initialized
INFO - 2022-11-29 11:05:47 --> Output Class Initialized
INFO - 2022-11-29 11:05:47 --> Security Class Initialized
DEBUG - 2022-11-29 11:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:05:47 --> Input Class Initialized
INFO - 2022-11-29 11:05:47 --> Language Class Initialized
INFO - 2022-11-29 11:05:47 --> Loader Class Initialized
INFO - 2022-11-29 11:05:47 --> Helper loaded: url_helper
INFO - 2022-11-29 11:05:47 --> Database Driver Class Initialized
INFO - 2022-11-29 11:05:47 --> Helper loaded: form_helper
INFO - 2022-11-29 11:05:47 --> Form Validation Class Initialized
INFO - 2022-11-29 11:05:47 --> Controller Class Initialized
INFO - 2022-11-29 11:05:47 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:05:47 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:05:47 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:05:47 --> Final output sent to browser
DEBUG - 2022-11-29 11:05:47 --> Total execution time: 0.0570
INFO - 2022-11-29 11:08:32 --> Config Class Initialized
INFO - 2022-11-29 11:08:32 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:08:32 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:08:32 --> Utf8 Class Initialized
INFO - 2022-11-29 11:08:32 --> URI Class Initialized
INFO - 2022-11-29 11:08:32 --> Router Class Initialized
INFO - 2022-11-29 11:08:32 --> Output Class Initialized
INFO - 2022-11-29 11:08:32 --> Security Class Initialized
DEBUG - 2022-11-29 11:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:08:32 --> Input Class Initialized
INFO - 2022-11-29 11:08:32 --> Language Class Initialized
INFO - 2022-11-29 11:08:32 --> Loader Class Initialized
INFO - 2022-11-29 11:08:32 --> Helper loaded: url_helper
INFO - 2022-11-29 11:08:32 --> Database Driver Class Initialized
INFO - 2022-11-29 11:08:32 --> Helper loaded: form_helper
INFO - 2022-11-29 11:08:32 --> Form Validation Class Initialized
INFO - 2022-11-29 11:08:32 --> Controller Class Initialized
INFO - 2022-11-29 11:08:32 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:08:32 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:08:32 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:08:32 --> Final output sent to browser
DEBUG - 2022-11-29 11:08:32 --> Total execution time: 0.0528
INFO - 2022-11-29 11:08:41 --> Config Class Initialized
INFO - 2022-11-29 11:08:41 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:08:41 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:08:41 --> Utf8 Class Initialized
INFO - 2022-11-29 11:08:41 --> URI Class Initialized
INFO - 2022-11-29 11:08:41 --> Router Class Initialized
INFO - 2022-11-29 11:08:41 --> Output Class Initialized
INFO - 2022-11-29 11:08:41 --> Security Class Initialized
DEBUG - 2022-11-29 11:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:08:41 --> Input Class Initialized
INFO - 2022-11-29 11:08:41 --> Language Class Initialized
INFO - 2022-11-29 11:08:41 --> Loader Class Initialized
INFO - 2022-11-29 11:08:41 --> Helper loaded: url_helper
INFO - 2022-11-29 11:08:41 --> Database Driver Class Initialized
INFO - 2022-11-29 11:08:41 --> Helper loaded: form_helper
INFO - 2022-11-29 11:08:41 --> Form Validation Class Initialized
INFO - 2022-11-29 11:08:41 --> Controller Class Initialized
INFO - 2022-11-29 11:08:41 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:08:41 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:08:41 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:08:41 --> Final output sent to browser
DEBUG - 2022-11-29 11:08:41 --> Total execution time: 0.0501
INFO - 2022-11-29 11:08:46 --> Config Class Initialized
INFO - 2022-11-29 11:08:46 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:08:46 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:08:46 --> Utf8 Class Initialized
INFO - 2022-11-29 11:08:46 --> URI Class Initialized
INFO - 2022-11-29 11:08:46 --> Router Class Initialized
INFO - 2022-11-29 11:08:46 --> Output Class Initialized
INFO - 2022-11-29 11:08:46 --> Security Class Initialized
DEBUG - 2022-11-29 11:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:08:46 --> Input Class Initialized
INFO - 2022-11-29 11:08:46 --> Language Class Initialized
INFO - 2022-11-29 11:08:46 --> Loader Class Initialized
INFO - 2022-11-29 11:08:46 --> Helper loaded: url_helper
INFO - 2022-11-29 11:08:46 --> Database Driver Class Initialized
INFO - 2022-11-29 11:08:46 --> Helper loaded: form_helper
INFO - 2022-11-29 11:08:46 --> Form Validation Class Initialized
INFO - 2022-11-29 11:08:46 --> Controller Class Initialized
INFO - 2022-11-29 11:08:46 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:08:46 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:08:46 --> Upload Class Initialized
INFO - 2022-11-29 11:08:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-11-29 11:08:46 --> Config Class Initialized
INFO - 2022-11-29 11:08:46 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:08:46 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:08:46 --> Utf8 Class Initialized
INFO - 2022-11-29 11:08:46 --> URI Class Initialized
INFO - 2022-11-29 11:08:46 --> Router Class Initialized
INFO - 2022-11-29 11:08:46 --> Output Class Initialized
INFO - 2022-11-29 11:08:46 --> Security Class Initialized
DEBUG - 2022-11-29 11:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:08:46 --> Input Class Initialized
INFO - 2022-11-29 11:08:46 --> Language Class Initialized
INFO - 2022-11-29 11:08:46 --> Loader Class Initialized
INFO - 2022-11-29 11:08:46 --> Helper loaded: url_helper
INFO - 2022-11-29 11:08:46 --> Database Driver Class Initialized
INFO - 2022-11-29 11:08:46 --> Helper loaded: form_helper
INFO - 2022-11-29 11:08:46 --> Form Validation Class Initialized
INFO - 2022-11-29 11:08:46 --> Controller Class Initialized
INFO - 2022-11-29 11:08:46 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:08:46 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:08:46 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:08:46 --> Final output sent to browser
DEBUG - 2022-11-29 11:08:46 --> Total execution time: 0.0568
INFO - 2022-11-29 11:08:54 --> Config Class Initialized
INFO - 2022-11-29 11:08:54 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:08:54 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:08:54 --> Utf8 Class Initialized
INFO - 2022-11-29 11:08:54 --> URI Class Initialized
INFO - 2022-11-29 11:08:54 --> Router Class Initialized
INFO - 2022-11-29 11:08:54 --> Output Class Initialized
INFO - 2022-11-29 11:08:54 --> Security Class Initialized
DEBUG - 2022-11-29 11:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:08:54 --> Input Class Initialized
INFO - 2022-11-29 11:08:54 --> Language Class Initialized
INFO - 2022-11-29 11:08:54 --> Loader Class Initialized
INFO - 2022-11-29 11:08:54 --> Helper loaded: url_helper
INFO - 2022-11-29 11:08:54 --> Database Driver Class Initialized
INFO - 2022-11-29 11:08:54 --> Helper loaded: form_helper
INFO - 2022-11-29 11:08:54 --> Form Validation Class Initialized
INFO - 2022-11-29 11:08:54 --> Controller Class Initialized
INFO - 2022-11-29 11:08:54 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:08:54 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:08:54 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:08:54 --> Final output sent to browser
DEBUG - 2022-11-29 11:08:54 --> Total execution time: 0.0363
INFO - 2022-11-29 11:08:59 --> Config Class Initialized
INFO - 2022-11-29 11:08:59 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:08:59 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:08:59 --> Utf8 Class Initialized
INFO - 2022-11-29 11:08:59 --> URI Class Initialized
INFO - 2022-11-29 11:08:59 --> Router Class Initialized
INFO - 2022-11-29 11:08:59 --> Output Class Initialized
INFO - 2022-11-29 11:08:59 --> Security Class Initialized
DEBUG - 2022-11-29 11:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:08:59 --> Input Class Initialized
INFO - 2022-11-29 11:08:59 --> Language Class Initialized
INFO - 2022-11-29 11:08:59 --> Loader Class Initialized
INFO - 2022-11-29 11:08:59 --> Helper loaded: url_helper
INFO - 2022-11-29 11:08:59 --> Database Driver Class Initialized
INFO - 2022-11-29 11:08:59 --> Helper loaded: form_helper
INFO - 2022-11-29 11:08:59 --> Form Validation Class Initialized
INFO - 2022-11-29 11:08:59 --> Controller Class Initialized
INFO - 2022-11-29 11:08:59 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:08:59 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:08:59 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:08:59 --> Final output sent to browser
DEBUG - 2022-11-29 11:08:59 --> Total execution time: 0.0507
INFO - 2022-11-29 11:09:06 --> Config Class Initialized
INFO - 2022-11-29 11:09:06 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:09:06 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:09:06 --> Utf8 Class Initialized
INFO - 2022-11-29 11:09:06 --> URI Class Initialized
INFO - 2022-11-29 11:09:06 --> Router Class Initialized
INFO - 2022-11-29 11:09:06 --> Output Class Initialized
INFO - 2022-11-29 11:09:06 --> Security Class Initialized
DEBUG - 2022-11-29 11:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:09:06 --> Input Class Initialized
INFO - 2022-11-29 11:09:06 --> Language Class Initialized
INFO - 2022-11-29 11:09:06 --> Loader Class Initialized
INFO - 2022-11-29 11:09:06 --> Helper loaded: url_helper
INFO - 2022-11-29 11:09:06 --> Database Driver Class Initialized
INFO - 2022-11-29 11:09:06 --> Helper loaded: form_helper
INFO - 2022-11-29 11:09:06 --> Form Validation Class Initialized
INFO - 2022-11-29 11:09:06 --> Controller Class Initialized
INFO - 2022-11-29 11:09:06 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:09:06 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:09:06 --> Upload Class Initialized
INFO - 2022-11-29 11:09:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-11-29 11:09:06 --> Config Class Initialized
INFO - 2022-11-29 11:09:06 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:09:06 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:09:06 --> Utf8 Class Initialized
INFO - 2022-11-29 11:09:06 --> URI Class Initialized
INFO - 2022-11-29 11:09:06 --> Router Class Initialized
INFO - 2022-11-29 11:09:06 --> Output Class Initialized
INFO - 2022-11-29 11:09:06 --> Security Class Initialized
DEBUG - 2022-11-29 11:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:09:06 --> Input Class Initialized
INFO - 2022-11-29 11:09:06 --> Language Class Initialized
INFO - 2022-11-29 11:09:06 --> Loader Class Initialized
INFO - 2022-11-29 11:09:06 --> Helper loaded: url_helper
INFO - 2022-11-29 11:09:06 --> Database Driver Class Initialized
INFO - 2022-11-29 11:09:06 --> Helper loaded: form_helper
INFO - 2022-11-29 11:09:06 --> Form Validation Class Initialized
INFO - 2022-11-29 11:09:06 --> Controller Class Initialized
INFO - 2022-11-29 11:09:06 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:09:06 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:09:06 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:09:06 --> Final output sent to browser
DEBUG - 2022-11-29 11:09:06 --> Total execution time: 0.0558
INFO - 2022-11-29 11:09:11 --> Config Class Initialized
INFO - 2022-11-29 11:09:11 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:09:11 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:09:11 --> Utf8 Class Initialized
INFO - 2022-11-29 11:09:11 --> URI Class Initialized
INFO - 2022-11-29 11:09:11 --> Router Class Initialized
INFO - 2022-11-29 11:09:11 --> Output Class Initialized
INFO - 2022-11-29 11:09:11 --> Security Class Initialized
DEBUG - 2022-11-29 11:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:09:11 --> Input Class Initialized
INFO - 2022-11-29 11:09:11 --> Language Class Initialized
INFO - 2022-11-29 11:09:11 --> Loader Class Initialized
INFO - 2022-11-29 11:09:11 --> Helper loaded: url_helper
INFO - 2022-11-29 11:09:11 --> Database Driver Class Initialized
INFO - 2022-11-29 11:09:11 --> Helper loaded: form_helper
INFO - 2022-11-29 11:09:11 --> Form Validation Class Initialized
INFO - 2022-11-29 11:09:11 --> Controller Class Initialized
INFO - 2022-11-29 11:09:11 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:09:11 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:09:11 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:09:11 --> Final output sent to browser
DEBUG - 2022-11-29 11:09:11 --> Total execution time: 0.0515
INFO - 2022-11-29 11:09:26 --> Config Class Initialized
INFO - 2022-11-29 11:09:26 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:09:26 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:09:26 --> Utf8 Class Initialized
INFO - 2022-11-29 11:09:26 --> URI Class Initialized
INFO - 2022-11-29 11:09:26 --> Router Class Initialized
INFO - 2022-11-29 11:09:26 --> Output Class Initialized
INFO - 2022-11-29 11:09:26 --> Security Class Initialized
DEBUG - 2022-11-29 11:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:09:26 --> Input Class Initialized
INFO - 2022-11-29 11:09:26 --> Language Class Initialized
INFO - 2022-11-29 11:09:26 --> Loader Class Initialized
INFO - 2022-11-29 11:09:26 --> Helper loaded: url_helper
INFO - 2022-11-29 11:09:26 --> Database Driver Class Initialized
INFO - 2022-11-29 11:09:26 --> Helper loaded: form_helper
INFO - 2022-11-29 11:09:26 --> Form Validation Class Initialized
INFO - 2022-11-29 11:09:26 --> Controller Class Initialized
INFO - 2022-11-29 11:09:26 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:09:26 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:09:26 --> Upload Class Initialized
INFO - 2022-11-29 11:09:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-11-29 11:09:26 --> Config Class Initialized
INFO - 2022-11-29 11:09:26 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:09:26 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:09:26 --> Utf8 Class Initialized
INFO - 2022-11-29 11:09:26 --> URI Class Initialized
INFO - 2022-11-29 11:09:26 --> Router Class Initialized
INFO - 2022-11-29 11:09:26 --> Output Class Initialized
INFO - 2022-11-29 11:09:26 --> Security Class Initialized
DEBUG - 2022-11-29 11:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:09:26 --> Input Class Initialized
INFO - 2022-11-29 11:09:26 --> Language Class Initialized
INFO - 2022-11-29 11:09:26 --> Loader Class Initialized
INFO - 2022-11-29 11:09:26 --> Helper loaded: url_helper
INFO - 2022-11-29 11:09:26 --> Database Driver Class Initialized
INFO - 2022-11-29 11:09:27 --> Helper loaded: form_helper
INFO - 2022-11-29 11:09:27 --> Form Validation Class Initialized
INFO - 2022-11-29 11:09:27 --> Controller Class Initialized
INFO - 2022-11-29 11:09:27 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:09:27 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:09:27 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:09:27 --> Final output sent to browser
DEBUG - 2022-11-29 11:09:27 --> Total execution time: 0.0600
INFO - 2022-11-29 11:09:32 --> Config Class Initialized
INFO - 2022-11-29 11:09:32 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:09:32 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:09:32 --> Utf8 Class Initialized
INFO - 2022-11-29 11:09:32 --> URI Class Initialized
INFO - 2022-11-29 11:09:32 --> Router Class Initialized
INFO - 2022-11-29 11:09:32 --> Output Class Initialized
INFO - 2022-11-29 11:09:32 --> Security Class Initialized
DEBUG - 2022-11-29 11:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:09:32 --> Input Class Initialized
INFO - 2022-11-29 11:09:32 --> Language Class Initialized
INFO - 2022-11-29 11:09:32 --> Loader Class Initialized
INFO - 2022-11-29 11:09:32 --> Helper loaded: url_helper
INFO - 2022-11-29 11:09:32 --> Database Driver Class Initialized
INFO - 2022-11-29 11:09:32 --> Helper loaded: form_helper
INFO - 2022-11-29 11:09:32 --> Form Validation Class Initialized
INFO - 2022-11-29 11:09:32 --> Controller Class Initialized
INFO - 2022-11-29 11:09:32 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:09:32 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:09:32 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:09:32 --> Final output sent to browser
DEBUG - 2022-11-29 11:09:32 --> Total execution time: 0.0505
INFO - 2022-11-29 11:10:07 --> Config Class Initialized
INFO - 2022-11-29 11:10:07 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:10:07 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:10:07 --> Utf8 Class Initialized
INFO - 2022-11-29 11:10:07 --> URI Class Initialized
INFO - 2022-11-29 11:10:07 --> Router Class Initialized
INFO - 2022-11-29 11:10:07 --> Output Class Initialized
INFO - 2022-11-29 11:10:07 --> Security Class Initialized
DEBUG - 2022-11-29 11:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:10:07 --> Input Class Initialized
INFO - 2022-11-29 11:10:07 --> Language Class Initialized
INFO - 2022-11-29 11:10:07 --> Loader Class Initialized
INFO - 2022-11-29 11:10:07 --> Helper loaded: url_helper
INFO - 2022-11-29 11:10:07 --> Database Driver Class Initialized
INFO - 2022-11-29 11:10:07 --> Helper loaded: form_helper
INFO - 2022-11-29 11:10:07 --> Form Validation Class Initialized
INFO - 2022-11-29 11:10:07 --> Controller Class Initialized
INFO - 2022-11-29 11:10:07 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:10:07 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:10:07 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:10:07 --> Final output sent to browser
DEBUG - 2022-11-29 11:10:07 --> Total execution time: 0.0301
INFO - 2022-11-29 11:10:31 --> Config Class Initialized
INFO - 2022-11-29 11:10:31 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:10:31 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:10:31 --> Utf8 Class Initialized
INFO - 2022-11-29 11:10:31 --> URI Class Initialized
INFO - 2022-11-29 11:10:31 --> Router Class Initialized
INFO - 2022-11-29 11:10:31 --> Output Class Initialized
INFO - 2022-11-29 11:10:31 --> Security Class Initialized
DEBUG - 2022-11-29 11:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:10:31 --> Input Class Initialized
INFO - 2022-11-29 11:10:31 --> Language Class Initialized
INFO - 2022-11-29 11:10:31 --> Loader Class Initialized
INFO - 2022-11-29 11:10:31 --> Helper loaded: url_helper
INFO - 2022-11-29 11:10:31 --> Database Driver Class Initialized
INFO - 2022-11-29 11:10:31 --> Helper loaded: form_helper
INFO - 2022-11-29 11:10:31 --> Form Validation Class Initialized
INFO - 2022-11-29 11:10:31 --> Controller Class Initialized
INFO - 2022-11-29 11:10:31 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:10:31 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:10:31 --> Upload Class Initialized
INFO - 2022-11-29 11:10:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-11-29 11:10:31 --> Config Class Initialized
INFO - 2022-11-29 11:10:31 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:10:31 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:10:31 --> Utf8 Class Initialized
INFO - 2022-11-29 11:10:31 --> URI Class Initialized
INFO - 2022-11-29 11:10:31 --> Router Class Initialized
INFO - 2022-11-29 11:10:31 --> Output Class Initialized
INFO - 2022-11-29 11:10:31 --> Security Class Initialized
DEBUG - 2022-11-29 11:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:10:31 --> Input Class Initialized
INFO - 2022-11-29 11:10:31 --> Language Class Initialized
INFO - 2022-11-29 11:10:31 --> Loader Class Initialized
INFO - 2022-11-29 11:10:31 --> Helper loaded: url_helper
INFO - 2022-11-29 11:10:31 --> Database Driver Class Initialized
INFO - 2022-11-29 11:10:31 --> Helper loaded: form_helper
INFO - 2022-11-29 11:10:31 --> Form Validation Class Initialized
INFO - 2022-11-29 11:10:31 --> Controller Class Initialized
INFO - 2022-11-29 11:10:31 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:10:31 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:10:31 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:10:31 --> Final output sent to browser
DEBUG - 2022-11-29 11:10:31 --> Total execution time: 0.0446
INFO - 2022-11-29 11:13:23 --> Config Class Initialized
INFO - 2022-11-29 11:13:23 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:13:23 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:13:23 --> Utf8 Class Initialized
INFO - 2022-11-29 11:13:23 --> URI Class Initialized
INFO - 2022-11-29 11:13:23 --> Router Class Initialized
INFO - 2022-11-29 11:13:23 --> Output Class Initialized
INFO - 2022-11-29 11:13:23 --> Security Class Initialized
DEBUG - 2022-11-29 11:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:13:23 --> Input Class Initialized
INFO - 2022-11-29 11:13:23 --> Language Class Initialized
INFO - 2022-11-29 11:13:23 --> Loader Class Initialized
INFO - 2022-11-29 11:13:23 --> Helper loaded: url_helper
INFO - 2022-11-29 11:13:23 --> Database Driver Class Initialized
INFO - 2022-11-29 11:13:23 --> Helper loaded: form_helper
INFO - 2022-11-29 11:13:23 --> Form Validation Class Initialized
INFO - 2022-11-29 11:13:23 --> Controller Class Initialized
INFO - 2022-11-29 11:13:23 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:13:23 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:13:23 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:13:23 --> Final output sent to browser
DEBUG - 2022-11-29 11:13:23 --> Total execution time: 0.0650
INFO - 2022-11-29 11:13:42 --> Config Class Initialized
INFO - 2022-11-29 11:13:42 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:13:42 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:13:42 --> Utf8 Class Initialized
INFO - 2022-11-29 11:13:42 --> URI Class Initialized
INFO - 2022-11-29 11:13:42 --> Router Class Initialized
INFO - 2022-11-29 11:13:42 --> Output Class Initialized
INFO - 2022-11-29 11:13:42 --> Security Class Initialized
DEBUG - 2022-11-29 11:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:13:42 --> Input Class Initialized
INFO - 2022-11-29 11:13:42 --> Language Class Initialized
INFO - 2022-11-29 11:13:42 --> Loader Class Initialized
INFO - 2022-11-29 11:13:42 --> Helper loaded: url_helper
INFO - 2022-11-29 11:13:42 --> Database Driver Class Initialized
INFO - 2022-11-29 11:13:42 --> Helper loaded: form_helper
INFO - 2022-11-29 11:13:42 --> Form Validation Class Initialized
INFO - 2022-11-29 11:13:42 --> Controller Class Initialized
INFO - 2022-11-29 11:13:42 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:13:42 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:13:42 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:13:42 --> Final output sent to browser
DEBUG - 2022-11-29 11:13:42 --> Total execution time: 0.0512
INFO - 2022-11-29 11:13:54 --> Config Class Initialized
INFO - 2022-11-29 11:13:54 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:13:54 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:13:54 --> Utf8 Class Initialized
INFO - 2022-11-29 11:13:54 --> URI Class Initialized
INFO - 2022-11-29 11:13:54 --> Router Class Initialized
INFO - 2022-11-29 11:13:54 --> Output Class Initialized
INFO - 2022-11-29 11:13:54 --> Security Class Initialized
DEBUG - 2022-11-29 11:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:13:54 --> Input Class Initialized
INFO - 2022-11-29 11:13:54 --> Language Class Initialized
INFO - 2022-11-29 11:13:54 --> Loader Class Initialized
INFO - 2022-11-29 11:13:54 --> Helper loaded: url_helper
INFO - 2022-11-29 11:13:54 --> Database Driver Class Initialized
INFO - 2022-11-29 11:13:54 --> Helper loaded: form_helper
INFO - 2022-11-29 11:13:54 --> Form Validation Class Initialized
INFO - 2022-11-29 11:13:54 --> Controller Class Initialized
INFO - 2022-11-29 11:13:54 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:13:54 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:13:54 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:13:54 --> Final output sent to browser
DEBUG - 2022-11-29 11:13:54 --> Total execution time: 0.0556
INFO - 2022-11-29 11:14:24 --> Config Class Initialized
INFO - 2022-11-29 11:14:24 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:14:24 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:14:24 --> Utf8 Class Initialized
INFO - 2022-11-29 11:14:24 --> URI Class Initialized
INFO - 2022-11-29 11:14:24 --> Router Class Initialized
INFO - 2022-11-29 11:14:24 --> Output Class Initialized
INFO - 2022-11-29 11:14:24 --> Security Class Initialized
DEBUG - 2022-11-29 11:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:14:24 --> Input Class Initialized
INFO - 2022-11-29 11:14:24 --> Language Class Initialized
INFO - 2022-11-29 11:14:24 --> Loader Class Initialized
INFO - 2022-11-29 11:14:24 --> Helper loaded: url_helper
INFO - 2022-11-29 11:14:24 --> Database Driver Class Initialized
INFO - 2022-11-29 11:14:24 --> Helper loaded: form_helper
INFO - 2022-11-29 11:14:24 --> Form Validation Class Initialized
INFO - 2022-11-29 11:14:24 --> Controller Class Initialized
INFO - 2022-11-29 11:14:24 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:14:24 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:14:24 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:14:24 --> Final output sent to browser
DEBUG - 2022-11-29 11:14:24 --> Total execution time: 0.0536
INFO - 2022-11-29 11:14:38 --> Config Class Initialized
INFO - 2022-11-29 11:14:38 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:14:38 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:14:38 --> Utf8 Class Initialized
INFO - 2022-11-29 11:14:38 --> URI Class Initialized
INFO - 2022-11-29 11:14:38 --> Router Class Initialized
INFO - 2022-11-29 11:14:38 --> Output Class Initialized
INFO - 2022-11-29 11:14:38 --> Security Class Initialized
DEBUG - 2022-11-29 11:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:14:38 --> Input Class Initialized
INFO - 2022-11-29 11:14:38 --> Language Class Initialized
INFO - 2022-11-29 11:14:38 --> Loader Class Initialized
INFO - 2022-11-29 11:14:38 --> Helper loaded: url_helper
INFO - 2022-11-29 11:14:38 --> Database Driver Class Initialized
INFO - 2022-11-29 11:14:38 --> Helper loaded: form_helper
INFO - 2022-11-29 11:14:38 --> Form Validation Class Initialized
INFO - 2022-11-29 11:14:38 --> Controller Class Initialized
INFO - 2022-11-29 11:14:38 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:14:38 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:14:38 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:14:38 --> Final output sent to browser
DEBUG - 2022-11-29 11:14:38 --> Total execution time: 0.0499
INFO - 2022-11-29 11:14:44 --> Config Class Initialized
INFO - 2022-11-29 11:14:44 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:14:44 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:14:44 --> Utf8 Class Initialized
INFO - 2022-11-29 11:14:44 --> URI Class Initialized
INFO - 2022-11-29 11:14:44 --> Router Class Initialized
INFO - 2022-11-29 11:14:44 --> Output Class Initialized
INFO - 2022-11-29 11:14:44 --> Security Class Initialized
DEBUG - 2022-11-29 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:14:44 --> Input Class Initialized
INFO - 2022-11-29 11:14:44 --> Language Class Initialized
INFO - 2022-11-29 11:14:44 --> Loader Class Initialized
INFO - 2022-11-29 11:14:44 --> Helper loaded: url_helper
INFO - 2022-11-29 11:14:44 --> Database Driver Class Initialized
INFO - 2022-11-29 11:14:44 --> Helper loaded: form_helper
INFO - 2022-11-29 11:14:44 --> Form Validation Class Initialized
INFO - 2022-11-29 11:14:44 --> Controller Class Initialized
INFO - 2022-11-29 11:14:44 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:14:44 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:14:44 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:14:44 --> Final output sent to browser
DEBUG - 2022-11-29 11:14:44 --> Total execution time: 0.0374
INFO - 2022-11-29 11:14:44 --> Config Class Initialized
INFO - 2022-11-29 11:14:44 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:14:44 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:14:44 --> Utf8 Class Initialized
INFO - 2022-11-29 11:14:44 --> URI Class Initialized
INFO - 2022-11-29 11:14:44 --> Router Class Initialized
INFO - 2022-11-29 11:14:44 --> Output Class Initialized
INFO - 2022-11-29 11:14:44 --> Security Class Initialized
DEBUG - 2022-11-29 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:14:44 --> Input Class Initialized
INFO - 2022-11-29 11:14:44 --> Language Class Initialized
INFO - 2022-11-29 11:14:44 --> Loader Class Initialized
INFO - 2022-11-29 11:14:44 --> Helper loaded: url_helper
INFO - 2022-11-29 11:14:44 --> Database Driver Class Initialized
INFO - 2022-11-29 11:14:44 --> Helper loaded: form_helper
INFO - 2022-11-29 11:14:44 --> Form Validation Class Initialized
INFO - 2022-11-29 11:14:44 --> Controller Class Initialized
INFO - 2022-11-29 11:14:44 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:14:44 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:14:44 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:14:44 --> Final output sent to browser
DEBUG - 2022-11-29 11:14:44 --> Total execution time: 0.0641
INFO - 2022-11-29 11:14:52 --> Config Class Initialized
INFO - 2022-11-29 11:14:52 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:14:52 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:14:52 --> Utf8 Class Initialized
INFO - 2022-11-29 11:14:52 --> URI Class Initialized
INFO - 2022-11-29 11:14:52 --> Router Class Initialized
INFO - 2022-11-29 11:14:52 --> Output Class Initialized
INFO - 2022-11-29 11:14:52 --> Security Class Initialized
DEBUG - 2022-11-29 11:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:14:52 --> Input Class Initialized
INFO - 2022-11-29 11:14:52 --> Language Class Initialized
INFO - 2022-11-29 11:14:52 --> Loader Class Initialized
INFO - 2022-11-29 11:14:52 --> Helper loaded: url_helper
INFO - 2022-11-29 11:14:52 --> Database Driver Class Initialized
INFO - 2022-11-29 11:14:52 --> Helper loaded: form_helper
INFO - 2022-11-29 11:14:52 --> Form Validation Class Initialized
INFO - 2022-11-29 11:14:52 --> Controller Class Initialized
INFO - 2022-11-29 11:14:52 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:14:52 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:14:52 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:14:52 --> Final output sent to browser
DEBUG - 2022-11-29 11:14:52 --> Total execution time: 0.0626
INFO - 2022-11-29 11:15:02 --> Config Class Initialized
INFO - 2022-11-29 11:15:02 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:15:02 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:15:02 --> Utf8 Class Initialized
INFO - 2022-11-29 11:15:02 --> URI Class Initialized
INFO - 2022-11-29 11:15:02 --> Router Class Initialized
INFO - 2022-11-29 11:15:02 --> Output Class Initialized
INFO - 2022-11-29 11:15:02 --> Security Class Initialized
DEBUG - 2022-11-29 11:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:15:02 --> Input Class Initialized
INFO - 2022-11-29 11:15:02 --> Language Class Initialized
INFO - 2022-11-29 11:15:02 --> Loader Class Initialized
INFO - 2022-11-29 11:15:02 --> Helper loaded: url_helper
INFO - 2022-11-29 11:15:02 --> Database Driver Class Initialized
INFO - 2022-11-29 11:15:02 --> Helper loaded: form_helper
INFO - 2022-11-29 11:15:02 --> Form Validation Class Initialized
INFO - 2022-11-29 11:15:02 --> Controller Class Initialized
INFO - 2022-11-29 11:15:02 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:15:02 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:15:02 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:15:02 --> Final output sent to browser
DEBUG - 2022-11-29 11:15:02 --> Total execution time: 0.0637
INFO - 2022-11-29 11:15:07 --> Config Class Initialized
INFO - 2022-11-29 11:15:07 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:15:07 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:15:07 --> Utf8 Class Initialized
INFO - 2022-11-29 11:15:07 --> URI Class Initialized
INFO - 2022-11-29 11:15:07 --> Router Class Initialized
INFO - 2022-11-29 11:15:07 --> Output Class Initialized
INFO - 2022-11-29 11:15:07 --> Security Class Initialized
DEBUG - 2022-11-29 11:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:15:07 --> Input Class Initialized
INFO - 2022-11-29 11:15:07 --> Language Class Initialized
INFO - 2022-11-29 11:15:07 --> Loader Class Initialized
INFO - 2022-11-29 11:15:07 --> Helper loaded: url_helper
INFO - 2022-11-29 11:15:07 --> Database Driver Class Initialized
INFO - 2022-11-29 11:15:07 --> Helper loaded: form_helper
INFO - 2022-11-29 11:15:07 --> Form Validation Class Initialized
INFO - 2022-11-29 11:15:07 --> Controller Class Initialized
INFO - 2022-11-29 11:15:07 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:15:07 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:15:07 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:15:07 --> Final output sent to browser
DEBUG - 2022-11-29 11:15:07 --> Total execution time: 0.0510
INFO - 2022-11-29 11:15:15 --> Config Class Initialized
INFO - 2022-11-29 11:15:15 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:15:15 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:15:15 --> Utf8 Class Initialized
INFO - 2022-11-29 11:15:15 --> URI Class Initialized
INFO - 2022-11-29 11:15:15 --> Router Class Initialized
INFO - 2022-11-29 11:15:15 --> Output Class Initialized
INFO - 2022-11-29 11:15:15 --> Security Class Initialized
DEBUG - 2022-11-29 11:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:15:15 --> Input Class Initialized
INFO - 2022-11-29 11:15:15 --> Language Class Initialized
INFO - 2022-11-29 11:15:15 --> Loader Class Initialized
INFO - 2022-11-29 11:15:15 --> Helper loaded: url_helper
INFO - 2022-11-29 11:15:15 --> Database Driver Class Initialized
INFO - 2022-11-29 11:15:15 --> Helper loaded: form_helper
INFO - 2022-11-29 11:15:15 --> Form Validation Class Initialized
INFO - 2022-11-29 11:15:15 --> Controller Class Initialized
INFO - 2022-11-29 11:15:15 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:15:15 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:15:15 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:15:15 --> Final output sent to browser
DEBUG - 2022-11-29 11:15:15 --> Total execution time: 0.0499
INFO - 2022-11-29 11:15:20 --> Config Class Initialized
INFO - 2022-11-29 11:15:20 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:15:20 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:15:20 --> Utf8 Class Initialized
INFO - 2022-11-29 11:15:20 --> URI Class Initialized
INFO - 2022-11-29 11:15:20 --> Router Class Initialized
INFO - 2022-11-29 11:15:20 --> Output Class Initialized
INFO - 2022-11-29 11:15:20 --> Security Class Initialized
DEBUG - 2022-11-29 11:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:15:20 --> Input Class Initialized
INFO - 2022-11-29 11:15:20 --> Language Class Initialized
INFO - 2022-11-29 11:15:20 --> Loader Class Initialized
INFO - 2022-11-29 11:15:20 --> Helper loaded: url_helper
INFO - 2022-11-29 11:15:20 --> Database Driver Class Initialized
INFO - 2022-11-29 11:15:20 --> Helper loaded: form_helper
INFO - 2022-11-29 11:15:20 --> Form Validation Class Initialized
INFO - 2022-11-29 11:15:20 --> Controller Class Initialized
INFO - 2022-11-29 11:15:20 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:15:20 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:15:20 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:15:20 --> Final output sent to browser
DEBUG - 2022-11-29 11:15:20 --> Total execution time: 0.0392
INFO - 2022-11-29 11:15:25 --> Config Class Initialized
INFO - 2022-11-29 11:15:25 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:15:25 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:15:25 --> Utf8 Class Initialized
INFO - 2022-11-29 11:15:25 --> URI Class Initialized
INFO - 2022-11-29 11:15:25 --> Router Class Initialized
INFO - 2022-11-29 11:15:25 --> Output Class Initialized
INFO - 2022-11-29 11:15:25 --> Security Class Initialized
DEBUG - 2022-11-29 11:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:15:25 --> Input Class Initialized
INFO - 2022-11-29 11:15:25 --> Language Class Initialized
INFO - 2022-11-29 11:15:25 --> Loader Class Initialized
INFO - 2022-11-29 11:15:25 --> Helper loaded: url_helper
INFO - 2022-11-29 11:15:25 --> Database Driver Class Initialized
INFO - 2022-11-29 11:15:25 --> Helper loaded: form_helper
INFO - 2022-11-29 11:15:25 --> Form Validation Class Initialized
INFO - 2022-11-29 11:15:25 --> Controller Class Initialized
INFO - 2022-11-29 11:15:25 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:15:25 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:15:25 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:15:25 --> Final output sent to browser
DEBUG - 2022-11-29 11:15:25 --> Total execution time: 0.0648
INFO - 2022-11-29 11:15:26 --> Config Class Initialized
INFO - 2022-11-29 11:15:26 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:15:26 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:15:26 --> Utf8 Class Initialized
INFO - 2022-11-29 11:15:26 --> URI Class Initialized
INFO - 2022-11-29 11:15:26 --> Router Class Initialized
INFO - 2022-11-29 11:15:26 --> Output Class Initialized
INFO - 2022-11-29 11:15:26 --> Security Class Initialized
DEBUG - 2022-11-29 11:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:15:26 --> Input Class Initialized
INFO - 2022-11-29 11:15:26 --> Language Class Initialized
INFO - 2022-11-29 11:15:26 --> Loader Class Initialized
INFO - 2022-11-29 11:15:26 --> Helper loaded: url_helper
INFO - 2022-11-29 11:15:26 --> Database Driver Class Initialized
INFO - 2022-11-29 11:15:26 --> Helper loaded: form_helper
INFO - 2022-11-29 11:15:26 --> Form Validation Class Initialized
INFO - 2022-11-29 11:15:26 --> Controller Class Initialized
INFO - 2022-11-29 11:15:26 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:15:26 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:15:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:15:26 --> Final output sent to browser
DEBUG - 2022-11-29 11:15:26 --> Total execution time: 0.0651
INFO - 2022-11-29 11:15:36 --> Config Class Initialized
INFO - 2022-11-29 11:15:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:15:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:15:36 --> Utf8 Class Initialized
INFO - 2022-11-29 11:15:36 --> URI Class Initialized
INFO - 2022-11-29 11:15:36 --> Router Class Initialized
INFO - 2022-11-29 11:15:36 --> Output Class Initialized
INFO - 2022-11-29 11:15:36 --> Security Class Initialized
DEBUG - 2022-11-29 11:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:15:36 --> Input Class Initialized
INFO - 2022-11-29 11:15:36 --> Language Class Initialized
INFO - 2022-11-29 11:15:36 --> Loader Class Initialized
INFO - 2022-11-29 11:15:36 --> Helper loaded: url_helper
INFO - 2022-11-29 11:15:36 --> Database Driver Class Initialized
INFO - 2022-11-29 11:15:36 --> Helper loaded: form_helper
INFO - 2022-11-29 11:15:36 --> Form Validation Class Initialized
INFO - 2022-11-29 11:15:36 --> Controller Class Initialized
INFO - 2022-11-29 11:15:36 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:15:36 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:15:36 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:15:36 --> Final output sent to browser
DEBUG - 2022-11-29 11:15:36 --> Total execution time: 0.0656
INFO - 2022-11-29 11:15:50 --> Config Class Initialized
INFO - 2022-11-29 11:15:50 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:15:50 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:15:50 --> Utf8 Class Initialized
INFO - 2022-11-29 11:15:50 --> URI Class Initialized
INFO - 2022-11-29 11:15:50 --> Router Class Initialized
INFO - 2022-11-29 11:15:50 --> Output Class Initialized
INFO - 2022-11-29 11:15:50 --> Security Class Initialized
DEBUG - 2022-11-29 11:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:15:50 --> Input Class Initialized
INFO - 2022-11-29 11:15:50 --> Language Class Initialized
INFO - 2022-11-29 11:15:50 --> Loader Class Initialized
INFO - 2022-11-29 11:15:50 --> Helper loaded: url_helper
INFO - 2022-11-29 11:15:50 --> Database Driver Class Initialized
INFO - 2022-11-29 11:15:50 --> Helper loaded: form_helper
INFO - 2022-11-29 11:15:50 --> Form Validation Class Initialized
INFO - 2022-11-29 11:15:50 --> Controller Class Initialized
INFO - 2022-11-29 11:15:51 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:15:51 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:15:51 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:15:51 --> Final output sent to browser
DEBUG - 2022-11-29 11:15:51 --> Total execution time: 0.0552
INFO - 2022-11-29 11:16:03 --> Config Class Initialized
INFO - 2022-11-29 11:16:03 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:16:03 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:16:03 --> Utf8 Class Initialized
INFO - 2022-11-29 11:16:03 --> URI Class Initialized
INFO - 2022-11-29 11:16:03 --> Router Class Initialized
INFO - 2022-11-29 11:16:03 --> Output Class Initialized
INFO - 2022-11-29 11:16:03 --> Security Class Initialized
DEBUG - 2022-11-29 11:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:16:03 --> Input Class Initialized
INFO - 2022-11-29 11:16:03 --> Language Class Initialized
INFO - 2022-11-29 11:16:03 --> Loader Class Initialized
INFO - 2022-11-29 11:16:03 --> Helper loaded: url_helper
INFO - 2022-11-29 11:16:03 --> Database Driver Class Initialized
INFO - 2022-11-29 11:16:03 --> Helper loaded: form_helper
INFO - 2022-11-29 11:16:03 --> Form Validation Class Initialized
INFO - 2022-11-29 11:16:03 --> Controller Class Initialized
INFO - 2022-11-29 11:16:03 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:16:03 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:16:03 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:16:03 --> Final output sent to browser
DEBUG - 2022-11-29 11:16:03 --> Total execution time: 0.0617
INFO - 2022-11-29 11:16:03 --> Config Class Initialized
INFO - 2022-11-29 11:16:03 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:16:03 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:16:03 --> Utf8 Class Initialized
INFO - 2022-11-29 11:16:03 --> URI Class Initialized
INFO - 2022-11-29 11:16:03 --> Router Class Initialized
INFO - 2022-11-29 11:16:03 --> Output Class Initialized
INFO - 2022-11-29 11:16:03 --> Security Class Initialized
DEBUG - 2022-11-29 11:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:16:03 --> Input Class Initialized
INFO - 2022-11-29 11:16:03 --> Language Class Initialized
INFO - 2022-11-29 11:16:03 --> Loader Class Initialized
INFO - 2022-11-29 11:16:03 --> Helper loaded: url_helper
INFO - 2022-11-29 11:16:03 --> Database Driver Class Initialized
INFO - 2022-11-29 11:16:03 --> Helper loaded: form_helper
INFO - 2022-11-29 11:16:03 --> Form Validation Class Initialized
INFO - 2022-11-29 11:16:03 --> Controller Class Initialized
INFO - 2022-11-29 11:16:03 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:16:03 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:16:03 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:16:03 --> Final output sent to browser
DEBUG - 2022-11-29 11:16:03 --> Total execution time: 0.0511
INFO - 2022-11-29 11:16:03 --> Config Class Initialized
INFO - 2022-11-29 11:16:03 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:16:03 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:16:03 --> Utf8 Class Initialized
INFO - 2022-11-29 11:16:03 --> URI Class Initialized
INFO - 2022-11-29 11:16:03 --> Router Class Initialized
INFO - 2022-11-29 11:16:03 --> Output Class Initialized
INFO - 2022-11-29 11:16:03 --> Security Class Initialized
DEBUG - 2022-11-29 11:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:16:03 --> Input Class Initialized
INFO - 2022-11-29 11:16:03 --> Language Class Initialized
INFO - 2022-11-29 11:16:03 --> Loader Class Initialized
INFO - 2022-11-29 11:16:03 --> Helper loaded: url_helper
INFO - 2022-11-29 11:16:03 --> Database Driver Class Initialized
INFO - 2022-11-29 11:16:03 --> Helper loaded: form_helper
INFO - 2022-11-29 11:16:03 --> Form Validation Class Initialized
INFO - 2022-11-29 11:16:03 --> Controller Class Initialized
INFO - 2022-11-29 11:16:03 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:16:03 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:16:03 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:16:03 --> Final output sent to browser
DEBUG - 2022-11-29 11:16:03 --> Total execution time: 0.0561
INFO - 2022-11-29 11:16:26 --> Config Class Initialized
INFO - 2022-11-29 11:16:26 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:16:26 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:16:26 --> Utf8 Class Initialized
INFO - 2022-11-29 11:16:26 --> URI Class Initialized
INFO - 2022-11-29 11:16:26 --> Router Class Initialized
INFO - 2022-11-29 11:16:26 --> Output Class Initialized
INFO - 2022-11-29 11:16:26 --> Security Class Initialized
DEBUG - 2022-11-29 11:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:16:26 --> Input Class Initialized
INFO - 2022-11-29 11:16:26 --> Language Class Initialized
INFO - 2022-11-29 11:16:26 --> Loader Class Initialized
INFO - 2022-11-29 11:16:26 --> Helper loaded: url_helper
INFO - 2022-11-29 11:16:26 --> Database Driver Class Initialized
INFO - 2022-11-29 11:16:26 --> Helper loaded: form_helper
INFO - 2022-11-29 11:16:26 --> Form Validation Class Initialized
INFO - 2022-11-29 11:16:26 --> Controller Class Initialized
INFO - 2022-11-29 11:16:26 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:16:26 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:16:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:16:26 --> Final output sent to browser
DEBUG - 2022-11-29 11:16:26 --> Total execution time: 0.0367
INFO - 2022-11-29 11:16:26 --> Config Class Initialized
INFO - 2022-11-29 11:16:26 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:16:26 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:16:26 --> Utf8 Class Initialized
INFO - 2022-11-29 11:16:26 --> URI Class Initialized
INFO - 2022-11-29 11:16:26 --> Router Class Initialized
INFO - 2022-11-29 11:16:26 --> Output Class Initialized
INFO - 2022-11-29 11:16:26 --> Security Class Initialized
DEBUG - 2022-11-29 11:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:16:26 --> Input Class Initialized
INFO - 2022-11-29 11:16:26 --> Language Class Initialized
INFO - 2022-11-29 11:16:26 --> Loader Class Initialized
INFO - 2022-11-29 11:16:26 --> Helper loaded: url_helper
INFO - 2022-11-29 11:16:26 --> Database Driver Class Initialized
INFO - 2022-11-29 11:16:26 --> Helper loaded: form_helper
INFO - 2022-11-29 11:16:26 --> Form Validation Class Initialized
INFO - 2022-11-29 11:16:26 --> Controller Class Initialized
INFO - 2022-11-29 11:16:26 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:16:26 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:16:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:16:26 --> Final output sent to browser
DEBUG - 2022-11-29 11:16:26 --> Total execution time: 0.0535
INFO - 2022-11-29 11:16:27 --> Config Class Initialized
INFO - 2022-11-29 11:16:27 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:16:27 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:16:27 --> Utf8 Class Initialized
INFO - 2022-11-29 11:16:27 --> URI Class Initialized
INFO - 2022-11-29 11:16:27 --> Router Class Initialized
INFO - 2022-11-29 11:16:27 --> Output Class Initialized
INFO - 2022-11-29 11:16:27 --> Security Class Initialized
DEBUG - 2022-11-29 11:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:16:27 --> Input Class Initialized
INFO - 2022-11-29 11:16:27 --> Language Class Initialized
INFO - 2022-11-29 11:16:27 --> Loader Class Initialized
INFO - 2022-11-29 11:16:27 --> Helper loaded: url_helper
INFO - 2022-11-29 11:16:27 --> Database Driver Class Initialized
INFO - 2022-11-29 11:16:27 --> Helper loaded: form_helper
INFO - 2022-11-29 11:16:27 --> Form Validation Class Initialized
INFO - 2022-11-29 11:16:27 --> Controller Class Initialized
INFO - 2022-11-29 11:16:27 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:16:27 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:16:27 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:16:27 --> Final output sent to browser
DEBUG - 2022-11-29 11:16:27 --> Total execution time: 0.0388
INFO - 2022-11-29 11:16:39 --> Config Class Initialized
INFO - 2022-11-29 11:16:39 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:16:39 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:16:39 --> Utf8 Class Initialized
INFO - 2022-11-29 11:16:39 --> URI Class Initialized
INFO - 2022-11-29 11:16:39 --> Router Class Initialized
INFO - 2022-11-29 11:16:39 --> Output Class Initialized
INFO - 2022-11-29 11:16:39 --> Security Class Initialized
DEBUG - 2022-11-29 11:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:16:39 --> Input Class Initialized
INFO - 2022-11-29 11:16:39 --> Language Class Initialized
INFO - 2022-11-29 11:16:39 --> Loader Class Initialized
INFO - 2022-11-29 11:16:39 --> Helper loaded: url_helper
INFO - 2022-11-29 11:16:39 --> Database Driver Class Initialized
INFO - 2022-11-29 11:16:39 --> Helper loaded: form_helper
INFO - 2022-11-29 11:16:39 --> Form Validation Class Initialized
INFO - 2022-11-29 11:16:39 --> Controller Class Initialized
INFO - 2022-11-29 11:16:39 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:16:39 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:16:39 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:16:39 --> Final output sent to browser
DEBUG - 2022-11-29 11:16:39 --> Total execution time: 0.0659
INFO - 2022-11-29 11:16:39 --> Config Class Initialized
INFO - 2022-11-29 11:16:39 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:16:39 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:16:39 --> Utf8 Class Initialized
INFO - 2022-11-29 11:16:39 --> URI Class Initialized
INFO - 2022-11-29 11:16:39 --> Router Class Initialized
INFO - 2022-11-29 11:16:39 --> Output Class Initialized
INFO - 2022-11-29 11:16:39 --> Security Class Initialized
DEBUG - 2022-11-29 11:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:16:39 --> Input Class Initialized
INFO - 2022-11-29 11:16:39 --> Language Class Initialized
INFO - 2022-11-29 11:16:39 --> Loader Class Initialized
INFO - 2022-11-29 11:16:39 --> Helper loaded: url_helper
INFO - 2022-11-29 11:16:39 --> Database Driver Class Initialized
INFO - 2022-11-29 11:16:39 --> Helper loaded: form_helper
INFO - 2022-11-29 11:16:39 --> Form Validation Class Initialized
INFO - 2022-11-29 11:16:39 --> Controller Class Initialized
INFO - 2022-11-29 11:16:39 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:16:39 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:16:39 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:16:39 --> Final output sent to browser
DEBUG - 2022-11-29 11:16:39 --> Total execution time: 0.0521
INFO - 2022-11-29 11:16:39 --> Config Class Initialized
INFO - 2022-11-29 11:16:39 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:16:39 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:16:39 --> Utf8 Class Initialized
INFO - 2022-11-29 11:16:39 --> URI Class Initialized
INFO - 2022-11-29 11:16:39 --> Router Class Initialized
INFO - 2022-11-29 11:16:39 --> Output Class Initialized
INFO - 2022-11-29 11:16:39 --> Security Class Initialized
DEBUG - 2022-11-29 11:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:16:39 --> Input Class Initialized
INFO - 2022-11-29 11:16:39 --> Language Class Initialized
INFO - 2022-11-29 11:16:39 --> Loader Class Initialized
INFO - 2022-11-29 11:16:39 --> Helper loaded: url_helper
INFO - 2022-11-29 11:16:39 --> Database Driver Class Initialized
INFO - 2022-11-29 11:16:39 --> Helper loaded: form_helper
INFO - 2022-11-29 11:16:39 --> Form Validation Class Initialized
INFO - 2022-11-29 11:16:39 --> Controller Class Initialized
INFO - 2022-11-29 11:16:39 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:16:39 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:16:39 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:16:39 --> Final output sent to browser
DEBUG - 2022-11-29 11:16:39 --> Total execution time: 0.0479
INFO - 2022-11-29 11:17:08 --> Config Class Initialized
INFO - 2022-11-29 11:17:08 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:17:08 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:17:08 --> Utf8 Class Initialized
INFO - 2022-11-29 11:17:08 --> URI Class Initialized
INFO - 2022-11-29 11:17:08 --> Router Class Initialized
INFO - 2022-11-29 11:17:08 --> Output Class Initialized
INFO - 2022-11-29 11:17:08 --> Security Class Initialized
DEBUG - 2022-11-29 11:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:17:08 --> Input Class Initialized
INFO - 2022-11-29 11:17:08 --> Language Class Initialized
INFO - 2022-11-29 11:17:08 --> Loader Class Initialized
INFO - 2022-11-29 11:17:08 --> Helper loaded: url_helper
INFO - 2022-11-29 11:17:08 --> Database Driver Class Initialized
INFO - 2022-11-29 11:17:08 --> Helper loaded: form_helper
INFO - 2022-11-29 11:17:08 --> Form Validation Class Initialized
INFO - 2022-11-29 11:17:08 --> Controller Class Initialized
INFO - 2022-11-29 11:17:08 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:17:08 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:17:08 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:17:08 --> Final output sent to browser
DEBUG - 2022-11-29 11:17:08 --> Total execution time: 0.0399
INFO - 2022-11-29 11:17:27 --> Config Class Initialized
INFO - 2022-11-29 11:17:27 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:17:27 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:17:27 --> Utf8 Class Initialized
INFO - 2022-11-29 11:17:27 --> URI Class Initialized
INFO - 2022-11-29 11:17:27 --> Router Class Initialized
INFO - 2022-11-29 11:17:27 --> Output Class Initialized
INFO - 2022-11-29 11:17:27 --> Security Class Initialized
DEBUG - 2022-11-29 11:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:17:27 --> Input Class Initialized
INFO - 2022-11-29 11:17:27 --> Language Class Initialized
INFO - 2022-11-29 11:17:27 --> Loader Class Initialized
INFO - 2022-11-29 11:17:27 --> Helper loaded: url_helper
INFO - 2022-11-29 11:17:27 --> Database Driver Class Initialized
INFO - 2022-11-29 11:17:27 --> Helper loaded: form_helper
INFO - 2022-11-29 11:17:27 --> Form Validation Class Initialized
INFO - 2022-11-29 11:17:27 --> Controller Class Initialized
INFO - 2022-11-29 11:17:27 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:17:27 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:17:27 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:17:27 --> Final output sent to browser
DEBUG - 2022-11-29 11:17:27 --> Total execution time: 0.0600
INFO - 2022-11-29 11:17:28 --> Config Class Initialized
INFO - 2022-11-29 11:17:28 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:17:28 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:17:28 --> Utf8 Class Initialized
INFO - 2022-11-29 11:17:28 --> URI Class Initialized
INFO - 2022-11-29 11:17:28 --> Router Class Initialized
INFO - 2022-11-29 11:17:28 --> Output Class Initialized
INFO - 2022-11-29 11:17:28 --> Security Class Initialized
DEBUG - 2022-11-29 11:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:17:28 --> Input Class Initialized
INFO - 2022-11-29 11:17:28 --> Language Class Initialized
INFO - 2022-11-29 11:17:28 --> Loader Class Initialized
INFO - 2022-11-29 11:17:28 --> Helper loaded: url_helper
INFO - 2022-11-29 11:17:28 --> Database Driver Class Initialized
INFO - 2022-11-29 11:17:28 --> Helper loaded: form_helper
INFO - 2022-11-29 11:17:28 --> Form Validation Class Initialized
INFO - 2022-11-29 11:17:28 --> Controller Class Initialized
INFO - 2022-11-29 11:17:28 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:17:28 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:17:28 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:17:28 --> Final output sent to browser
DEBUG - 2022-11-29 11:17:28 --> Total execution time: 0.0542
INFO - 2022-11-29 11:17:28 --> Config Class Initialized
INFO - 2022-11-29 11:17:28 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:17:28 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:17:28 --> Utf8 Class Initialized
INFO - 2022-11-29 11:17:28 --> URI Class Initialized
INFO - 2022-11-29 11:17:28 --> Router Class Initialized
INFO - 2022-11-29 11:17:28 --> Output Class Initialized
INFO - 2022-11-29 11:17:28 --> Security Class Initialized
DEBUG - 2022-11-29 11:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:17:28 --> Input Class Initialized
INFO - 2022-11-29 11:17:28 --> Language Class Initialized
INFO - 2022-11-29 11:17:28 --> Loader Class Initialized
INFO - 2022-11-29 11:17:28 --> Helper loaded: url_helper
INFO - 2022-11-29 11:17:28 --> Database Driver Class Initialized
INFO - 2022-11-29 11:17:28 --> Helper loaded: form_helper
INFO - 2022-11-29 11:17:28 --> Form Validation Class Initialized
INFO - 2022-11-29 11:17:28 --> Controller Class Initialized
INFO - 2022-11-29 11:17:28 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:17:28 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:17:28 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:17:28 --> Final output sent to browser
DEBUG - 2022-11-29 11:17:28 --> Total execution time: 0.0538
INFO - 2022-11-29 11:17:47 --> Config Class Initialized
INFO - 2022-11-29 11:17:47 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:17:47 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:17:47 --> Utf8 Class Initialized
INFO - 2022-11-29 11:17:47 --> URI Class Initialized
INFO - 2022-11-29 11:17:47 --> Router Class Initialized
INFO - 2022-11-29 11:17:47 --> Output Class Initialized
INFO - 2022-11-29 11:17:47 --> Security Class Initialized
DEBUG - 2022-11-29 11:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:17:47 --> Input Class Initialized
INFO - 2022-11-29 11:17:47 --> Language Class Initialized
INFO - 2022-11-29 11:17:47 --> Loader Class Initialized
INFO - 2022-11-29 11:17:47 --> Helper loaded: url_helper
INFO - 2022-11-29 11:17:47 --> Database Driver Class Initialized
INFO - 2022-11-29 11:17:47 --> Helper loaded: form_helper
INFO - 2022-11-29 11:17:47 --> Form Validation Class Initialized
INFO - 2022-11-29 11:17:47 --> Controller Class Initialized
INFO - 2022-11-29 11:17:47 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:17:47 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:17:47 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:17:47 --> Final output sent to browser
DEBUG - 2022-11-29 11:17:47 --> Total execution time: 0.0384
INFO - 2022-11-29 11:18:07 --> Config Class Initialized
INFO - 2022-11-29 11:18:07 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:07 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:07 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:07 --> URI Class Initialized
INFO - 2022-11-29 11:18:07 --> Router Class Initialized
INFO - 2022-11-29 11:18:07 --> Output Class Initialized
INFO - 2022-11-29 11:18:07 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:07 --> Input Class Initialized
INFO - 2022-11-29 11:18:07 --> Language Class Initialized
INFO - 2022-11-29 11:18:07 --> Loader Class Initialized
INFO - 2022-11-29 11:18:07 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:07 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:07 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:07 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:07 --> Controller Class Initialized
INFO - 2022-11-29 11:18:07 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:07 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:07 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:07 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:07 --> Total execution time: 0.0600
INFO - 2022-11-29 11:18:07 --> Config Class Initialized
INFO - 2022-11-29 11:18:07 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:07 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:07 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:07 --> URI Class Initialized
INFO - 2022-11-29 11:18:07 --> Router Class Initialized
INFO - 2022-11-29 11:18:07 --> Output Class Initialized
INFO - 2022-11-29 11:18:07 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:07 --> Input Class Initialized
INFO - 2022-11-29 11:18:07 --> Language Class Initialized
INFO - 2022-11-29 11:18:07 --> Loader Class Initialized
INFO - 2022-11-29 11:18:07 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:07 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:07 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:07 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:07 --> Controller Class Initialized
INFO - 2022-11-29 11:18:07 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:07 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:07 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:07 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:07 --> Total execution time: 0.0546
INFO - 2022-11-29 11:18:07 --> Config Class Initialized
INFO - 2022-11-29 11:18:07 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:07 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:07 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:07 --> URI Class Initialized
INFO - 2022-11-29 11:18:07 --> Router Class Initialized
INFO - 2022-11-29 11:18:07 --> Output Class Initialized
INFO - 2022-11-29 11:18:07 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:07 --> Input Class Initialized
INFO - 2022-11-29 11:18:07 --> Language Class Initialized
INFO - 2022-11-29 11:18:07 --> Loader Class Initialized
INFO - 2022-11-29 11:18:07 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:07 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:07 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:07 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:07 --> Controller Class Initialized
INFO - 2022-11-29 11:18:07 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:07 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:07 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:07 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:07 --> Total execution time: 0.0553
INFO - 2022-11-29 11:18:17 --> Config Class Initialized
INFO - 2022-11-29 11:18:17 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:17 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:17 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:17 --> URI Class Initialized
INFO - 2022-11-29 11:18:17 --> Router Class Initialized
INFO - 2022-11-29 11:18:17 --> Output Class Initialized
INFO - 2022-11-29 11:18:17 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:17 --> Input Class Initialized
INFO - 2022-11-29 11:18:17 --> Language Class Initialized
INFO - 2022-11-29 11:18:17 --> Loader Class Initialized
INFO - 2022-11-29 11:18:17 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:17 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:17 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:17 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:17 --> Controller Class Initialized
INFO - 2022-11-29 11:18:17 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:17 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:17 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:17 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:17 --> Total execution time: 0.0674
INFO - 2022-11-29 11:18:17 --> Config Class Initialized
INFO - 2022-11-29 11:18:17 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:17 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:17 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:17 --> URI Class Initialized
INFO - 2022-11-29 11:18:17 --> Router Class Initialized
INFO - 2022-11-29 11:18:17 --> Output Class Initialized
INFO - 2022-11-29 11:18:17 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:17 --> Input Class Initialized
INFO - 2022-11-29 11:18:17 --> Language Class Initialized
INFO - 2022-11-29 11:18:17 --> Loader Class Initialized
INFO - 2022-11-29 11:18:17 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:17 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:17 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:17 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:18 --> Controller Class Initialized
INFO - 2022-11-29 11:18:18 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:18 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:18 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:18 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:18 --> Total execution time: 0.0513
INFO - 2022-11-29 11:18:24 --> Config Class Initialized
INFO - 2022-11-29 11:18:24 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:24 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:24 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:24 --> URI Class Initialized
INFO - 2022-11-29 11:18:24 --> Router Class Initialized
INFO - 2022-11-29 11:18:24 --> Output Class Initialized
INFO - 2022-11-29 11:18:24 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:24 --> Input Class Initialized
INFO - 2022-11-29 11:18:24 --> Language Class Initialized
INFO - 2022-11-29 11:18:24 --> Loader Class Initialized
INFO - 2022-11-29 11:18:24 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:24 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:24 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:24 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:24 --> Controller Class Initialized
INFO - 2022-11-29 11:18:24 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:24 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:24 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:24 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:24 --> Total execution time: 0.0676
INFO - 2022-11-29 11:18:24 --> Config Class Initialized
INFO - 2022-11-29 11:18:24 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:24 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:24 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:24 --> URI Class Initialized
INFO - 2022-11-29 11:18:24 --> Router Class Initialized
INFO - 2022-11-29 11:18:24 --> Output Class Initialized
INFO - 2022-11-29 11:18:24 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:24 --> Input Class Initialized
INFO - 2022-11-29 11:18:24 --> Language Class Initialized
INFO - 2022-11-29 11:18:24 --> Loader Class Initialized
INFO - 2022-11-29 11:18:24 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:24 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:24 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:24 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:24 --> Controller Class Initialized
INFO - 2022-11-29 11:18:24 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:24 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:24 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:24 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:24 --> Total execution time: 0.0507
INFO - 2022-11-29 11:18:24 --> Config Class Initialized
INFO - 2022-11-29 11:18:24 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:24 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:24 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:24 --> URI Class Initialized
INFO - 2022-11-29 11:18:24 --> Router Class Initialized
INFO - 2022-11-29 11:18:24 --> Output Class Initialized
INFO - 2022-11-29 11:18:24 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:24 --> Input Class Initialized
INFO - 2022-11-29 11:18:24 --> Language Class Initialized
INFO - 2022-11-29 11:18:24 --> Loader Class Initialized
INFO - 2022-11-29 11:18:24 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:24 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:24 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:24 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:24 --> Controller Class Initialized
INFO - 2022-11-29 11:18:24 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:24 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:24 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:24 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:24 --> Total execution time: 0.0380
INFO - 2022-11-29 11:18:30 --> Config Class Initialized
INFO - 2022-11-29 11:18:30 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:30 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:30 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:30 --> URI Class Initialized
INFO - 2022-11-29 11:18:30 --> Router Class Initialized
INFO - 2022-11-29 11:18:30 --> Output Class Initialized
INFO - 2022-11-29 11:18:30 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:30 --> Input Class Initialized
INFO - 2022-11-29 11:18:30 --> Language Class Initialized
INFO - 2022-11-29 11:18:30 --> Loader Class Initialized
INFO - 2022-11-29 11:18:30 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:30 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:30 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:30 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:30 --> Controller Class Initialized
INFO - 2022-11-29 11:18:30 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:30 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:30 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:30 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:30 --> Total execution time: 0.0462
INFO - 2022-11-29 11:18:31 --> Config Class Initialized
INFO - 2022-11-29 11:18:31 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:31 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:31 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:31 --> URI Class Initialized
INFO - 2022-11-29 11:18:31 --> Router Class Initialized
INFO - 2022-11-29 11:18:31 --> Output Class Initialized
INFO - 2022-11-29 11:18:31 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:31 --> Input Class Initialized
INFO - 2022-11-29 11:18:31 --> Language Class Initialized
INFO - 2022-11-29 11:18:31 --> Loader Class Initialized
INFO - 2022-11-29 11:18:31 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:31 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:31 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:31 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:31 --> Controller Class Initialized
INFO - 2022-11-29 11:18:31 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:31 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:31 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:31 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:31 --> Total execution time: 0.0358
INFO - 2022-11-29 11:18:31 --> Config Class Initialized
INFO - 2022-11-29 11:18:31 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:31 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:31 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:31 --> URI Class Initialized
INFO - 2022-11-29 11:18:31 --> Router Class Initialized
INFO - 2022-11-29 11:18:31 --> Output Class Initialized
INFO - 2022-11-29 11:18:31 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:31 --> Input Class Initialized
INFO - 2022-11-29 11:18:31 --> Language Class Initialized
INFO - 2022-11-29 11:18:31 --> Loader Class Initialized
INFO - 2022-11-29 11:18:31 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:31 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:31 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:31 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:31 --> Controller Class Initialized
INFO - 2022-11-29 11:18:31 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:31 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:31 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:31 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:31 --> Total execution time: 0.0342
INFO - 2022-11-29 11:18:36 --> Config Class Initialized
INFO - 2022-11-29 11:18:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:36 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:36 --> URI Class Initialized
INFO - 2022-11-29 11:18:36 --> Router Class Initialized
INFO - 2022-11-29 11:18:36 --> Output Class Initialized
INFO - 2022-11-29 11:18:36 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:36 --> Input Class Initialized
INFO - 2022-11-29 11:18:36 --> Language Class Initialized
INFO - 2022-11-29 11:18:36 --> Loader Class Initialized
INFO - 2022-11-29 11:18:36 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:36 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:36 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:36 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:36 --> Controller Class Initialized
INFO - 2022-11-29 11:18:36 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:36 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:36 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:36 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:36 --> Total execution time: 0.0360
INFO - 2022-11-29 11:18:36 --> Config Class Initialized
INFO - 2022-11-29 11:18:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:36 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:36 --> URI Class Initialized
INFO - 2022-11-29 11:18:36 --> Router Class Initialized
INFO - 2022-11-29 11:18:36 --> Output Class Initialized
INFO - 2022-11-29 11:18:36 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:36 --> Input Class Initialized
INFO - 2022-11-29 11:18:36 --> Language Class Initialized
INFO - 2022-11-29 11:18:36 --> Loader Class Initialized
INFO - 2022-11-29 11:18:36 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:36 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:36 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:36 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:36 --> Controller Class Initialized
INFO - 2022-11-29 11:18:36 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:36 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:36 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:36 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:36 --> Total execution time: 0.0345
INFO - 2022-11-29 11:18:36 --> Config Class Initialized
INFO - 2022-11-29 11:18:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:36 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:36 --> URI Class Initialized
INFO - 2022-11-29 11:18:36 --> Router Class Initialized
INFO - 2022-11-29 11:18:36 --> Output Class Initialized
INFO - 2022-11-29 11:18:36 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:36 --> Input Class Initialized
INFO - 2022-11-29 11:18:36 --> Language Class Initialized
INFO - 2022-11-29 11:18:36 --> Loader Class Initialized
INFO - 2022-11-29 11:18:36 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:36 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:36 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:36 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:36 --> Controller Class Initialized
INFO - 2022-11-29 11:18:36 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:36 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:36 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:36 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:36 --> Total execution time: 0.0350
INFO - 2022-11-29 11:18:36 --> Config Class Initialized
INFO - 2022-11-29 11:18:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:36 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:36 --> URI Class Initialized
INFO - 2022-11-29 11:18:36 --> Router Class Initialized
INFO - 2022-11-29 11:18:36 --> Output Class Initialized
INFO - 2022-11-29 11:18:36 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:36 --> Input Class Initialized
INFO - 2022-11-29 11:18:36 --> Language Class Initialized
INFO - 2022-11-29 11:18:36 --> Loader Class Initialized
INFO - 2022-11-29 11:18:36 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:36 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:36 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:36 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:36 --> Controller Class Initialized
INFO - 2022-11-29 11:18:36 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:36 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:36 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:36 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:36 --> Total execution time: 0.0464
INFO - 2022-11-29 11:18:36 --> Config Class Initialized
INFO - 2022-11-29 11:18:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:36 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:36 --> URI Class Initialized
INFO - 2022-11-29 11:18:36 --> Router Class Initialized
INFO - 2022-11-29 11:18:36 --> Output Class Initialized
INFO - 2022-11-29 11:18:36 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:36 --> Input Class Initialized
INFO - 2022-11-29 11:18:36 --> Language Class Initialized
INFO - 2022-11-29 11:18:36 --> Loader Class Initialized
INFO - 2022-11-29 11:18:36 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:36 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:37 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:37 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:37 --> Controller Class Initialized
INFO - 2022-11-29 11:18:37 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:37 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:37 --> Total execution time: 0.0537
INFO - 2022-11-29 11:18:37 --> Config Class Initialized
INFO - 2022-11-29 11:18:37 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:37 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:37 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:37 --> URI Class Initialized
INFO - 2022-11-29 11:18:37 --> Router Class Initialized
INFO - 2022-11-29 11:18:37 --> Output Class Initialized
INFO - 2022-11-29 11:18:37 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:37 --> Input Class Initialized
INFO - 2022-11-29 11:18:37 --> Language Class Initialized
INFO - 2022-11-29 11:18:37 --> Loader Class Initialized
INFO - 2022-11-29 11:18:37 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:37 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:37 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:37 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:37 --> Controller Class Initialized
INFO - 2022-11-29 11:18:37 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:37 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:37 --> Total execution time: 0.0321
INFO - 2022-11-29 11:18:37 --> Config Class Initialized
INFO - 2022-11-29 11:18:37 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:37 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:37 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:37 --> URI Class Initialized
INFO - 2022-11-29 11:18:37 --> Router Class Initialized
INFO - 2022-11-29 11:18:37 --> Output Class Initialized
INFO - 2022-11-29 11:18:37 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:37 --> Input Class Initialized
INFO - 2022-11-29 11:18:37 --> Language Class Initialized
INFO - 2022-11-29 11:18:37 --> Loader Class Initialized
INFO - 2022-11-29 11:18:37 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:37 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:37 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:37 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:37 --> Controller Class Initialized
INFO - 2022-11-29 11:18:37 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:37 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:37 --> Total execution time: 0.0312
INFO - 2022-11-29 11:18:37 --> Config Class Initialized
INFO - 2022-11-29 11:18:37 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:37 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:37 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:37 --> URI Class Initialized
INFO - 2022-11-29 11:18:37 --> Router Class Initialized
INFO - 2022-11-29 11:18:37 --> Output Class Initialized
INFO - 2022-11-29 11:18:37 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:37 --> Input Class Initialized
INFO - 2022-11-29 11:18:37 --> Language Class Initialized
INFO - 2022-11-29 11:18:37 --> Loader Class Initialized
INFO - 2022-11-29 11:18:37 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:37 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:37 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:37 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:37 --> Controller Class Initialized
INFO - 2022-11-29 11:18:37 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:37 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:37 --> Total execution time: 0.0354
INFO - 2022-11-29 11:18:37 --> Config Class Initialized
INFO - 2022-11-29 11:18:37 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:37 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:37 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:37 --> URI Class Initialized
INFO - 2022-11-29 11:18:37 --> Router Class Initialized
INFO - 2022-11-29 11:18:37 --> Output Class Initialized
INFO - 2022-11-29 11:18:37 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:37 --> Input Class Initialized
INFO - 2022-11-29 11:18:37 --> Language Class Initialized
INFO - 2022-11-29 11:18:37 --> Loader Class Initialized
INFO - 2022-11-29 11:18:37 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:37 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:37 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:37 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:37 --> Controller Class Initialized
INFO - 2022-11-29 11:18:37 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:37 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:37 --> Total execution time: 0.0350
INFO - 2022-11-29 11:18:37 --> Config Class Initialized
INFO - 2022-11-29 11:18:37 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:37 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:37 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:37 --> URI Class Initialized
INFO - 2022-11-29 11:18:37 --> Router Class Initialized
INFO - 2022-11-29 11:18:37 --> Output Class Initialized
INFO - 2022-11-29 11:18:37 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:37 --> Input Class Initialized
INFO - 2022-11-29 11:18:37 --> Language Class Initialized
INFO - 2022-11-29 11:18:37 --> Loader Class Initialized
INFO - 2022-11-29 11:18:37 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:37 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:37 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:37 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:37 --> Controller Class Initialized
INFO - 2022-11-29 11:18:37 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:37 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:37 --> Total execution time: 0.0479
INFO - 2022-11-29 11:18:38 --> Config Class Initialized
INFO - 2022-11-29 11:18:38 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:38 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:38 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:38 --> URI Class Initialized
INFO - 2022-11-29 11:18:38 --> Router Class Initialized
INFO - 2022-11-29 11:18:38 --> Output Class Initialized
INFO - 2022-11-29 11:18:38 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:38 --> Input Class Initialized
INFO - 2022-11-29 11:18:38 --> Language Class Initialized
INFO - 2022-11-29 11:18:38 --> Loader Class Initialized
INFO - 2022-11-29 11:18:38 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:38 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:38 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:38 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:38 --> Controller Class Initialized
INFO - 2022-11-29 11:18:38 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:38 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:38 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:38 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:38 --> Total execution time: 0.0348
INFO - 2022-11-29 11:18:38 --> Config Class Initialized
INFO - 2022-11-29 11:18:38 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:18:38 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:18:38 --> Utf8 Class Initialized
INFO - 2022-11-29 11:18:38 --> URI Class Initialized
INFO - 2022-11-29 11:18:38 --> Router Class Initialized
INFO - 2022-11-29 11:18:38 --> Output Class Initialized
INFO - 2022-11-29 11:18:38 --> Security Class Initialized
DEBUG - 2022-11-29 11:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:18:38 --> Input Class Initialized
INFO - 2022-11-29 11:18:38 --> Language Class Initialized
INFO - 2022-11-29 11:18:38 --> Loader Class Initialized
INFO - 2022-11-29 11:18:38 --> Helper loaded: url_helper
INFO - 2022-11-29 11:18:38 --> Database Driver Class Initialized
INFO - 2022-11-29 11:18:38 --> Helper loaded: form_helper
INFO - 2022-11-29 11:18:38 --> Form Validation Class Initialized
INFO - 2022-11-29 11:18:38 --> Controller Class Initialized
INFO - 2022-11-29 11:18:38 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:18:38 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:18:38 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:18:38 --> Final output sent to browser
DEBUG - 2022-11-29 11:18:38 --> Total execution time: 0.0324
INFO - 2022-11-29 11:19:26 --> Config Class Initialized
INFO - 2022-11-29 11:19:26 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:19:26 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:19:26 --> Utf8 Class Initialized
INFO - 2022-11-29 11:19:26 --> URI Class Initialized
INFO - 2022-11-29 11:19:26 --> Router Class Initialized
INFO - 2022-11-29 11:19:26 --> Output Class Initialized
INFO - 2022-11-29 11:19:26 --> Security Class Initialized
DEBUG - 2022-11-29 11:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:19:26 --> Input Class Initialized
INFO - 2022-11-29 11:19:26 --> Language Class Initialized
INFO - 2022-11-29 11:19:26 --> Loader Class Initialized
INFO - 2022-11-29 11:19:26 --> Helper loaded: url_helper
INFO - 2022-11-29 11:19:26 --> Database Driver Class Initialized
INFO - 2022-11-29 11:19:26 --> Helper loaded: form_helper
INFO - 2022-11-29 11:19:26 --> Form Validation Class Initialized
INFO - 2022-11-29 11:19:26 --> Controller Class Initialized
INFO - 2022-11-29 11:19:26 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:19:26 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:19:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:19:26 --> Final output sent to browser
DEBUG - 2022-11-29 11:19:26 --> Total execution time: 0.0536
INFO - 2022-11-29 11:19:26 --> Config Class Initialized
INFO - 2022-11-29 11:19:26 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:19:26 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:19:26 --> Utf8 Class Initialized
INFO - 2022-11-29 11:19:26 --> URI Class Initialized
INFO - 2022-11-29 11:19:26 --> Router Class Initialized
INFO - 2022-11-29 11:19:26 --> Output Class Initialized
INFO - 2022-11-29 11:19:26 --> Security Class Initialized
DEBUG - 2022-11-29 11:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:19:26 --> Input Class Initialized
INFO - 2022-11-29 11:19:26 --> Language Class Initialized
INFO - 2022-11-29 11:19:26 --> Loader Class Initialized
INFO - 2022-11-29 11:19:26 --> Helper loaded: url_helper
INFO - 2022-11-29 11:19:26 --> Database Driver Class Initialized
INFO - 2022-11-29 11:19:26 --> Helper loaded: form_helper
INFO - 2022-11-29 11:19:26 --> Form Validation Class Initialized
INFO - 2022-11-29 11:19:26 --> Controller Class Initialized
INFO - 2022-11-29 11:19:26 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:19:26 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:19:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:19:26 --> Final output sent to browser
DEBUG - 2022-11-29 11:19:26 --> Total execution time: 0.0347
INFO - 2022-11-29 11:19:27 --> Config Class Initialized
INFO - 2022-11-29 11:19:27 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:19:27 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:19:27 --> Utf8 Class Initialized
INFO - 2022-11-29 11:19:27 --> URI Class Initialized
INFO - 2022-11-29 11:19:27 --> Router Class Initialized
INFO - 2022-11-29 11:19:27 --> Output Class Initialized
INFO - 2022-11-29 11:19:27 --> Security Class Initialized
DEBUG - 2022-11-29 11:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:19:27 --> Input Class Initialized
INFO - 2022-11-29 11:19:27 --> Language Class Initialized
INFO - 2022-11-29 11:19:27 --> Loader Class Initialized
INFO - 2022-11-29 11:19:27 --> Helper loaded: url_helper
INFO - 2022-11-29 11:19:27 --> Database Driver Class Initialized
INFO - 2022-11-29 11:19:27 --> Helper loaded: form_helper
INFO - 2022-11-29 11:19:27 --> Form Validation Class Initialized
INFO - 2022-11-29 11:19:27 --> Controller Class Initialized
INFO - 2022-11-29 11:19:27 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:19:27 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:19:27 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:19:27 --> Final output sent to browser
DEBUG - 2022-11-29 11:19:27 --> Total execution time: 0.0579
INFO - 2022-11-29 11:19:31 --> Config Class Initialized
INFO - 2022-11-29 11:19:31 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:19:31 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:19:31 --> Utf8 Class Initialized
INFO - 2022-11-29 11:19:31 --> URI Class Initialized
INFO - 2022-11-29 11:19:31 --> Router Class Initialized
INFO - 2022-11-29 11:19:31 --> Output Class Initialized
INFO - 2022-11-29 11:19:31 --> Security Class Initialized
DEBUG - 2022-11-29 11:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:19:31 --> Input Class Initialized
INFO - 2022-11-29 11:19:31 --> Language Class Initialized
INFO - 2022-11-29 11:19:31 --> Loader Class Initialized
INFO - 2022-11-29 11:19:31 --> Helper loaded: url_helper
INFO - 2022-11-29 11:19:31 --> Database Driver Class Initialized
INFO - 2022-11-29 11:19:31 --> Helper loaded: form_helper
INFO - 2022-11-29 11:19:31 --> Form Validation Class Initialized
INFO - 2022-11-29 11:19:31 --> Controller Class Initialized
INFO - 2022-11-29 11:19:31 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:19:31 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:19:31 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:19:31 --> Final output sent to browser
DEBUG - 2022-11-29 11:19:31 --> Total execution time: 0.0512
INFO - 2022-11-29 11:19:31 --> Config Class Initialized
INFO - 2022-11-29 11:19:31 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:19:31 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:19:31 --> Utf8 Class Initialized
INFO - 2022-11-29 11:19:31 --> URI Class Initialized
INFO - 2022-11-29 11:19:31 --> Router Class Initialized
INFO - 2022-11-29 11:19:31 --> Output Class Initialized
INFO - 2022-11-29 11:19:31 --> Security Class Initialized
DEBUG - 2022-11-29 11:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:19:31 --> Input Class Initialized
INFO - 2022-11-29 11:19:31 --> Language Class Initialized
INFO - 2022-11-29 11:19:31 --> Loader Class Initialized
INFO - 2022-11-29 11:19:31 --> Helper loaded: url_helper
INFO - 2022-11-29 11:19:31 --> Database Driver Class Initialized
INFO - 2022-11-29 11:19:31 --> Helper loaded: form_helper
INFO - 2022-11-29 11:19:31 --> Form Validation Class Initialized
INFO - 2022-11-29 11:19:31 --> Controller Class Initialized
INFO - 2022-11-29 11:19:31 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:19:31 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:19:31 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:19:31 --> Final output sent to browser
DEBUG - 2022-11-29 11:19:31 --> Total execution time: 0.0359
INFO - 2022-11-29 11:19:47 --> Config Class Initialized
INFO - 2022-11-29 11:19:47 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:19:47 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:19:47 --> Utf8 Class Initialized
INFO - 2022-11-29 11:19:47 --> URI Class Initialized
INFO - 2022-11-29 11:19:47 --> Router Class Initialized
INFO - 2022-11-29 11:19:47 --> Output Class Initialized
INFO - 2022-11-29 11:19:47 --> Security Class Initialized
DEBUG - 2022-11-29 11:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:19:47 --> Input Class Initialized
INFO - 2022-11-29 11:19:47 --> Language Class Initialized
INFO - 2022-11-29 11:19:47 --> Loader Class Initialized
INFO - 2022-11-29 11:19:47 --> Helper loaded: url_helper
INFO - 2022-11-29 11:19:47 --> Database Driver Class Initialized
INFO - 2022-11-29 11:19:47 --> Helper loaded: form_helper
INFO - 2022-11-29 11:19:47 --> Form Validation Class Initialized
INFO - 2022-11-29 11:19:47 --> Controller Class Initialized
INFO - 2022-11-29 11:19:47 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:19:47 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:19:47 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:19:47 --> Final output sent to browser
DEBUG - 2022-11-29 11:19:47 --> Total execution time: 0.0500
INFO - 2022-11-29 11:19:47 --> Config Class Initialized
INFO - 2022-11-29 11:19:47 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:19:47 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:19:47 --> Utf8 Class Initialized
INFO - 2022-11-29 11:19:47 --> URI Class Initialized
INFO - 2022-11-29 11:19:47 --> Router Class Initialized
INFO - 2022-11-29 11:19:47 --> Output Class Initialized
INFO - 2022-11-29 11:19:47 --> Security Class Initialized
DEBUG - 2022-11-29 11:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:19:47 --> Input Class Initialized
INFO - 2022-11-29 11:19:47 --> Language Class Initialized
INFO - 2022-11-29 11:19:47 --> Loader Class Initialized
INFO - 2022-11-29 11:19:47 --> Helper loaded: url_helper
INFO - 2022-11-29 11:19:47 --> Database Driver Class Initialized
INFO - 2022-11-29 11:19:47 --> Helper loaded: form_helper
INFO - 2022-11-29 11:19:47 --> Form Validation Class Initialized
INFO - 2022-11-29 11:19:47 --> Controller Class Initialized
INFO - 2022-11-29 11:19:47 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:19:47 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:19:48 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:19:48 --> Final output sent to browser
DEBUG - 2022-11-29 11:19:48 --> Total execution time: 0.0550
INFO - 2022-11-29 11:19:53 --> Config Class Initialized
INFO - 2022-11-29 11:19:53 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:19:53 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:19:53 --> Utf8 Class Initialized
INFO - 2022-11-29 11:19:53 --> URI Class Initialized
INFO - 2022-11-29 11:19:53 --> Router Class Initialized
INFO - 2022-11-29 11:19:53 --> Output Class Initialized
INFO - 2022-11-29 11:19:53 --> Security Class Initialized
DEBUG - 2022-11-29 11:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:19:53 --> Input Class Initialized
INFO - 2022-11-29 11:19:53 --> Language Class Initialized
INFO - 2022-11-29 11:19:53 --> Loader Class Initialized
INFO - 2022-11-29 11:19:53 --> Helper loaded: url_helper
INFO - 2022-11-29 11:19:53 --> Database Driver Class Initialized
INFO - 2022-11-29 11:19:53 --> Helper loaded: form_helper
INFO - 2022-11-29 11:19:53 --> Form Validation Class Initialized
INFO - 2022-11-29 11:19:53 --> Controller Class Initialized
INFO - 2022-11-29 11:19:53 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:19:53 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:19:53 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:19:53 --> Final output sent to browser
DEBUG - 2022-11-29 11:19:53 --> Total execution time: 0.0591
INFO - 2022-11-29 11:19:53 --> Config Class Initialized
INFO - 2022-11-29 11:19:53 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:19:53 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:19:53 --> Utf8 Class Initialized
INFO - 2022-11-29 11:19:53 --> URI Class Initialized
INFO - 2022-11-29 11:19:53 --> Router Class Initialized
INFO - 2022-11-29 11:19:53 --> Output Class Initialized
INFO - 2022-11-29 11:19:53 --> Security Class Initialized
DEBUG - 2022-11-29 11:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:19:53 --> Input Class Initialized
INFO - 2022-11-29 11:19:53 --> Language Class Initialized
INFO - 2022-11-29 11:19:53 --> Loader Class Initialized
INFO - 2022-11-29 11:19:53 --> Helper loaded: url_helper
INFO - 2022-11-29 11:19:53 --> Database Driver Class Initialized
INFO - 2022-11-29 11:19:53 --> Helper loaded: form_helper
INFO - 2022-11-29 11:19:53 --> Form Validation Class Initialized
INFO - 2022-11-29 11:19:53 --> Controller Class Initialized
INFO - 2022-11-29 11:19:53 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:19:53 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:19:53 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:19:53 --> Final output sent to browser
DEBUG - 2022-11-29 11:19:53 --> Total execution time: 0.0362
INFO - 2022-11-29 11:19:54 --> Config Class Initialized
INFO - 2022-11-29 11:19:54 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:19:54 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:19:54 --> Utf8 Class Initialized
INFO - 2022-11-29 11:19:54 --> URI Class Initialized
INFO - 2022-11-29 11:19:54 --> Router Class Initialized
INFO - 2022-11-29 11:19:54 --> Output Class Initialized
INFO - 2022-11-29 11:19:54 --> Security Class Initialized
DEBUG - 2022-11-29 11:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:19:54 --> Input Class Initialized
INFO - 2022-11-29 11:19:54 --> Language Class Initialized
INFO - 2022-11-29 11:19:54 --> Loader Class Initialized
INFO - 2022-11-29 11:19:54 --> Helper loaded: url_helper
INFO - 2022-11-29 11:19:54 --> Database Driver Class Initialized
INFO - 2022-11-29 11:19:54 --> Helper loaded: form_helper
INFO - 2022-11-29 11:19:54 --> Form Validation Class Initialized
INFO - 2022-11-29 11:19:54 --> Controller Class Initialized
INFO - 2022-11-29 11:19:54 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:19:54 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:19:54 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:19:54 --> Final output sent to browser
DEBUG - 2022-11-29 11:19:54 --> Total execution time: 0.0384
INFO - 2022-11-29 11:22:57 --> Config Class Initialized
INFO - 2022-11-29 11:22:57 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:22:57 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:22:57 --> Utf8 Class Initialized
INFO - 2022-11-29 11:22:57 --> URI Class Initialized
INFO - 2022-11-29 11:22:57 --> Router Class Initialized
INFO - 2022-11-29 11:22:57 --> Output Class Initialized
INFO - 2022-11-29 11:22:57 --> Security Class Initialized
DEBUG - 2022-11-29 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:22:57 --> Input Class Initialized
INFO - 2022-11-29 11:22:57 --> Language Class Initialized
INFO - 2022-11-29 11:22:57 --> Loader Class Initialized
INFO - 2022-11-29 11:22:57 --> Helper loaded: url_helper
INFO - 2022-11-29 11:22:57 --> Database Driver Class Initialized
INFO - 2022-11-29 11:22:57 --> Helper loaded: form_helper
INFO - 2022-11-29 11:22:57 --> Form Validation Class Initialized
INFO - 2022-11-29 11:22:57 --> Controller Class Initialized
INFO - 2022-11-29 11:22:57 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:22:57 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:22:57 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:22:57 --> Final output sent to browser
DEBUG - 2022-11-29 11:22:57 --> Total execution time: 0.0467
INFO - 2022-11-29 11:22:57 --> Config Class Initialized
INFO - 2022-11-29 11:22:57 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:22:57 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:22:57 --> Utf8 Class Initialized
INFO - 2022-11-29 11:22:57 --> URI Class Initialized
INFO - 2022-11-29 11:22:57 --> Router Class Initialized
INFO - 2022-11-29 11:22:57 --> Output Class Initialized
INFO - 2022-11-29 11:22:57 --> Security Class Initialized
DEBUG - 2022-11-29 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:22:57 --> Input Class Initialized
INFO - 2022-11-29 11:22:57 --> Language Class Initialized
INFO - 2022-11-29 11:22:57 --> Loader Class Initialized
INFO - 2022-11-29 11:22:57 --> Helper loaded: url_helper
INFO - 2022-11-29 11:22:57 --> Database Driver Class Initialized
INFO - 2022-11-29 11:22:57 --> Helper loaded: form_helper
INFO - 2022-11-29 11:22:57 --> Form Validation Class Initialized
INFO - 2022-11-29 11:22:57 --> Controller Class Initialized
INFO - 2022-11-29 11:22:57 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:22:57 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:22:57 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:22:57 --> Final output sent to browser
DEBUG - 2022-11-29 11:22:57 --> Total execution time: 0.0351
INFO - 2022-11-29 11:22:59 --> Config Class Initialized
INFO - 2022-11-29 11:22:59 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:22:59 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:22:59 --> Utf8 Class Initialized
INFO - 2022-11-29 11:22:59 --> URI Class Initialized
INFO - 2022-11-29 11:22:59 --> Router Class Initialized
INFO - 2022-11-29 11:22:59 --> Output Class Initialized
INFO - 2022-11-29 11:22:59 --> Security Class Initialized
DEBUG - 2022-11-29 11:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:22:59 --> Input Class Initialized
INFO - 2022-11-29 11:22:59 --> Language Class Initialized
INFO - 2022-11-29 11:22:59 --> Loader Class Initialized
INFO - 2022-11-29 11:22:59 --> Helper loaded: url_helper
INFO - 2022-11-29 11:22:59 --> Database Driver Class Initialized
INFO - 2022-11-29 11:22:59 --> Helper loaded: form_helper
INFO - 2022-11-29 11:22:59 --> Form Validation Class Initialized
INFO - 2022-11-29 11:22:59 --> Controller Class Initialized
INFO - 2022-11-29 11:22:59 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:22:59 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:22:59 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:22:59 --> Final output sent to browser
DEBUG - 2022-11-29 11:22:59 --> Total execution time: 0.0360
INFO - 2022-11-29 11:23:08 --> Config Class Initialized
INFO - 2022-11-29 11:23:08 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:23:08 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:23:08 --> Utf8 Class Initialized
INFO - 2022-11-29 11:23:08 --> URI Class Initialized
INFO - 2022-11-29 11:23:08 --> Router Class Initialized
INFO - 2022-11-29 11:23:08 --> Output Class Initialized
INFO - 2022-11-29 11:23:08 --> Security Class Initialized
DEBUG - 2022-11-29 11:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:23:08 --> Input Class Initialized
INFO - 2022-11-29 11:23:08 --> Language Class Initialized
INFO - 2022-11-29 11:23:08 --> Loader Class Initialized
INFO - 2022-11-29 11:23:08 --> Helper loaded: url_helper
INFO - 2022-11-29 11:23:08 --> Database Driver Class Initialized
INFO - 2022-11-29 11:23:08 --> Helper loaded: form_helper
INFO - 2022-11-29 11:23:08 --> Form Validation Class Initialized
INFO - 2022-11-29 11:23:08 --> Controller Class Initialized
INFO - 2022-11-29 11:23:08 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:23:08 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:23:08 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:23:08 --> Final output sent to browser
DEBUG - 2022-11-29 11:23:08 --> Total execution time: 0.0484
INFO - 2022-11-29 11:23:35 --> Config Class Initialized
INFO - 2022-11-29 11:23:35 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:23:35 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:23:35 --> Utf8 Class Initialized
INFO - 2022-11-29 11:23:35 --> URI Class Initialized
INFO - 2022-11-29 11:23:35 --> Router Class Initialized
INFO - 2022-11-29 11:23:35 --> Output Class Initialized
INFO - 2022-11-29 11:23:35 --> Security Class Initialized
DEBUG - 2022-11-29 11:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:23:35 --> Input Class Initialized
INFO - 2022-11-29 11:23:35 --> Language Class Initialized
INFO - 2022-11-29 11:23:35 --> Loader Class Initialized
INFO - 2022-11-29 11:23:35 --> Helper loaded: url_helper
INFO - 2022-11-29 11:23:35 --> Database Driver Class Initialized
INFO - 2022-11-29 11:23:35 --> Helper loaded: form_helper
INFO - 2022-11-29 11:23:35 --> Form Validation Class Initialized
INFO - 2022-11-29 11:23:35 --> Controller Class Initialized
INFO - 2022-11-29 11:23:35 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:23:35 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:23:35 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:23:35 --> Final output sent to browser
DEBUG - 2022-11-29 11:23:35 --> Total execution time: 0.0403
INFO - 2022-11-29 11:23:47 --> Config Class Initialized
INFO - 2022-11-29 11:23:47 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:23:47 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:23:47 --> Utf8 Class Initialized
INFO - 2022-11-29 11:23:47 --> URI Class Initialized
INFO - 2022-11-29 11:23:47 --> Router Class Initialized
INFO - 2022-11-29 11:23:47 --> Output Class Initialized
INFO - 2022-11-29 11:23:47 --> Security Class Initialized
DEBUG - 2022-11-29 11:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:23:47 --> Input Class Initialized
INFO - 2022-11-29 11:23:47 --> Language Class Initialized
INFO - 2022-11-29 11:23:47 --> Loader Class Initialized
INFO - 2022-11-29 11:23:47 --> Helper loaded: url_helper
INFO - 2022-11-29 11:23:47 --> Database Driver Class Initialized
INFO - 2022-11-29 11:23:47 --> Helper loaded: form_helper
INFO - 2022-11-29 11:23:47 --> Form Validation Class Initialized
INFO - 2022-11-29 11:23:47 --> Controller Class Initialized
INFO - 2022-11-29 11:23:47 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:23:47 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:23:47 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:23:47 --> Final output sent to browser
DEBUG - 2022-11-29 11:23:47 --> Total execution time: 0.0523
INFO - 2022-11-29 11:23:54 --> Config Class Initialized
INFO - 2022-11-29 11:23:54 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:23:54 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:23:54 --> Utf8 Class Initialized
INFO - 2022-11-29 11:23:54 --> URI Class Initialized
INFO - 2022-11-29 11:23:54 --> Router Class Initialized
INFO - 2022-11-29 11:23:54 --> Output Class Initialized
INFO - 2022-11-29 11:23:54 --> Security Class Initialized
DEBUG - 2022-11-29 11:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:23:54 --> Input Class Initialized
INFO - 2022-11-29 11:23:54 --> Language Class Initialized
INFO - 2022-11-29 11:23:54 --> Loader Class Initialized
INFO - 2022-11-29 11:23:54 --> Helper loaded: url_helper
INFO - 2022-11-29 11:23:54 --> Database Driver Class Initialized
INFO - 2022-11-29 11:23:54 --> Helper loaded: form_helper
INFO - 2022-11-29 11:23:54 --> Form Validation Class Initialized
INFO - 2022-11-29 11:23:54 --> Controller Class Initialized
INFO - 2022-11-29 11:23:54 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:23:54 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:23:54 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:23:54 --> Final output sent to browser
DEBUG - 2022-11-29 11:23:54 --> Total execution time: 0.0604
INFO - 2022-11-29 11:24:05 --> Config Class Initialized
INFO - 2022-11-29 11:24:05 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:24:05 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:24:05 --> Utf8 Class Initialized
INFO - 2022-11-29 11:24:05 --> URI Class Initialized
INFO - 2022-11-29 11:24:05 --> Router Class Initialized
INFO - 2022-11-29 11:24:05 --> Output Class Initialized
INFO - 2022-11-29 11:24:05 --> Security Class Initialized
DEBUG - 2022-11-29 11:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:24:05 --> Input Class Initialized
INFO - 2022-11-29 11:24:05 --> Language Class Initialized
INFO - 2022-11-29 11:24:05 --> Loader Class Initialized
INFO - 2022-11-29 11:24:05 --> Helper loaded: url_helper
INFO - 2022-11-29 11:24:05 --> Database Driver Class Initialized
INFO - 2022-11-29 11:24:05 --> Helper loaded: form_helper
INFO - 2022-11-29 11:24:05 --> Form Validation Class Initialized
INFO - 2022-11-29 11:24:05 --> Controller Class Initialized
INFO - 2022-11-29 11:24:05 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:24:05 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:24:05 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:24:05 --> Final output sent to browser
DEBUG - 2022-11-29 11:24:05 --> Total execution time: 0.0514
INFO - 2022-11-29 11:24:12 --> Config Class Initialized
INFO - 2022-11-29 11:24:12 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:24:12 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:24:12 --> Utf8 Class Initialized
INFO - 2022-11-29 11:24:12 --> URI Class Initialized
INFO - 2022-11-29 11:24:12 --> Router Class Initialized
INFO - 2022-11-29 11:24:12 --> Output Class Initialized
INFO - 2022-11-29 11:24:12 --> Security Class Initialized
DEBUG - 2022-11-29 11:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:24:12 --> Input Class Initialized
INFO - 2022-11-29 11:24:12 --> Language Class Initialized
INFO - 2022-11-29 11:24:12 --> Loader Class Initialized
INFO - 2022-11-29 11:24:12 --> Helper loaded: url_helper
INFO - 2022-11-29 11:24:12 --> Database Driver Class Initialized
INFO - 2022-11-29 11:24:12 --> Helper loaded: form_helper
INFO - 2022-11-29 11:24:12 --> Form Validation Class Initialized
INFO - 2022-11-29 11:24:12 --> Controller Class Initialized
INFO - 2022-11-29 11:24:12 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:24:12 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:24:12 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:24:12 --> Final output sent to browser
DEBUG - 2022-11-29 11:24:12 --> Total execution time: 0.0366
INFO - 2022-11-29 11:24:13 --> Config Class Initialized
INFO - 2022-11-29 11:24:13 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:24:13 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:24:13 --> Utf8 Class Initialized
INFO - 2022-11-29 11:24:13 --> URI Class Initialized
INFO - 2022-11-29 11:24:13 --> Router Class Initialized
INFO - 2022-11-29 11:24:13 --> Output Class Initialized
INFO - 2022-11-29 11:24:13 --> Security Class Initialized
DEBUG - 2022-11-29 11:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:24:13 --> Input Class Initialized
INFO - 2022-11-29 11:24:13 --> Language Class Initialized
INFO - 2022-11-29 11:24:13 --> Loader Class Initialized
INFO - 2022-11-29 11:24:13 --> Helper loaded: url_helper
INFO - 2022-11-29 11:24:13 --> Database Driver Class Initialized
INFO - 2022-11-29 11:24:13 --> Helper loaded: form_helper
INFO - 2022-11-29 11:24:13 --> Form Validation Class Initialized
INFO - 2022-11-29 11:24:13 --> Controller Class Initialized
INFO - 2022-11-29 11:24:13 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:24:13 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:24:13 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:24:13 --> Final output sent to browser
DEBUG - 2022-11-29 11:24:13 --> Total execution time: 0.0399
INFO - 2022-11-29 11:24:13 --> Config Class Initialized
INFO - 2022-11-29 11:24:13 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:24:13 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:24:13 --> Utf8 Class Initialized
INFO - 2022-11-29 11:24:13 --> URI Class Initialized
INFO - 2022-11-29 11:24:13 --> Router Class Initialized
INFO - 2022-11-29 11:24:13 --> Output Class Initialized
INFO - 2022-11-29 11:24:13 --> Security Class Initialized
DEBUG - 2022-11-29 11:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:24:13 --> Input Class Initialized
INFO - 2022-11-29 11:24:13 --> Language Class Initialized
INFO - 2022-11-29 11:24:13 --> Loader Class Initialized
INFO - 2022-11-29 11:24:13 --> Helper loaded: url_helper
INFO - 2022-11-29 11:24:13 --> Database Driver Class Initialized
INFO - 2022-11-29 11:24:13 --> Helper loaded: form_helper
INFO - 2022-11-29 11:24:13 --> Form Validation Class Initialized
INFO - 2022-11-29 11:24:13 --> Controller Class Initialized
INFO - 2022-11-29 11:24:13 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:24:13 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:24:13 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:24:13 --> Final output sent to browser
DEBUG - 2022-11-29 11:24:13 --> Total execution time: 0.0360
INFO - 2022-11-29 11:24:42 --> Config Class Initialized
INFO - 2022-11-29 11:24:42 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:24:42 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:24:42 --> Utf8 Class Initialized
INFO - 2022-11-29 11:24:42 --> URI Class Initialized
INFO - 2022-11-29 11:24:42 --> Router Class Initialized
INFO - 2022-11-29 11:24:42 --> Output Class Initialized
INFO - 2022-11-29 11:24:42 --> Security Class Initialized
DEBUG - 2022-11-29 11:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:24:42 --> Input Class Initialized
INFO - 2022-11-29 11:24:42 --> Language Class Initialized
INFO - 2022-11-29 11:24:42 --> Loader Class Initialized
INFO - 2022-11-29 11:24:42 --> Helper loaded: url_helper
INFO - 2022-11-29 11:24:42 --> Database Driver Class Initialized
INFO - 2022-11-29 11:24:42 --> Helper loaded: form_helper
INFO - 2022-11-29 11:24:42 --> Form Validation Class Initialized
INFO - 2022-11-29 11:24:42 --> Controller Class Initialized
INFO - 2022-11-29 11:24:42 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:24:42 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:24:42 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:24:42 --> Final output sent to browser
DEBUG - 2022-11-29 11:24:42 --> Total execution time: 0.0474
INFO - 2022-11-29 11:24:45 --> Config Class Initialized
INFO - 2022-11-29 11:24:45 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:24:45 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:24:45 --> Utf8 Class Initialized
INFO - 2022-11-29 11:24:45 --> URI Class Initialized
INFO - 2022-11-29 11:24:45 --> Router Class Initialized
INFO - 2022-11-29 11:24:45 --> Output Class Initialized
INFO - 2022-11-29 11:24:45 --> Security Class Initialized
DEBUG - 2022-11-29 11:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:24:45 --> Input Class Initialized
INFO - 2022-11-29 11:24:45 --> Language Class Initialized
INFO - 2022-11-29 11:24:45 --> Loader Class Initialized
INFO - 2022-11-29 11:24:45 --> Helper loaded: url_helper
INFO - 2022-11-29 11:24:45 --> Database Driver Class Initialized
INFO - 2022-11-29 11:24:45 --> Helper loaded: form_helper
INFO - 2022-11-29 11:24:45 --> Form Validation Class Initialized
INFO - 2022-11-29 11:24:45 --> Controller Class Initialized
INFO - 2022-11-29 11:24:45 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:24:45 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:24:45 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:24:45 --> Final output sent to browser
DEBUG - 2022-11-29 11:24:45 --> Total execution time: 0.0521
INFO - 2022-11-29 11:25:05 --> Config Class Initialized
INFO - 2022-11-29 11:25:05 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:25:05 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:25:05 --> Utf8 Class Initialized
INFO - 2022-11-29 11:25:05 --> URI Class Initialized
INFO - 2022-11-29 11:25:05 --> Router Class Initialized
INFO - 2022-11-29 11:25:05 --> Output Class Initialized
INFO - 2022-11-29 11:25:05 --> Security Class Initialized
DEBUG - 2022-11-29 11:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:25:05 --> Input Class Initialized
INFO - 2022-11-29 11:25:05 --> Language Class Initialized
INFO - 2022-11-29 11:25:05 --> Loader Class Initialized
INFO - 2022-11-29 11:25:05 --> Helper loaded: url_helper
INFO - 2022-11-29 11:25:05 --> Database Driver Class Initialized
INFO - 2022-11-29 11:25:05 --> Helper loaded: form_helper
INFO - 2022-11-29 11:25:05 --> Form Validation Class Initialized
INFO - 2022-11-29 11:25:05 --> Controller Class Initialized
INFO - 2022-11-29 11:25:05 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:25:05 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:25:05 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:25:05 --> Final output sent to browser
DEBUG - 2022-11-29 11:25:05 --> Total execution time: 0.0595
INFO - 2022-11-29 11:25:05 --> Config Class Initialized
INFO - 2022-11-29 11:25:05 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:25:05 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:25:05 --> Utf8 Class Initialized
INFO - 2022-11-29 11:25:05 --> URI Class Initialized
INFO - 2022-11-29 11:25:05 --> Router Class Initialized
INFO - 2022-11-29 11:25:05 --> Output Class Initialized
INFO - 2022-11-29 11:25:05 --> Security Class Initialized
DEBUG - 2022-11-29 11:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:25:05 --> Input Class Initialized
INFO - 2022-11-29 11:25:05 --> Language Class Initialized
INFO - 2022-11-29 11:25:05 --> Loader Class Initialized
INFO - 2022-11-29 11:25:05 --> Helper loaded: url_helper
INFO - 2022-11-29 11:25:05 --> Database Driver Class Initialized
INFO - 2022-11-29 11:25:05 --> Helper loaded: form_helper
INFO - 2022-11-29 11:25:05 --> Form Validation Class Initialized
INFO - 2022-11-29 11:25:05 --> Controller Class Initialized
INFO - 2022-11-29 11:25:05 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:25:05 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:25:05 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:25:05 --> Final output sent to browser
DEBUG - 2022-11-29 11:25:05 --> Total execution time: 0.0588
INFO - 2022-11-29 11:25:06 --> Config Class Initialized
INFO - 2022-11-29 11:25:06 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:25:06 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:25:06 --> Utf8 Class Initialized
INFO - 2022-11-29 11:25:06 --> URI Class Initialized
INFO - 2022-11-29 11:25:06 --> Router Class Initialized
INFO - 2022-11-29 11:25:06 --> Output Class Initialized
INFO - 2022-11-29 11:25:06 --> Security Class Initialized
DEBUG - 2022-11-29 11:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:25:06 --> Input Class Initialized
INFO - 2022-11-29 11:25:06 --> Language Class Initialized
INFO - 2022-11-29 11:25:06 --> Loader Class Initialized
INFO - 2022-11-29 11:25:06 --> Helper loaded: url_helper
INFO - 2022-11-29 11:25:06 --> Database Driver Class Initialized
INFO - 2022-11-29 11:25:06 --> Helper loaded: form_helper
INFO - 2022-11-29 11:25:06 --> Form Validation Class Initialized
INFO - 2022-11-29 11:25:06 --> Controller Class Initialized
INFO - 2022-11-29 11:25:06 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:25:06 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:25:06 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:25:06 --> Final output sent to browser
DEBUG - 2022-11-29 11:25:06 --> Total execution time: 0.0323
INFO - 2022-11-29 11:25:15 --> Config Class Initialized
INFO - 2022-11-29 11:25:15 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:25:15 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:25:15 --> Utf8 Class Initialized
INFO - 2022-11-29 11:25:15 --> URI Class Initialized
INFO - 2022-11-29 11:25:15 --> Router Class Initialized
INFO - 2022-11-29 11:25:15 --> Output Class Initialized
INFO - 2022-11-29 11:25:15 --> Security Class Initialized
DEBUG - 2022-11-29 11:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:25:15 --> Input Class Initialized
INFO - 2022-11-29 11:25:15 --> Language Class Initialized
INFO - 2022-11-29 11:25:15 --> Loader Class Initialized
INFO - 2022-11-29 11:25:15 --> Helper loaded: url_helper
INFO - 2022-11-29 11:25:15 --> Database Driver Class Initialized
INFO - 2022-11-29 11:25:16 --> Helper loaded: form_helper
INFO - 2022-11-29 11:25:16 --> Form Validation Class Initialized
INFO - 2022-11-29 11:25:16 --> Controller Class Initialized
INFO - 2022-11-29 11:25:16 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:25:16 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:25:16 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:25:16 --> Final output sent to browser
DEBUG - 2022-11-29 11:25:16 --> Total execution time: 0.0614
INFO - 2022-11-29 11:25:16 --> Config Class Initialized
INFO - 2022-11-29 11:25:16 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:25:16 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:25:16 --> Utf8 Class Initialized
INFO - 2022-11-29 11:25:16 --> URI Class Initialized
INFO - 2022-11-29 11:25:16 --> Router Class Initialized
INFO - 2022-11-29 11:25:16 --> Output Class Initialized
INFO - 2022-11-29 11:25:16 --> Security Class Initialized
DEBUG - 2022-11-29 11:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:25:16 --> Input Class Initialized
INFO - 2022-11-29 11:25:16 --> Language Class Initialized
INFO - 2022-11-29 11:25:16 --> Loader Class Initialized
INFO - 2022-11-29 11:25:16 --> Helper loaded: url_helper
INFO - 2022-11-29 11:25:16 --> Database Driver Class Initialized
INFO - 2022-11-29 11:25:16 --> Helper loaded: form_helper
INFO - 2022-11-29 11:25:16 --> Form Validation Class Initialized
INFO - 2022-11-29 11:25:16 --> Controller Class Initialized
INFO - 2022-11-29 11:25:16 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:25:16 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:25:16 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:25:16 --> Final output sent to browser
DEBUG - 2022-11-29 11:25:16 --> Total execution time: 0.0526
INFO - 2022-11-29 11:25:34 --> Config Class Initialized
INFO - 2022-11-29 11:25:34 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:25:34 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:25:34 --> Utf8 Class Initialized
INFO - 2022-11-29 11:25:34 --> URI Class Initialized
INFO - 2022-11-29 11:25:34 --> Router Class Initialized
INFO - 2022-11-29 11:25:34 --> Output Class Initialized
INFO - 2022-11-29 11:25:34 --> Security Class Initialized
DEBUG - 2022-11-29 11:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:25:34 --> Input Class Initialized
INFO - 2022-11-29 11:25:34 --> Language Class Initialized
INFO - 2022-11-29 11:25:34 --> Loader Class Initialized
INFO - 2022-11-29 11:25:34 --> Helper loaded: url_helper
INFO - 2022-11-29 11:25:34 --> Database Driver Class Initialized
INFO - 2022-11-29 11:25:34 --> Helper loaded: form_helper
INFO - 2022-11-29 11:25:34 --> Form Validation Class Initialized
INFO - 2022-11-29 11:25:34 --> Controller Class Initialized
INFO - 2022-11-29 11:25:34 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:25:34 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:25:34 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:25:34 --> Final output sent to browser
DEBUG - 2022-11-29 11:25:34 --> Total execution time: 0.0488
INFO - 2022-11-29 11:25:43 --> Config Class Initialized
INFO - 2022-11-29 11:25:43 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:25:43 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:25:43 --> Utf8 Class Initialized
INFO - 2022-11-29 11:25:43 --> URI Class Initialized
INFO - 2022-11-29 11:25:43 --> Router Class Initialized
INFO - 2022-11-29 11:25:43 --> Output Class Initialized
INFO - 2022-11-29 11:25:43 --> Security Class Initialized
DEBUG - 2022-11-29 11:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:25:43 --> Input Class Initialized
INFO - 2022-11-29 11:25:43 --> Language Class Initialized
INFO - 2022-11-29 11:25:43 --> Loader Class Initialized
INFO - 2022-11-29 11:25:43 --> Helper loaded: url_helper
INFO - 2022-11-29 11:25:43 --> Database Driver Class Initialized
INFO - 2022-11-29 11:25:43 --> Helper loaded: form_helper
INFO - 2022-11-29 11:25:43 --> Form Validation Class Initialized
INFO - 2022-11-29 11:25:43 --> Controller Class Initialized
INFO - 2022-11-29 11:25:43 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:25:43 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:25:43 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:25:43 --> Final output sent to browser
DEBUG - 2022-11-29 11:25:43 --> Total execution time: 0.0542
INFO - 2022-11-29 11:25:43 --> Config Class Initialized
INFO - 2022-11-29 11:25:43 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:25:43 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:25:43 --> Utf8 Class Initialized
INFO - 2022-11-29 11:25:43 --> URI Class Initialized
INFO - 2022-11-29 11:25:43 --> Router Class Initialized
INFO - 2022-11-29 11:25:43 --> Output Class Initialized
INFO - 2022-11-29 11:25:43 --> Security Class Initialized
DEBUG - 2022-11-29 11:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:25:43 --> Input Class Initialized
INFO - 2022-11-29 11:25:43 --> Language Class Initialized
INFO - 2022-11-29 11:25:43 --> Loader Class Initialized
INFO - 2022-11-29 11:25:43 --> Helper loaded: url_helper
INFO - 2022-11-29 11:25:43 --> Database Driver Class Initialized
INFO - 2022-11-29 11:25:43 --> Helper loaded: form_helper
INFO - 2022-11-29 11:25:43 --> Form Validation Class Initialized
INFO - 2022-11-29 11:25:43 --> Controller Class Initialized
INFO - 2022-11-29 11:25:43 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:25:43 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:25:43 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:25:43 --> Final output sent to browser
DEBUG - 2022-11-29 11:25:43 --> Total execution time: 0.0561
INFO - 2022-11-29 11:25:56 --> Config Class Initialized
INFO - 2022-11-29 11:25:56 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:25:56 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:25:56 --> Utf8 Class Initialized
INFO - 2022-11-29 11:25:56 --> URI Class Initialized
INFO - 2022-11-29 11:25:56 --> Router Class Initialized
INFO - 2022-11-29 11:25:56 --> Output Class Initialized
INFO - 2022-11-29 11:25:56 --> Security Class Initialized
DEBUG - 2022-11-29 11:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:25:56 --> Input Class Initialized
INFO - 2022-11-29 11:25:56 --> Language Class Initialized
INFO - 2022-11-29 11:25:56 --> Loader Class Initialized
INFO - 2022-11-29 11:25:56 --> Helper loaded: url_helper
INFO - 2022-11-29 11:25:56 --> Database Driver Class Initialized
INFO - 2022-11-29 11:25:56 --> Helper loaded: form_helper
INFO - 2022-11-29 11:25:56 --> Form Validation Class Initialized
INFO - 2022-11-29 11:25:56 --> Controller Class Initialized
INFO - 2022-11-29 11:25:56 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:25:56 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:25:56 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:25:56 --> Final output sent to browser
DEBUG - 2022-11-29 11:25:56 --> Total execution time: 0.0383
INFO - 2022-11-29 11:26:06 --> Config Class Initialized
INFO - 2022-11-29 11:26:06 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:26:06 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:26:06 --> Utf8 Class Initialized
INFO - 2022-11-29 11:26:06 --> URI Class Initialized
INFO - 2022-11-29 11:26:06 --> Router Class Initialized
INFO - 2022-11-29 11:26:06 --> Output Class Initialized
INFO - 2022-11-29 11:26:06 --> Security Class Initialized
DEBUG - 2022-11-29 11:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:26:06 --> Input Class Initialized
INFO - 2022-11-29 11:26:06 --> Language Class Initialized
INFO - 2022-11-29 11:26:06 --> Loader Class Initialized
INFO - 2022-11-29 11:26:06 --> Helper loaded: url_helper
INFO - 2022-11-29 11:26:06 --> Database Driver Class Initialized
INFO - 2022-11-29 11:26:06 --> Helper loaded: form_helper
INFO - 2022-11-29 11:26:06 --> Form Validation Class Initialized
INFO - 2022-11-29 11:26:06 --> Controller Class Initialized
INFO - 2022-11-29 11:26:06 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:26:06 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:26:06 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:26:06 --> Final output sent to browser
DEBUG - 2022-11-29 11:26:06 --> Total execution time: 0.0536
INFO - 2022-11-29 11:26:18 --> Config Class Initialized
INFO - 2022-11-29 11:26:18 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:26:18 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:26:18 --> Utf8 Class Initialized
INFO - 2022-11-29 11:26:18 --> URI Class Initialized
INFO - 2022-11-29 11:26:18 --> Router Class Initialized
INFO - 2022-11-29 11:26:18 --> Output Class Initialized
INFO - 2022-11-29 11:26:18 --> Security Class Initialized
DEBUG - 2022-11-29 11:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:26:18 --> Input Class Initialized
INFO - 2022-11-29 11:26:18 --> Language Class Initialized
INFO - 2022-11-29 11:26:18 --> Loader Class Initialized
INFO - 2022-11-29 11:26:18 --> Helper loaded: url_helper
INFO - 2022-11-29 11:26:18 --> Database Driver Class Initialized
INFO - 2022-11-29 11:26:18 --> Helper loaded: form_helper
INFO - 2022-11-29 11:26:18 --> Form Validation Class Initialized
INFO - 2022-11-29 11:26:18 --> Controller Class Initialized
INFO - 2022-11-29 11:26:18 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:26:18 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:26:18 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:26:18 --> Final output sent to browser
DEBUG - 2022-11-29 11:26:18 --> Total execution time: 0.0382
INFO - 2022-11-29 11:26:19 --> Config Class Initialized
INFO - 2022-11-29 11:26:19 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:26:19 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:26:19 --> Utf8 Class Initialized
INFO - 2022-11-29 11:26:19 --> URI Class Initialized
INFO - 2022-11-29 11:26:19 --> Router Class Initialized
INFO - 2022-11-29 11:26:19 --> Output Class Initialized
INFO - 2022-11-29 11:26:19 --> Security Class Initialized
DEBUG - 2022-11-29 11:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:26:19 --> Input Class Initialized
INFO - 2022-11-29 11:26:19 --> Language Class Initialized
INFO - 2022-11-29 11:26:19 --> Loader Class Initialized
INFO - 2022-11-29 11:26:19 --> Helper loaded: url_helper
INFO - 2022-11-29 11:26:19 --> Database Driver Class Initialized
INFO - 2022-11-29 11:26:19 --> Helper loaded: form_helper
INFO - 2022-11-29 11:26:19 --> Form Validation Class Initialized
INFO - 2022-11-29 11:26:19 --> Controller Class Initialized
INFO - 2022-11-29 11:26:19 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:26:19 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:26:19 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:26:19 --> Final output sent to browser
DEBUG - 2022-11-29 11:26:19 --> Total execution time: 0.0493
INFO - 2022-11-29 11:26:20 --> Config Class Initialized
INFO - 2022-11-29 11:26:20 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:26:20 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:26:20 --> Utf8 Class Initialized
INFO - 2022-11-29 11:26:20 --> URI Class Initialized
INFO - 2022-11-29 11:26:20 --> Router Class Initialized
INFO - 2022-11-29 11:26:20 --> Output Class Initialized
INFO - 2022-11-29 11:26:20 --> Security Class Initialized
DEBUG - 2022-11-29 11:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:26:20 --> Input Class Initialized
INFO - 2022-11-29 11:26:20 --> Language Class Initialized
INFO - 2022-11-29 11:26:20 --> Loader Class Initialized
INFO - 2022-11-29 11:26:20 --> Helper loaded: url_helper
INFO - 2022-11-29 11:26:20 --> Database Driver Class Initialized
INFO - 2022-11-29 11:26:20 --> Helper loaded: form_helper
INFO - 2022-11-29 11:26:20 --> Form Validation Class Initialized
INFO - 2022-11-29 11:26:20 --> Controller Class Initialized
INFO - 2022-11-29 11:26:20 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:26:20 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:26:20 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:26:20 --> Final output sent to browser
DEBUG - 2022-11-29 11:26:20 --> Total execution time: 0.0559
INFO - 2022-11-29 11:26:33 --> Config Class Initialized
INFO - 2022-11-29 11:26:33 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:26:33 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:26:33 --> Utf8 Class Initialized
INFO - 2022-11-29 11:26:33 --> URI Class Initialized
INFO - 2022-11-29 11:26:33 --> Router Class Initialized
INFO - 2022-11-29 11:26:33 --> Output Class Initialized
INFO - 2022-11-29 11:26:33 --> Security Class Initialized
DEBUG - 2022-11-29 11:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:26:33 --> Input Class Initialized
INFO - 2022-11-29 11:26:33 --> Language Class Initialized
INFO - 2022-11-29 11:26:33 --> Loader Class Initialized
INFO - 2022-11-29 11:26:33 --> Helper loaded: url_helper
INFO - 2022-11-29 11:26:33 --> Database Driver Class Initialized
INFO - 2022-11-29 11:26:33 --> Helper loaded: form_helper
INFO - 2022-11-29 11:26:33 --> Form Validation Class Initialized
INFO - 2022-11-29 11:26:33 --> Controller Class Initialized
INFO - 2022-11-29 11:26:33 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:26:33 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:26:33 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:26:33 --> Final output sent to browser
DEBUG - 2022-11-29 11:26:33 --> Total execution time: 0.0558
INFO - 2022-11-29 11:26:58 --> Config Class Initialized
INFO - 2022-11-29 11:26:58 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:26:58 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:26:58 --> Utf8 Class Initialized
INFO - 2022-11-29 11:26:58 --> URI Class Initialized
INFO - 2022-11-29 11:26:58 --> Router Class Initialized
INFO - 2022-11-29 11:26:58 --> Output Class Initialized
INFO - 2022-11-29 11:26:58 --> Security Class Initialized
DEBUG - 2022-11-29 11:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:26:58 --> Input Class Initialized
INFO - 2022-11-29 11:26:58 --> Language Class Initialized
INFO - 2022-11-29 11:26:58 --> Loader Class Initialized
INFO - 2022-11-29 11:26:58 --> Helper loaded: url_helper
INFO - 2022-11-29 11:26:58 --> Database Driver Class Initialized
INFO - 2022-11-29 11:26:58 --> Helper loaded: form_helper
INFO - 2022-11-29 11:26:58 --> Form Validation Class Initialized
INFO - 2022-11-29 11:26:58 --> Controller Class Initialized
INFO - 2022-11-29 11:26:58 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:26:58 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:26:58 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:26:58 --> Final output sent to browser
DEBUG - 2022-11-29 11:26:58 --> Total execution time: 0.0534
INFO - 2022-11-29 11:28:21 --> Config Class Initialized
INFO - 2022-11-29 11:28:21 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:28:21 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:28:21 --> Utf8 Class Initialized
INFO - 2022-11-29 11:28:21 --> URI Class Initialized
INFO - 2022-11-29 11:28:21 --> Router Class Initialized
INFO - 2022-11-29 11:28:21 --> Output Class Initialized
INFO - 2022-11-29 11:28:21 --> Security Class Initialized
DEBUG - 2022-11-29 11:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:28:21 --> Input Class Initialized
INFO - 2022-11-29 11:28:21 --> Language Class Initialized
INFO - 2022-11-29 11:28:21 --> Loader Class Initialized
INFO - 2022-11-29 11:28:21 --> Helper loaded: url_helper
INFO - 2022-11-29 11:28:21 --> Database Driver Class Initialized
INFO - 2022-11-29 11:28:21 --> Helper loaded: form_helper
INFO - 2022-11-29 11:28:21 --> Form Validation Class Initialized
INFO - 2022-11-29 11:28:21 --> Controller Class Initialized
INFO - 2022-11-29 11:28:21 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:28:21 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:28:21 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:28:21 --> Final output sent to browser
DEBUG - 2022-11-29 11:28:21 --> Total execution time: 0.0571
INFO - 2022-11-29 11:28:21 --> Config Class Initialized
INFO - 2022-11-29 11:28:21 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:28:21 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:28:21 --> Utf8 Class Initialized
INFO - 2022-11-29 11:28:21 --> URI Class Initialized
INFO - 2022-11-29 11:28:21 --> Router Class Initialized
INFO - 2022-11-29 11:28:21 --> Output Class Initialized
INFO - 2022-11-29 11:28:21 --> Security Class Initialized
DEBUG - 2022-11-29 11:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:28:21 --> Input Class Initialized
INFO - 2022-11-29 11:28:21 --> Language Class Initialized
INFO - 2022-11-29 11:28:21 --> Loader Class Initialized
INFO - 2022-11-29 11:28:21 --> Helper loaded: url_helper
INFO - 2022-11-29 11:28:21 --> Database Driver Class Initialized
INFO - 2022-11-29 11:28:21 --> Helper loaded: form_helper
INFO - 2022-11-29 11:28:21 --> Form Validation Class Initialized
INFO - 2022-11-29 11:28:21 --> Controller Class Initialized
INFO - 2022-11-29 11:28:21 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:28:21 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:28:21 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:28:21 --> Final output sent to browser
DEBUG - 2022-11-29 11:28:21 --> Total execution time: 0.0379
INFO - 2022-11-29 11:28:26 --> Config Class Initialized
INFO - 2022-11-29 11:28:26 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:28:26 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:28:26 --> Utf8 Class Initialized
INFO - 2022-11-29 11:28:26 --> URI Class Initialized
INFO - 2022-11-29 11:28:26 --> Router Class Initialized
INFO - 2022-11-29 11:28:26 --> Output Class Initialized
INFO - 2022-11-29 11:28:26 --> Security Class Initialized
DEBUG - 2022-11-29 11:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:28:26 --> Input Class Initialized
INFO - 2022-11-29 11:28:26 --> Language Class Initialized
INFO - 2022-11-29 11:28:26 --> Loader Class Initialized
INFO - 2022-11-29 11:28:26 --> Helper loaded: url_helper
INFO - 2022-11-29 11:28:26 --> Database Driver Class Initialized
INFO - 2022-11-29 11:28:26 --> Helper loaded: form_helper
INFO - 2022-11-29 11:28:26 --> Form Validation Class Initialized
INFO - 2022-11-29 11:28:26 --> Controller Class Initialized
INFO - 2022-11-29 11:28:26 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:28:26 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:28:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:28:26 --> Final output sent to browser
DEBUG - 2022-11-29 11:28:26 --> Total execution time: 0.0602
INFO - 2022-11-29 11:28:44 --> Config Class Initialized
INFO - 2022-11-29 11:28:44 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:28:44 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:28:44 --> Utf8 Class Initialized
INFO - 2022-11-29 11:28:44 --> URI Class Initialized
INFO - 2022-11-29 11:28:44 --> Router Class Initialized
INFO - 2022-11-29 11:28:44 --> Output Class Initialized
INFO - 2022-11-29 11:28:44 --> Security Class Initialized
DEBUG - 2022-11-29 11:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:28:44 --> Input Class Initialized
INFO - 2022-11-29 11:28:44 --> Language Class Initialized
INFO - 2022-11-29 11:28:44 --> Loader Class Initialized
INFO - 2022-11-29 11:28:44 --> Helper loaded: url_helper
INFO - 2022-11-29 11:28:44 --> Database Driver Class Initialized
INFO - 2022-11-29 11:28:44 --> Helper loaded: form_helper
INFO - 2022-11-29 11:28:44 --> Form Validation Class Initialized
INFO - 2022-11-29 11:28:44 --> Controller Class Initialized
INFO - 2022-11-29 11:28:44 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:28:44 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:28:44 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:28:44 --> Final output sent to browser
DEBUG - 2022-11-29 11:28:44 --> Total execution time: 0.0550
INFO - 2022-11-29 11:28:46 --> Config Class Initialized
INFO - 2022-11-29 11:28:46 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:28:46 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:28:46 --> Utf8 Class Initialized
INFO - 2022-11-29 11:28:46 --> URI Class Initialized
INFO - 2022-11-29 11:28:46 --> Router Class Initialized
INFO - 2022-11-29 11:28:46 --> Output Class Initialized
INFO - 2022-11-29 11:28:46 --> Security Class Initialized
DEBUG - 2022-11-29 11:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:28:46 --> Input Class Initialized
INFO - 2022-11-29 11:28:46 --> Language Class Initialized
INFO - 2022-11-29 11:28:46 --> Loader Class Initialized
INFO - 2022-11-29 11:28:46 --> Helper loaded: url_helper
INFO - 2022-11-29 11:28:46 --> Database Driver Class Initialized
INFO - 2022-11-29 11:28:46 --> Helper loaded: form_helper
INFO - 2022-11-29 11:28:46 --> Form Validation Class Initialized
INFO - 2022-11-29 11:28:46 --> Controller Class Initialized
INFO - 2022-11-29 11:28:46 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:28:46 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:28:46 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:28:46 --> Final output sent to browser
DEBUG - 2022-11-29 11:28:46 --> Total execution time: 0.0412
INFO - 2022-11-29 11:29:32 --> Config Class Initialized
INFO - 2022-11-29 11:29:32 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:29:32 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:29:32 --> Utf8 Class Initialized
INFO - 2022-11-29 11:29:32 --> URI Class Initialized
INFO - 2022-11-29 11:29:32 --> Router Class Initialized
INFO - 2022-11-29 11:29:32 --> Output Class Initialized
INFO - 2022-11-29 11:29:32 --> Security Class Initialized
DEBUG - 2022-11-29 11:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:29:32 --> Input Class Initialized
INFO - 2022-11-29 11:29:32 --> Language Class Initialized
INFO - 2022-11-29 11:29:32 --> Loader Class Initialized
INFO - 2022-11-29 11:29:32 --> Helper loaded: url_helper
INFO - 2022-11-29 11:29:32 --> Database Driver Class Initialized
INFO - 2022-11-29 11:29:32 --> Helper loaded: form_helper
INFO - 2022-11-29 11:29:32 --> Form Validation Class Initialized
INFO - 2022-11-29 11:29:32 --> Controller Class Initialized
INFO - 2022-11-29 11:29:32 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:29:32 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:29:32 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:29:32 --> Final output sent to browser
DEBUG - 2022-11-29 11:29:32 --> Total execution time: 0.0478
INFO - 2022-11-29 11:32:42 --> Config Class Initialized
INFO - 2022-11-29 11:32:42 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:32:42 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:32:42 --> Utf8 Class Initialized
INFO - 2022-11-29 11:32:42 --> URI Class Initialized
INFO - 2022-11-29 11:32:42 --> Router Class Initialized
INFO - 2022-11-29 11:32:42 --> Output Class Initialized
INFO - 2022-11-29 11:32:42 --> Security Class Initialized
DEBUG - 2022-11-29 11:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:32:42 --> Input Class Initialized
INFO - 2022-11-29 11:32:42 --> Language Class Initialized
INFO - 2022-11-29 11:32:42 --> Loader Class Initialized
INFO - 2022-11-29 11:32:42 --> Helper loaded: url_helper
INFO - 2022-11-29 11:32:42 --> Database Driver Class Initialized
INFO - 2022-11-29 11:32:42 --> Helper loaded: form_helper
INFO - 2022-11-29 11:32:42 --> Form Validation Class Initialized
INFO - 2022-11-29 11:32:42 --> Controller Class Initialized
INFO - 2022-11-29 11:32:42 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:32:42 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:32:42 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:32:42 --> Final output sent to browser
DEBUG - 2022-11-29 11:32:42 --> Total execution time: 0.0564
INFO - 2022-11-29 11:32:43 --> Config Class Initialized
INFO - 2022-11-29 11:32:43 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:32:43 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:32:43 --> Utf8 Class Initialized
INFO - 2022-11-29 11:32:43 --> URI Class Initialized
INFO - 2022-11-29 11:32:43 --> Router Class Initialized
INFO - 2022-11-29 11:32:43 --> Output Class Initialized
INFO - 2022-11-29 11:32:43 --> Security Class Initialized
DEBUG - 2022-11-29 11:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:32:43 --> Input Class Initialized
INFO - 2022-11-29 11:32:43 --> Language Class Initialized
INFO - 2022-11-29 11:32:43 --> Loader Class Initialized
INFO - 2022-11-29 11:32:43 --> Helper loaded: url_helper
INFO - 2022-11-29 11:32:43 --> Database Driver Class Initialized
INFO - 2022-11-29 11:32:43 --> Helper loaded: form_helper
INFO - 2022-11-29 11:32:43 --> Form Validation Class Initialized
INFO - 2022-11-29 11:32:43 --> Controller Class Initialized
INFO - 2022-11-29 11:32:43 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:32:43 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:32:43 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:32:43 --> Final output sent to browser
DEBUG - 2022-11-29 11:32:43 --> Total execution time: 0.0510
INFO - 2022-11-29 11:32:48 --> Config Class Initialized
INFO - 2022-11-29 11:32:48 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:32:48 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:32:48 --> Utf8 Class Initialized
INFO - 2022-11-29 11:32:48 --> URI Class Initialized
INFO - 2022-11-29 11:32:48 --> Router Class Initialized
INFO - 2022-11-29 11:32:48 --> Output Class Initialized
INFO - 2022-11-29 11:32:48 --> Security Class Initialized
DEBUG - 2022-11-29 11:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:32:48 --> Input Class Initialized
INFO - 2022-11-29 11:32:48 --> Language Class Initialized
INFO - 2022-11-29 11:32:48 --> Loader Class Initialized
INFO - 2022-11-29 11:32:48 --> Helper loaded: url_helper
INFO - 2022-11-29 11:32:48 --> Database Driver Class Initialized
INFO - 2022-11-29 11:32:48 --> Helper loaded: form_helper
INFO - 2022-11-29 11:32:48 --> Form Validation Class Initialized
INFO - 2022-11-29 11:32:48 --> Controller Class Initialized
INFO - 2022-11-29 11:32:48 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:32:48 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:32:48 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:32:48 --> Final output sent to browser
DEBUG - 2022-11-29 11:32:48 --> Total execution time: 0.0571
INFO - 2022-11-29 11:33:05 --> Config Class Initialized
INFO - 2022-11-29 11:33:05 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:33:05 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:33:05 --> Utf8 Class Initialized
INFO - 2022-11-29 11:33:05 --> URI Class Initialized
INFO - 2022-11-29 11:33:05 --> Router Class Initialized
INFO - 2022-11-29 11:33:05 --> Output Class Initialized
INFO - 2022-11-29 11:33:05 --> Security Class Initialized
DEBUG - 2022-11-29 11:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:33:05 --> Input Class Initialized
INFO - 2022-11-29 11:33:05 --> Language Class Initialized
INFO - 2022-11-29 11:33:05 --> Loader Class Initialized
INFO - 2022-11-29 11:33:05 --> Helper loaded: url_helper
INFO - 2022-11-29 11:33:05 --> Database Driver Class Initialized
INFO - 2022-11-29 11:33:05 --> Helper loaded: form_helper
INFO - 2022-11-29 11:33:05 --> Form Validation Class Initialized
INFO - 2022-11-29 11:33:05 --> Controller Class Initialized
INFO - 2022-11-29 11:33:05 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:33:05 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:33:05 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:33:05 --> Final output sent to browser
DEBUG - 2022-11-29 11:33:05 --> Total execution time: 0.0418
INFO - 2022-11-29 11:33:06 --> Config Class Initialized
INFO - 2022-11-29 11:33:06 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:33:06 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:33:06 --> Utf8 Class Initialized
INFO - 2022-11-29 11:33:06 --> URI Class Initialized
INFO - 2022-11-29 11:33:06 --> Router Class Initialized
INFO - 2022-11-29 11:33:06 --> Output Class Initialized
INFO - 2022-11-29 11:33:06 --> Security Class Initialized
DEBUG - 2022-11-29 11:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:33:06 --> Input Class Initialized
INFO - 2022-11-29 11:33:06 --> Language Class Initialized
INFO - 2022-11-29 11:33:06 --> Loader Class Initialized
INFO - 2022-11-29 11:33:06 --> Helper loaded: url_helper
INFO - 2022-11-29 11:33:06 --> Database Driver Class Initialized
INFO - 2022-11-29 11:33:06 --> Helper loaded: form_helper
INFO - 2022-11-29 11:33:06 --> Form Validation Class Initialized
INFO - 2022-11-29 11:33:06 --> Controller Class Initialized
INFO - 2022-11-29 11:33:06 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:33:06 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:33:06 --> Final output sent to browser
DEBUG - 2022-11-29 11:33:06 --> Total execution time: 0.0747
INFO - 2022-11-29 11:33:09 --> Config Class Initialized
INFO - 2022-11-29 11:33:09 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:33:09 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:33:09 --> Utf8 Class Initialized
INFO - 2022-11-29 11:33:09 --> URI Class Initialized
INFO - 2022-11-29 11:33:09 --> Router Class Initialized
INFO - 2022-11-29 11:33:09 --> Output Class Initialized
INFO - 2022-11-29 11:33:09 --> Security Class Initialized
DEBUG - 2022-11-29 11:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:33:09 --> Input Class Initialized
INFO - 2022-11-29 11:33:09 --> Language Class Initialized
INFO - 2022-11-29 11:33:09 --> Loader Class Initialized
INFO - 2022-11-29 11:33:09 --> Helper loaded: url_helper
INFO - 2022-11-29 11:33:09 --> Database Driver Class Initialized
INFO - 2022-11-29 11:33:09 --> Helper loaded: form_helper
INFO - 2022-11-29 11:33:09 --> Form Validation Class Initialized
INFO - 2022-11-29 11:33:09 --> Controller Class Initialized
INFO - 2022-11-29 11:33:09 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:33:09 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:33:09 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:33:09 --> Final output sent to browser
DEBUG - 2022-11-29 11:33:09 --> Total execution time: 0.0354
INFO - 2022-11-29 11:33:22 --> Config Class Initialized
INFO - 2022-11-29 11:33:22 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:33:22 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:33:22 --> Utf8 Class Initialized
INFO - 2022-11-29 11:33:22 --> URI Class Initialized
INFO - 2022-11-29 11:33:22 --> Router Class Initialized
INFO - 2022-11-29 11:33:22 --> Output Class Initialized
INFO - 2022-11-29 11:33:22 --> Security Class Initialized
DEBUG - 2022-11-29 11:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:33:22 --> Input Class Initialized
INFO - 2022-11-29 11:33:22 --> Language Class Initialized
INFO - 2022-11-29 11:33:22 --> Loader Class Initialized
INFO - 2022-11-29 11:33:22 --> Helper loaded: url_helper
INFO - 2022-11-29 11:33:22 --> Database Driver Class Initialized
INFO - 2022-11-29 11:33:22 --> Helper loaded: form_helper
INFO - 2022-11-29 11:33:22 --> Form Validation Class Initialized
INFO - 2022-11-29 11:33:22 --> Controller Class Initialized
INFO - 2022-11-29 11:33:22 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:33:22 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:33:22 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:33:22 --> Final output sent to browser
DEBUG - 2022-11-29 11:33:22 --> Total execution time: 0.0356
INFO - 2022-11-29 11:33:24 --> Config Class Initialized
INFO - 2022-11-29 11:33:24 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:33:24 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:33:24 --> Utf8 Class Initialized
INFO - 2022-11-29 11:33:24 --> URI Class Initialized
INFO - 2022-11-29 11:33:24 --> Router Class Initialized
INFO - 2022-11-29 11:33:24 --> Output Class Initialized
INFO - 2022-11-29 11:33:24 --> Security Class Initialized
DEBUG - 2022-11-29 11:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:33:24 --> Input Class Initialized
INFO - 2022-11-29 11:33:24 --> Language Class Initialized
INFO - 2022-11-29 11:33:24 --> Loader Class Initialized
INFO - 2022-11-29 11:33:24 --> Helper loaded: url_helper
INFO - 2022-11-29 11:33:24 --> Database Driver Class Initialized
INFO - 2022-11-29 11:33:24 --> Helper loaded: form_helper
INFO - 2022-11-29 11:33:24 --> Form Validation Class Initialized
INFO - 2022-11-29 11:33:24 --> Controller Class Initialized
INFO - 2022-11-29 11:33:24 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:33:24 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:33:24 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:33:24 --> Final output sent to browser
DEBUG - 2022-11-29 11:33:24 --> Total execution time: 0.0384
INFO - 2022-11-29 11:33:36 --> Config Class Initialized
INFO - 2022-11-29 11:33:36 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:33:36 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:33:36 --> Utf8 Class Initialized
INFO - 2022-11-29 11:33:36 --> URI Class Initialized
INFO - 2022-11-29 11:33:36 --> Router Class Initialized
INFO - 2022-11-29 11:33:36 --> Output Class Initialized
INFO - 2022-11-29 11:33:36 --> Security Class Initialized
DEBUG - 2022-11-29 11:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:33:36 --> Input Class Initialized
INFO - 2022-11-29 11:33:36 --> Language Class Initialized
INFO - 2022-11-29 11:33:36 --> Loader Class Initialized
INFO - 2022-11-29 11:33:36 --> Helper loaded: url_helper
INFO - 2022-11-29 11:33:37 --> Database Driver Class Initialized
INFO - 2022-11-29 11:33:37 --> Helper loaded: form_helper
INFO - 2022-11-29 11:33:37 --> Form Validation Class Initialized
INFO - 2022-11-29 11:33:37 --> Controller Class Initialized
INFO - 2022-11-29 11:33:37 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:33:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:33:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:33:37 --> Final output sent to browser
DEBUG - 2022-11-29 11:33:37 --> Total execution time: 0.0594
INFO - 2022-11-29 11:33:37 --> Config Class Initialized
INFO - 2022-11-29 11:33:37 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:33:37 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:33:37 --> Utf8 Class Initialized
INFO - 2022-11-29 11:33:37 --> URI Class Initialized
INFO - 2022-11-29 11:33:37 --> Router Class Initialized
INFO - 2022-11-29 11:33:37 --> Output Class Initialized
INFO - 2022-11-29 11:33:37 --> Security Class Initialized
DEBUG - 2022-11-29 11:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:33:37 --> Input Class Initialized
INFO - 2022-11-29 11:33:37 --> Language Class Initialized
INFO - 2022-11-29 11:33:37 --> Loader Class Initialized
INFO - 2022-11-29 11:33:37 --> Helper loaded: url_helper
INFO - 2022-11-29 11:33:37 --> Database Driver Class Initialized
INFO - 2022-11-29 11:33:37 --> Helper loaded: form_helper
INFO - 2022-11-29 11:33:37 --> Form Validation Class Initialized
INFO - 2022-11-29 11:33:37 --> Controller Class Initialized
INFO - 2022-11-29 11:33:37 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:33:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:33:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:33:37 --> Final output sent to browser
DEBUG - 2022-11-29 11:33:37 --> Total execution time: 0.0518
INFO - 2022-11-29 11:33:38 --> Config Class Initialized
INFO - 2022-11-29 11:33:38 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:33:38 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:33:38 --> Utf8 Class Initialized
INFO - 2022-11-29 11:33:38 --> URI Class Initialized
INFO - 2022-11-29 11:33:38 --> Router Class Initialized
INFO - 2022-11-29 11:33:38 --> Output Class Initialized
INFO - 2022-11-29 11:33:38 --> Security Class Initialized
DEBUG - 2022-11-29 11:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:33:38 --> Input Class Initialized
INFO - 2022-11-29 11:33:38 --> Language Class Initialized
INFO - 2022-11-29 11:33:38 --> Loader Class Initialized
INFO - 2022-11-29 11:33:38 --> Helper loaded: url_helper
INFO - 2022-11-29 11:33:38 --> Database Driver Class Initialized
INFO - 2022-11-29 11:33:38 --> Helper loaded: form_helper
INFO - 2022-11-29 11:33:38 --> Form Validation Class Initialized
INFO - 2022-11-29 11:33:38 --> Controller Class Initialized
INFO - 2022-11-29 11:33:38 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:33:38 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:33:38 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:33:38 --> Final output sent to browser
DEBUG - 2022-11-29 11:33:38 --> Total execution time: 0.0546
INFO - 2022-11-29 11:34:37 --> Config Class Initialized
INFO - 2022-11-29 11:34:37 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:34:37 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:34:37 --> Utf8 Class Initialized
INFO - 2022-11-29 11:34:37 --> URI Class Initialized
INFO - 2022-11-29 11:34:37 --> Router Class Initialized
INFO - 2022-11-29 11:34:37 --> Output Class Initialized
INFO - 2022-11-29 11:34:37 --> Security Class Initialized
DEBUG - 2022-11-29 11:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:34:37 --> Input Class Initialized
INFO - 2022-11-29 11:34:37 --> Language Class Initialized
INFO - 2022-11-29 11:34:37 --> Loader Class Initialized
INFO - 2022-11-29 11:34:37 --> Helper loaded: url_helper
INFO - 2022-11-29 11:34:37 --> Database Driver Class Initialized
INFO - 2022-11-29 11:34:37 --> Helper loaded: form_helper
INFO - 2022-11-29 11:34:37 --> Form Validation Class Initialized
INFO - 2022-11-29 11:34:37 --> Controller Class Initialized
INFO - 2022-11-29 11:34:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:34:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:34:37 --> Final output sent to browser
DEBUG - 2022-11-29 11:34:37 --> Total execution time: 0.0476
INFO - 2022-11-29 11:34:39 --> Config Class Initialized
INFO - 2022-11-29 11:34:39 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:34:39 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:34:39 --> Utf8 Class Initialized
INFO - 2022-11-29 11:34:39 --> URI Class Initialized
INFO - 2022-11-29 11:34:39 --> Router Class Initialized
INFO - 2022-11-29 11:34:39 --> Output Class Initialized
INFO - 2022-11-29 11:34:39 --> Security Class Initialized
DEBUG - 2022-11-29 11:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:34:39 --> Input Class Initialized
INFO - 2022-11-29 11:34:39 --> Language Class Initialized
INFO - 2022-11-29 11:34:39 --> Loader Class Initialized
INFO - 2022-11-29 11:34:39 --> Helper loaded: url_helper
INFO - 2022-11-29 11:34:39 --> Database Driver Class Initialized
INFO - 2022-11-29 11:34:39 --> Helper loaded: form_helper
INFO - 2022-11-29 11:34:39 --> Form Validation Class Initialized
INFO - 2022-11-29 11:34:39 --> Controller Class Initialized
INFO - 2022-11-29 11:34:39 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:34:39 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:34:39 --> Final output sent to browser
DEBUG - 2022-11-29 11:34:39 --> Total execution time: 0.0482
INFO - 2022-11-29 11:36:47 --> Config Class Initialized
INFO - 2022-11-29 11:36:47 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:36:47 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:36:47 --> Utf8 Class Initialized
INFO - 2022-11-29 11:36:47 --> URI Class Initialized
INFO - 2022-11-29 11:36:47 --> Router Class Initialized
INFO - 2022-11-29 11:36:47 --> Output Class Initialized
INFO - 2022-11-29 11:36:48 --> Security Class Initialized
DEBUG - 2022-11-29 11:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:36:48 --> Input Class Initialized
INFO - 2022-11-29 11:36:48 --> Language Class Initialized
INFO - 2022-11-29 11:36:48 --> Loader Class Initialized
INFO - 2022-11-29 11:36:48 --> Helper loaded: url_helper
INFO - 2022-11-29 11:36:48 --> Database Driver Class Initialized
INFO - 2022-11-29 11:36:48 --> Helper loaded: form_helper
INFO - 2022-11-29 11:36:48 --> Form Validation Class Initialized
INFO - 2022-11-29 11:36:48 --> Controller Class Initialized
INFO - 2022-11-29 11:36:48 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:36:48 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:36:48 --> Final output sent to browser
DEBUG - 2022-11-29 11:36:48 --> Total execution time: 0.0585
INFO - 2022-11-29 11:37:09 --> Config Class Initialized
INFO - 2022-11-29 11:37:09 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:37:09 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:37:09 --> Utf8 Class Initialized
INFO - 2022-11-29 11:37:09 --> URI Class Initialized
INFO - 2022-11-29 11:37:09 --> Router Class Initialized
INFO - 2022-11-29 11:37:09 --> Output Class Initialized
INFO - 2022-11-29 11:37:09 --> Security Class Initialized
DEBUG - 2022-11-29 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:37:09 --> Input Class Initialized
INFO - 2022-11-29 11:37:09 --> Language Class Initialized
INFO - 2022-11-29 11:37:09 --> Loader Class Initialized
INFO - 2022-11-29 11:37:09 --> Helper loaded: url_helper
INFO - 2022-11-29 11:37:09 --> Database Driver Class Initialized
INFO - 2022-11-29 11:37:09 --> Helper loaded: form_helper
INFO - 2022-11-29 11:37:09 --> Form Validation Class Initialized
INFO - 2022-11-29 11:37:09 --> Controller Class Initialized
INFO - 2022-11-29 11:37:09 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:37:09 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:37:09 --> Final output sent to browser
DEBUG - 2022-11-29 11:37:09 --> Total execution time: 0.0372
INFO - 2022-11-29 11:37:30 --> Config Class Initialized
INFO - 2022-11-29 11:37:30 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:37:30 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:37:30 --> Utf8 Class Initialized
INFO - 2022-11-29 11:37:30 --> URI Class Initialized
INFO - 2022-11-29 11:37:30 --> Router Class Initialized
INFO - 2022-11-29 11:37:30 --> Output Class Initialized
INFO - 2022-11-29 11:37:30 --> Security Class Initialized
DEBUG - 2022-11-29 11:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:37:30 --> Input Class Initialized
INFO - 2022-11-29 11:37:30 --> Language Class Initialized
INFO - 2022-11-29 11:37:30 --> Loader Class Initialized
INFO - 2022-11-29 11:37:30 --> Helper loaded: url_helper
INFO - 2022-11-29 11:37:30 --> Database Driver Class Initialized
INFO - 2022-11-29 11:37:30 --> Helper loaded: form_helper
INFO - 2022-11-29 11:37:30 --> Form Validation Class Initialized
INFO - 2022-11-29 11:37:30 --> Controller Class Initialized
INFO - 2022-11-29 11:37:30 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:37:30 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:37:30 --> Final output sent to browser
DEBUG - 2022-11-29 11:37:30 --> Total execution time: 0.0340
INFO - 2022-11-29 11:37:31 --> Config Class Initialized
INFO - 2022-11-29 11:37:31 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:37:31 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:37:31 --> Utf8 Class Initialized
INFO - 2022-11-29 11:37:31 --> URI Class Initialized
INFO - 2022-11-29 11:37:31 --> Router Class Initialized
INFO - 2022-11-29 11:37:31 --> Output Class Initialized
INFO - 2022-11-29 11:37:31 --> Security Class Initialized
DEBUG - 2022-11-29 11:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:37:31 --> Input Class Initialized
INFO - 2022-11-29 11:37:31 --> Language Class Initialized
INFO - 2022-11-29 11:37:31 --> Loader Class Initialized
INFO - 2022-11-29 11:37:31 --> Helper loaded: url_helper
INFO - 2022-11-29 11:37:31 --> Database Driver Class Initialized
INFO - 2022-11-29 11:37:31 --> Helper loaded: form_helper
INFO - 2022-11-29 11:37:31 --> Form Validation Class Initialized
INFO - 2022-11-29 11:37:31 --> Controller Class Initialized
INFO - 2022-11-29 11:37:31 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:37:31 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:37:31 --> Final output sent to browser
DEBUG - 2022-11-29 11:37:31 --> Total execution time: 0.0503
INFO - 2022-11-29 11:37:45 --> Config Class Initialized
INFO - 2022-11-29 11:37:45 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:37:45 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:37:45 --> Utf8 Class Initialized
INFO - 2022-11-29 11:37:45 --> URI Class Initialized
INFO - 2022-11-29 11:37:45 --> Router Class Initialized
INFO - 2022-11-29 11:37:45 --> Output Class Initialized
INFO - 2022-11-29 11:37:45 --> Security Class Initialized
DEBUG - 2022-11-29 11:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:37:45 --> Input Class Initialized
INFO - 2022-11-29 11:37:45 --> Language Class Initialized
INFO - 2022-11-29 11:37:45 --> Loader Class Initialized
INFO - 2022-11-29 11:37:45 --> Helper loaded: url_helper
INFO - 2022-11-29 11:37:45 --> Database Driver Class Initialized
INFO - 2022-11-29 11:37:45 --> Helper loaded: form_helper
INFO - 2022-11-29 11:37:45 --> Form Validation Class Initialized
INFO - 2022-11-29 11:37:45 --> Controller Class Initialized
INFO - 2022-11-29 11:37:45 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:37:45 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:37:45 --> Final output sent to browser
DEBUG - 2022-11-29 11:37:45 --> Total execution time: 0.0593
INFO - 2022-11-29 11:37:45 --> Config Class Initialized
INFO - 2022-11-29 11:37:45 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:37:45 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:37:45 --> Utf8 Class Initialized
INFO - 2022-11-29 11:37:45 --> URI Class Initialized
INFO - 2022-11-29 11:37:45 --> Router Class Initialized
INFO - 2022-11-29 11:37:45 --> Output Class Initialized
INFO - 2022-11-29 11:37:45 --> Security Class Initialized
DEBUG - 2022-11-29 11:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:37:45 --> Input Class Initialized
INFO - 2022-11-29 11:37:45 --> Language Class Initialized
INFO - 2022-11-29 11:37:45 --> Loader Class Initialized
INFO - 2022-11-29 11:37:45 --> Helper loaded: url_helper
INFO - 2022-11-29 11:37:45 --> Database Driver Class Initialized
INFO - 2022-11-29 11:37:45 --> Helper loaded: form_helper
INFO - 2022-11-29 11:37:45 --> Form Validation Class Initialized
INFO - 2022-11-29 11:37:45 --> Controller Class Initialized
INFO - 2022-11-29 11:37:45 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:37:45 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:37:45 --> Final output sent to browser
DEBUG - 2022-11-29 11:37:45 --> Total execution time: 0.0473
INFO - 2022-11-29 11:37:46 --> Config Class Initialized
INFO - 2022-11-29 11:37:46 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:37:46 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:37:46 --> Utf8 Class Initialized
INFO - 2022-11-29 11:37:46 --> URI Class Initialized
INFO - 2022-11-29 11:37:46 --> Router Class Initialized
INFO - 2022-11-29 11:37:46 --> Output Class Initialized
INFO - 2022-11-29 11:37:46 --> Security Class Initialized
DEBUG - 2022-11-29 11:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:37:46 --> Input Class Initialized
INFO - 2022-11-29 11:37:46 --> Language Class Initialized
INFO - 2022-11-29 11:37:46 --> Loader Class Initialized
INFO - 2022-11-29 11:37:46 --> Helper loaded: url_helper
INFO - 2022-11-29 11:37:46 --> Database Driver Class Initialized
INFO - 2022-11-29 11:37:46 --> Helper loaded: form_helper
INFO - 2022-11-29 11:37:46 --> Form Validation Class Initialized
INFO - 2022-11-29 11:37:46 --> Controller Class Initialized
INFO - 2022-11-29 11:37:46 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:37:46 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:37:46 --> Final output sent to browser
DEBUG - 2022-11-29 11:37:46 --> Total execution time: 0.0547
INFO - 2022-11-29 11:37:57 --> Config Class Initialized
INFO - 2022-11-29 11:37:57 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:37:57 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:37:57 --> Utf8 Class Initialized
INFO - 2022-11-29 11:37:57 --> URI Class Initialized
INFO - 2022-11-29 11:37:57 --> Router Class Initialized
INFO - 2022-11-29 11:37:57 --> Output Class Initialized
INFO - 2022-11-29 11:37:57 --> Security Class Initialized
DEBUG - 2022-11-29 11:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:37:57 --> Input Class Initialized
INFO - 2022-11-29 11:37:57 --> Language Class Initialized
INFO - 2022-11-29 11:37:57 --> Loader Class Initialized
INFO - 2022-11-29 11:37:57 --> Helper loaded: url_helper
INFO - 2022-11-29 11:37:57 --> Database Driver Class Initialized
INFO - 2022-11-29 11:37:57 --> Helper loaded: form_helper
INFO - 2022-11-29 11:37:57 --> Form Validation Class Initialized
INFO - 2022-11-29 11:37:57 --> Controller Class Initialized
INFO - 2022-11-29 11:37:57 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:37:57 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:37:57 --> Final output sent to browser
DEBUG - 2022-11-29 11:37:57 --> Total execution time: 0.0577
INFO - 2022-11-29 11:37:57 --> Config Class Initialized
INFO - 2022-11-29 11:37:57 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:37:57 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:37:57 --> Utf8 Class Initialized
INFO - 2022-11-29 11:37:57 --> URI Class Initialized
INFO - 2022-11-29 11:37:57 --> Router Class Initialized
INFO - 2022-11-29 11:37:57 --> Output Class Initialized
INFO - 2022-11-29 11:37:57 --> Security Class Initialized
DEBUG - 2022-11-29 11:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:37:57 --> Input Class Initialized
INFO - 2022-11-29 11:37:57 --> Language Class Initialized
INFO - 2022-11-29 11:37:57 --> Loader Class Initialized
INFO - 2022-11-29 11:37:57 --> Helper loaded: url_helper
INFO - 2022-11-29 11:37:57 --> Database Driver Class Initialized
INFO - 2022-11-29 11:37:57 --> Helper loaded: form_helper
INFO - 2022-11-29 11:37:57 --> Form Validation Class Initialized
INFO - 2022-11-29 11:37:57 --> Controller Class Initialized
INFO - 2022-11-29 11:37:57 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:37:57 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:37:57 --> Final output sent to browser
DEBUG - 2022-11-29 11:37:57 --> Total execution time: 0.0357
INFO - 2022-11-29 11:38:31 --> Config Class Initialized
INFO - 2022-11-29 11:38:31 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:38:31 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:38:31 --> Utf8 Class Initialized
INFO - 2022-11-29 11:38:31 --> URI Class Initialized
INFO - 2022-11-29 11:38:31 --> Router Class Initialized
INFO - 2022-11-29 11:38:32 --> Output Class Initialized
INFO - 2022-11-29 11:38:32 --> Security Class Initialized
DEBUG - 2022-11-29 11:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:38:32 --> Input Class Initialized
INFO - 2022-11-29 11:38:32 --> Language Class Initialized
INFO - 2022-11-29 11:38:32 --> Loader Class Initialized
INFO - 2022-11-29 11:38:32 --> Helper loaded: url_helper
INFO - 2022-11-29 11:38:32 --> Database Driver Class Initialized
INFO - 2022-11-29 11:38:32 --> Helper loaded: form_helper
INFO - 2022-11-29 11:38:32 --> Form Validation Class Initialized
INFO - 2022-11-29 11:38:32 --> Controller Class Initialized
INFO - 2022-11-29 11:38:32 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:38:32 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:38:32 --> Final output sent to browser
DEBUG - 2022-11-29 11:38:32 --> Total execution time: 0.0443
INFO - 2022-11-29 11:38:32 --> Config Class Initialized
INFO - 2022-11-29 11:38:32 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:38:32 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:38:32 --> Utf8 Class Initialized
INFO - 2022-11-29 11:38:32 --> URI Class Initialized
INFO - 2022-11-29 11:38:32 --> Router Class Initialized
INFO - 2022-11-29 11:38:32 --> Output Class Initialized
INFO - 2022-11-29 11:38:32 --> Security Class Initialized
DEBUG - 2022-11-29 11:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:38:32 --> Input Class Initialized
INFO - 2022-11-29 11:38:32 --> Language Class Initialized
INFO - 2022-11-29 11:38:32 --> Loader Class Initialized
INFO - 2022-11-29 11:38:32 --> Helper loaded: url_helper
INFO - 2022-11-29 11:38:32 --> Database Driver Class Initialized
INFO - 2022-11-29 11:38:32 --> Helper loaded: form_helper
INFO - 2022-11-29 11:38:32 --> Form Validation Class Initialized
INFO - 2022-11-29 11:38:32 --> Controller Class Initialized
INFO - 2022-11-29 11:38:32 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:38:32 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:38:32 --> Final output sent to browser
DEBUG - 2022-11-29 11:38:32 --> Total execution time: 0.0477
INFO - 2022-11-29 11:39:39 --> Config Class Initialized
INFO - 2022-11-29 11:39:39 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:39:39 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:39:39 --> Utf8 Class Initialized
INFO - 2022-11-29 11:39:39 --> URI Class Initialized
INFO - 2022-11-29 11:39:39 --> Router Class Initialized
INFO - 2022-11-29 11:39:39 --> Output Class Initialized
INFO - 2022-11-29 11:39:39 --> Security Class Initialized
DEBUG - 2022-11-29 11:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:39:39 --> Input Class Initialized
INFO - 2022-11-29 11:39:39 --> Language Class Initialized
INFO - 2022-11-29 11:39:39 --> Loader Class Initialized
INFO - 2022-11-29 11:39:39 --> Helper loaded: url_helper
INFO - 2022-11-29 11:39:39 --> Database Driver Class Initialized
INFO - 2022-11-29 11:39:39 --> Helper loaded: form_helper
INFO - 2022-11-29 11:39:39 --> Form Validation Class Initialized
INFO - 2022-11-29 11:39:39 --> Controller Class Initialized
INFO - 2022-11-29 11:39:39 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:39:39 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:39:39 --> Final output sent to browser
DEBUG - 2022-11-29 11:39:39 --> Total execution time: 0.0464
INFO - 2022-11-29 11:40:10 --> Config Class Initialized
INFO - 2022-11-29 11:40:10 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:40:10 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:40:10 --> Utf8 Class Initialized
INFO - 2022-11-29 11:40:10 --> URI Class Initialized
INFO - 2022-11-29 11:40:10 --> Router Class Initialized
INFO - 2022-11-29 11:40:10 --> Output Class Initialized
INFO - 2022-11-29 11:40:10 --> Security Class Initialized
DEBUG - 2022-11-29 11:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:40:10 --> Input Class Initialized
INFO - 2022-11-29 11:40:10 --> Language Class Initialized
INFO - 2022-11-29 11:40:10 --> Loader Class Initialized
INFO - 2022-11-29 11:40:10 --> Helper loaded: url_helper
INFO - 2022-11-29 11:40:10 --> Database Driver Class Initialized
INFO - 2022-11-29 11:40:10 --> Helper loaded: form_helper
INFO - 2022-11-29 11:40:10 --> Form Validation Class Initialized
INFO - 2022-11-29 11:40:10 --> Controller Class Initialized
INFO - 2022-11-29 11:40:10 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:40:10 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:40:10 --> Final output sent to browser
DEBUG - 2022-11-29 11:40:10 --> Total execution time: 0.0508
INFO - 2022-11-29 11:40:32 --> Config Class Initialized
INFO - 2022-11-29 11:40:32 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:40:32 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:40:32 --> Utf8 Class Initialized
INFO - 2022-11-29 11:40:32 --> URI Class Initialized
INFO - 2022-11-29 11:40:32 --> Router Class Initialized
INFO - 2022-11-29 11:40:32 --> Output Class Initialized
INFO - 2022-11-29 11:40:32 --> Security Class Initialized
DEBUG - 2022-11-29 11:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:40:32 --> Input Class Initialized
INFO - 2022-11-29 11:40:32 --> Language Class Initialized
INFO - 2022-11-29 11:40:32 --> Loader Class Initialized
INFO - 2022-11-29 11:40:32 --> Helper loaded: url_helper
INFO - 2022-11-29 11:40:32 --> Database Driver Class Initialized
INFO - 2022-11-29 11:40:32 --> Helper loaded: form_helper
INFO - 2022-11-29 11:40:32 --> Form Validation Class Initialized
INFO - 2022-11-29 11:40:32 --> Controller Class Initialized
INFO - 2022-11-29 11:40:32 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:40:32 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:40:32 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:40:32 --> Final output sent to browser
DEBUG - 2022-11-29 11:40:32 --> Total execution time: 0.0412
INFO - 2022-11-29 11:48:03 --> Config Class Initialized
INFO - 2022-11-29 11:48:03 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:48:03 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:48:03 --> Utf8 Class Initialized
INFO - 2022-11-29 11:48:03 --> URI Class Initialized
INFO - 2022-11-29 11:48:03 --> Router Class Initialized
INFO - 2022-11-29 11:48:03 --> Output Class Initialized
INFO - 2022-11-29 11:48:03 --> Security Class Initialized
DEBUG - 2022-11-29 11:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:48:03 --> Input Class Initialized
INFO - 2022-11-29 11:48:03 --> Language Class Initialized
INFO - 2022-11-29 11:48:03 --> Loader Class Initialized
INFO - 2022-11-29 11:48:03 --> Helper loaded: url_helper
INFO - 2022-11-29 11:48:03 --> Database Driver Class Initialized
INFO - 2022-11-29 11:48:03 --> Helper loaded: form_helper
INFO - 2022-11-29 11:48:03 --> Form Validation Class Initialized
INFO - 2022-11-29 11:48:03 --> Controller Class Initialized
INFO - 2022-11-29 11:48:03 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:48:03 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:48:03 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:48:03 --> Final output sent to browser
DEBUG - 2022-11-29 11:48:03 --> Total execution time: 0.0590
INFO - 2022-11-29 11:48:24 --> Config Class Initialized
INFO - 2022-11-29 11:48:24 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:48:24 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:48:24 --> Utf8 Class Initialized
INFO - 2022-11-29 11:48:24 --> URI Class Initialized
INFO - 2022-11-29 11:48:24 --> Router Class Initialized
INFO - 2022-11-29 11:48:24 --> Output Class Initialized
INFO - 2022-11-29 11:48:24 --> Security Class Initialized
DEBUG - 2022-11-29 11:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:48:24 --> Input Class Initialized
INFO - 2022-11-29 11:48:24 --> Language Class Initialized
INFO - 2022-11-29 11:48:24 --> Loader Class Initialized
INFO - 2022-11-29 11:48:24 --> Helper loaded: url_helper
INFO - 2022-11-29 11:48:24 --> Database Driver Class Initialized
INFO - 2022-11-29 11:48:24 --> Helper loaded: form_helper
INFO - 2022-11-29 11:48:24 --> Form Validation Class Initialized
INFO - 2022-11-29 11:48:24 --> Controller Class Initialized
INFO - 2022-11-29 11:48:24 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:48:24 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:48:24 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:48:24 --> Final output sent to browser
DEBUG - 2022-11-29 11:48:24 --> Total execution time: 0.0517
INFO - 2022-11-29 11:48:28 --> Config Class Initialized
INFO - 2022-11-29 11:48:28 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:48:28 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:48:28 --> Utf8 Class Initialized
INFO - 2022-11-29 11:48:28 --> URI Class Initialized
INFO - 2022-11-29 11:48:28 --> Router Class Initialized
INFO - 2022-11-29 11:48:28 --> Output Class Initialized
INFO - 2022-11-29 11:48:28 --> Security Class Initialized
DEBUG - 2022-11-29 11:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:48:28 --> Input Class Initialized
INFO - 2022-11-29 11:48:28 --> Language Class Initialized
INFO - 2022-11-29 11:48:28 --> Loader Class Initialized
INFO - 2022-11-29 11:48:28 --> Helper loaded: url_helper
INFO - 2022-11-29 11:48:28 --> Database Driver Class Initialized
INFO - 2022-11-29 11:48:29 --> Helper loaded: form_helper
INFO - 2022-11-29 11:48:29 --> Form Validation Class Initialized
INFO - 2022-11-29 11:48:29 --> Controller Class Initialized
INFO - 2022-11-29 11:48:29 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:48:29 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:48:29 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:48:29 --> Final output sent to browser
DEBUG - 2022-11-29 11:48:29 --> Total execution time: 0.0518
INFO - 2022-11-29 11:49:29 --> Config Class Initialized
INFO - 2022-11-29 11:49:29 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:49:29 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:49:29 --> Utf8 Class Initialized
INFO - 2022-11-29 11:49:29 --> URI Class Initialized
INFO - 2022-11-29 11:49:29 --> Router Class Initialized
INFO - 2022-11-29 11:49:29 --> Output Class Initialized
INFO - 2022-11-29 11:49:29 --> Security Class Initialized
DEBUG - 2022-11-29 11:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:49:29 --> Input Class Initialized
INFO - 2022-11-29 11:49:29 --> Language Class Initialized
INFO - 2022-11-29 11:49:29 --> Loader Class Initialized
INFO - 2022-11-29 11:49:29 --> Helper loaded: url_helper
INFO - 2022-11-29 11:49:29 --> Database Driver Class Initialized
INFO - 2022-11-29 11:49:29 --> Helper loaded: form_helper
INFO - 2022-11-29 11:49:29 --> Form Validation Class Initialized
INFO - 2022-11-29 11:49:29 --> Controller Class Initialized
INFO - 2022-11-29 11:49:29 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:49:29 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:49:29 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:49:29 --> Final output sent to browser
DEBUG - 2022-11-29 11:49:29 --> Total execution time: 0.0589
INFO - 2022-11-29 11:50:09 --> Config Class Initialized
INFO - 2022-11-29 11:50:09 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:50:09 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:50:09 --> Utf8 Class Initialized
INFO - 2022-11-29 11:50:09 --> URI Class Initialized
INFO - 2022-11-29 11:50:09 --> Router Class Initialized
INFO - 2022-11-29 11:50:09 --> Output Class Initialized
INFO - 2022-11-29 11:50:09 --> Security Class Initialized
DEBUG - 2022-11-29 11:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:50:09 --> Input Class Initialized
INFO - 2022-11-29 11:50:09 --> Language Class Initialized
INFO - 2022-11-29 11:50:09 --> Loader Class Initialized
INFO - 2022-11-29 11:50:09 --> Helper loaded: url_helper
INFO - 2022-11-29 11:50:09 --> Database Driver Class Initialized
INFO - 2022-11-29 11:50:09 --> Helper loaded: form_helper
INFO - 2022-11-29 11:50:09 --> Form Validation Class Initialized
INFO - 2022-11-29 11:50:09 --> Controller Class Initialized
INFO - 2022-11-29 11:50:09 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:50:09 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:50:09 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:50:09 --> Final output sent to browser
DEBUG - 2022-11-29 11:50:09 --> Total execution time: 0.0551
INFO - 2022-11-29 11:50:12 --> Config Class Initialized
INFO - 2022-11-29 11:50:12 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:50:12 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:50:12 --> Utf8 Class Initialized
INFO - 2022-11-29 11:50:12 --> URI Class Initialized
INFO - 2022-11-29 11:50:12 --> Router Class Initialized
INFO - 2022-11-29 11:50:12 --> Output Class Initialized
INFO - 2022-11-29 11:50:12 --> Security Class Initialized
DEBUG - 2022-11-29 11:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:50:12 --> Input Class Initialized
INFO - 2022-11-29 11:50:12 --> Language Class Initialized
INFO - 2022-11-29 11:50:12 --> Loader Class Initialized
INFO - 2022-11-29 11:50:12 --> Helper loaded: url_helper
INFO - 2022-11-29 11:50:12 --> Database Driver Class Initialized
INFO - 2022-11-29 11:50:12 --> Helper loaded: form_helper
INFO - 2022-11-29 11:50:12 --> Form Validation Class Initialized
INFO - 2022-11-29 11:50:12 --> Controller Class Initialized
INFO - 2022-11-29 11:50:12 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:50:12 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:50:12 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:50:12 --> Final output sent to browser
DEBUG - 2022-11-29 11:50:12 --> Total execution time: 0.0441
INFO - 2022-11-29 11:50:14 --> Config Class Initialized
INFO - 2022-11-29 11:50:14 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:50:14 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:50:14 --> Utf8 Class Initialized
INFO - 2022-11-29 11:50:14 --> URI Class Initialized
INFO - 2022-11-29 11:50:14 --> Router Class Initialized
INFO - 2022-11-29 11:50:14 --> Output Class Initialized
INFO - 2022-11-29 11:50:14 --> Security Class Initialized
DEBUG - 2022-11-29 11:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:50:14 --> Input Class Initialized
INFO - 2022-11-29 11:50:14 --> Language Class Initialized
INFO - 2022-11-29 11:50:14 --> Loader Class Initialized
INFO - 2022-11-29 11:50:14 --> Helper loaded: url_helper
INFO - 2022-11-29 11:50:14 --> Database Driver Class Initialized
INFO - 2022-11-29 11:50:14 --> Helper loaded: form_helper
INFO - 2022-11-29 11:50:14 --> Form Validation Class Initialized
INFO - 2022-11-29 11:50:14 --> Controller Class Initialized
INFO - 2022-11-29 11:50:14 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:50:14 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:50:14 --> Final output sent to browser
DEBUG - 2022-11-29 11:50:14 --> Total execution time: 0.0560
INFO - 2022-11-29 11:50:28 --> Config Class Initialized
INFO - 2022-11-29 11:50:28 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:50:28 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:50:28 --> Utf8 Class Initialized
INFO - 2022-11-29 11:50:28 --> URI Class Initialized
INFO - 2022-11-29 11:50:28 --> Router Class Initialized
INFO - 2022-11-29 11:50:28 --> Output Class Initialized
INFO - 2022-11-29 11:50:28 --> Security Class Initialized
DEBUG - 2022-11-29 11:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:50:28 --> Input Class Initialized
INFO - 2022-11-29 11:50:28 --> Language Class Initialized
INFO - 2022-11-29 11:50:28 --> Loader Class Initialized
INFO - 2022-11-29 11:50:28 --> Helper loaded: url_helper
INFO - 2022-11-29 11:50:28 --> Database Driver Class Initialized
INFO - 2022-11-29 11:50:28 --> Helper loaded: form_helper
INFO - 2022-11-29 11:50:28 --> Form Validation Class Initialized
INFO - 2022-11-29 11:50:28 --> Controller Class Initialized
INFO - 2022-11-29 11:50:28 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:50:28 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:50:28 --> Final output sent to browser
DEBUG - 2022-11-29 11:50:28 --> Total execution time: 0.0405
INFO - 2022-11-29 11:50:35 --> Config Class Initialized
INFO - 2022-11-29 11:50:35 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:50:35 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:50:35 --> Utf8 Class Initialized
INFO - 2022-11-29 11:50:35 --> URI Class Initialized
INFO - 2022-11-29 11:50:35 --> Router Class Initialized
INFO - 2022-11-29 11:50:35 --> Output Class Initialized
INFO - 2022-11-29 11:50:35 --> Security Class Initialized
DEBUG - 2022-11-29 11:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:50:35 --> Input Class Initialized
INFO - 2022-11-29 11:50:35 --> Language Class Initialized
INFO - 2022-11-29 11:50:35 --> Loader Class Initialized
INFO - 2022-11-29 11:50:35 --> Helper loaded: url_helper
INFO - 2022-11-29 11:50:35 --> Database Driver Class Initialized
INFO - 2022-11-29 11:50:35 --> Helper loaded: form_helper
INFO - 2022-11-29 11:50:35 --> Form Validation Class Initialized
INFO - 2022-11-29 11:50:35 --> Controller Class Initialized
INFO - 2022-11-29 11:50:35 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:50:35 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-29 11:50:35 --> Final output sent to browser
DEBUG - 2022-11-29 11:50:35 --> Total execution time: 0.0411
INFO - 2022-11-29 11:50:49 --> Config Class Initialized
INFO - 2022-11-29 11:50:49 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:50:49 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:50:49 --> Utf8 Class Initialized
INFO - 2022-11-29 11:50:49 --> URI Class Initialized
INFO - 2022-11-29 11:50:49 --> Router Class Initialized
INFO - 2022-11-29 11:50:49 --> Output Class Initialized
INFO - 2022-11-29 11:50:49 --> Security Class Initialized
DEBUG - 2022-11-29 11:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:50:49 --> Input Class Initialized
INFO - 2022-11-29 11:50:49 --> Language Class Initialized
INFO - 2022-11-29 11:50:49 --> Loader Class Initialized
INFO - 2022-11-29 11:50:49 --> Helper loaded: url_helper
INFO - 2022-11-29 11:50:49 --> Database Driver Class Initialized
INFO - 2022-11-29 11:50:49 --> Helper loaded: form_helper
INFO - 2022-11-29 11:50:49 --> Form Validation Class Initialized
INFO - 2022-11-29 11:50:49 --> Controller Class Initialized
INFO - 2022-11-29 11:50:49 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:50:49 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-29 11:50:49 --> Final output sent to browser
DEBUG - 2022-11-29 11:50:49 --> Total execution time: 0.0354
INFO - 2022-11-29 11:50:54 --> Config Class Initialized
INFO - 2022-11-29 11:50:54 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:50:54 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:50:54 --> Utf8 Class Initialized
INFO - 2022-11-29 11:50:54 --> URI Class Initialized
INFO - 2022-11-29 11:50:54 --> Router Class Initialized
INFO - 2022-11-29 11:50:54 --> Output Class Initialized
INFO - 2022-11-29 11:50:54 --> Security Class Initialized
DEBUG - 2022-11-29 11:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:50:54 --> Input Class Initialized
INFO - 2022-11-29 11:50:54 --> Language Class Initialized
INFO - 2022-11-29 11:50:54 --> Loader Class Initialized
INFO - 2022-11-29 11:50:54 --> Helper loaded: url_helper
INFO - 2022-11-29 11:50:54 --> Database Driver Class Initialized
INFO - 2022-11-29 11:50:54 --> Helper loaded: form_helper
INFO - 2022-11-29 11:50:54 --> Form Validation Class Initialized
INFO - 2022-11-29 11:50:54 --> Controller Class Initialized
INFO - 2022-11-29 11:50:54 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:50:54 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-29 11:50:54 --> Final output sent to browser
DEBUG - 2022-11-29 11:50:54 --> Total execution time: 0.0367
INFO - 2022-11-29 11:50:56 --> Config Class Initialized
INFO - 2022-11-29 11:50:56 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:50:56 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:50:56 --> Utf8 Class Initialized
INFO - 2022-11-29 11:50:56 --> URI Class Initialized
INFO - 2022-11-29 11:50:56 --> Router Class Initialized
INFO - 2022-11-29 11:50:56 --> Output Class Initialized
INFO - 2022-11-29 11:50:56 --> Security Class Initialized
DEBUG - 2022-11-29 11:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:50:56 --> Input Class Initialized
INFO - 2022-11-29 11:50:56 --> Language Class Initialized
INFO - 2022-11-29 11:50:56 --> Loader Class Initialized
INFO - 2022-11-29 11:50:56 --> Helper loaded: url_helper
INFO - 2022-11-29 11:50:56 --> Database Driver Class Initialized
INFO - 2022-11-29 11:50:56 --> Helper loaded: form_helper
INFO - 2022-11-29 11:50:56 --> Form Validation Class Initialized
INFO - 2022-11-29 11:50:56 --> Controller Class Initialized
INFO - 2022-11-29 11:50:56 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:50:56 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/detail.php
INFO - 2022-11-29 11:50:56 --> Final output sent to browser
DEBUG - 2022-11-29 11:50:56 --> Total execution time: 0.0350
INFO - 2022-11-29 11:51:10 --> Config Class Initialized
INFO - 2022-11-29 11:51:10 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:51:10 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:51:10 --> Utf8 Class Initialized
INFO - 2022-11-29 11:51:10 --> URI Class Initialized
INFO - 2022-11-29 11:51:10 --> Router Class Initialized
INFO - 2022-11-29 11:51:10 --> Output Class Initialized
INFO - 2022-11-29 11:51:10 --> Security Class Initialized
DEBUG - 2022-11-29 11:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:51:10 --> Input Class Initialized
INFO - 2022-11-29 11:51:10 --> Language Class Initialized
INFO - 2022-11-29 11:51:10 --> Loader Class Initialized
INFO - 2022-11-29 11:51:10 --> Helper loaded: url_helper
INFO - 2022-11-29 11:51:10 --> Database Driver Class Initialized
INFO - 2022-11-29 11:51:10 --> Helper loaded: form_helper
INFO - 2022-11-29 11:51:10 --> Form Validation Class Initialized
INFO - 2022-11-29 11:51:10 --> Controller Class Initialized
INFO - 2022-11-29 11:51:10 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:51:10 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/detail.php
INFO - 2022-11-29 11:51:10 --> Final output sent to browser
DEBUG - 2022-11-29 11:51:10 --> Total execution time: 0.0448
INFO - 2022-11-29 11:51:37 --> Config Class Initialized
INFO - 2022-11-29 11:51:37 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:51:37 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:51:37 --> Utf8 Class Initialized
INFO - 2022-11-29 11:51:37 --> URI Class Initialized
INFO - 2022-11-29 11:51:37 --> Router Class Initialized
INFO - 2022-11-29 11:51:37 --> Output Class Initialized
INFO - 2022-11-29 11:51:37 --> Security Class Initialized
DEBUG - 2022-11-29 11:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:51:37 --> Input Class Initialized
INFO - 2022-11-29 11:51:37 --> Language Class Initialized
INFO - 2022-11-29 11:51:37 --> Loader Class Initialized
INFO - 2022-11-29 11:51:37 --> Helper loaded: url_helper
INFO - 2022-11-29 11:51:37 --> Database Driver Class Initialized
INFO - 2022-11-29 11:51:37 --> Helper loaded: form_helper
INFO - 2022-11-29 11:51:37 --> Form Validation Class Initialized
INFO - 2022-11-29 11:51:37 --> Controller Class Initialized
INFO - 2022-11-29 11:51:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:51:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-29 11:51:37 --> Final output sent to browser
DEBUG - 2022-11-29 11:51:37 --> Total execution time: 0.0525
INFO - 2022-11-29 11:51:39 --> Config Class Initialized
INFO - 2022-11-29 11:51:39 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:51:39 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:51:39 --> Utf8 Class Initialized
INFO - 2022-11-29 11:51:39 --> URI Class Initialized
INFO - 2022-11-29 11:51:39 --> Router Class Initialized
INFO - 2022-11-29 11:51:39 --> Output Class Initialized
INFO - 2022-11-29 11:51:39 --> Security Class Initialized
DEBUG - 2022-11-29 11:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:51:39 --> Input Class Initialized
INFO - 2022-11-29 11:51:39 --> Language Class Initialized
INFO - 2022-11-29 11:51:39 --> Loader Class Initialized
INFO - 2022-11-29 11:51:39 --> Helper loaded: url_helper
INFO - 2022-11-29 11:51:39 --> Database Driver Class Initialized
INFO - 2022-11-29 11:51:39 --> Helper loaded: form_helper
INFO - 2022-11-29 11:51:39 --> Form Validation Class Initialized
INFO - 2022-11-29 11:51:39 --> Controller Class Initialized
INFO - 2022-11-29 11:51:39 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:51:39 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:51:39 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-29 11:51:39 --> Final output sent to browser
DEBUG - 2022-11-29 11:51:39 --> Total execution time: 0.0558
INFO - 2022-11-29 11:51:40 --> Config Class Initialized
INFO - 2022-11-29 11:51:40 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:51:40 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:51:40 --> Utf8 Class Initialized
INFO - 2022-11-29 11:51:40 --> URI Class Initialized
INFO - 2022-11-29 11:51:40 --> Router Class Initialized
INFO - 2022-11-29 11:51:40 --> Output Class Initialized
INFO - 2022-11-29 11:51:40 --> Security Class Initialized
DEBUG - 2022-11-29 11:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:51:40 --> Input Class Initialized
INFO - 2022-11-29 11:51:40 --> Language Class Initialized
INFO - 2022-11-29 11:51:40 --> Loader Class Initialized
INFO - 2022-11-29 11:51:40 --> Helper loaded: url_helper
INFO - 2022-11-29 11:51:40 --> Database Driver Class Initialized
INFO - 2022-11-29 11:51:40 --> Helper loaded: form_helper
INFO - 2022-11-29 11:51:40 --> Form Validation Class Initialized
INFO - 2022-11-29 11:51:40 --> Controller Class Initialized
INFO - 2022-11-29 11:51:40 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:51:40 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:51:40 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:51:40 --> Final output sent to browser
DEBUG - 2022-11-29 11:51:40 --> Total execution time: 0.0565
INFO - 2022-11-29 11:52:02 --> Config Class Initialized
INFO - 2022-11-29 11:52:02 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:52:02 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:52:02 --> Utf8 Class Initialized
INFO - 2022-11-29 11:52:02 --> URI Class Initialized
INFO - 2022-11-29 11:52:02 --> Router Class Initialized
INFO - 2022-11-29 11:52:02 --> Output Class Initialized
INFO - 2022-11-29 11:52:02 --> Security Class Initialized
DEBUG - 2022-11-29 11:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:52:02 --> Input Class Initialized
INFO - 2022-11-29 11:52:02 --> Language Class Initialized
INFO - 2022-11-29 11:52:02 --> Loader Class Initialized
INFO - 2022-11-29 11:52:02 --> Helper loaded: url_helper
INFO - 2022-11-29 11:52:02 --> Database Driver Class Initialized
INFO - 2022-11-29 11:52:02 --> Helper loaded: form_helper
INFO - 2022-11-29 11:52:02 --> Form Validation Class Initialized
INFO - 2022-11-29 11:52:02 --> Controller Class Initialized
INFO - 2022-11-29 11:52:02 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:52:02 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:52:02 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-29 11:52:02 --> Final output sent to browser
DEBUG - 2022-11-29 11:52:02 --> Total execution time: 0.0347
INFO - 2022-11-29 11:52:37 --> Config Class Initialized
INFO - 2022-11-29 11:52:37 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:52:37 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:52:37 --> Utf8 Class Initialized
INFO - 2022-11-29 11:52:37 --> URI Class Initialized
INFO - 2022-11-29 11:52:37 --> Router Class Initialized
INFO - 2022-11-29 11:52:37 --> Output Class Initialized
INFO - 2022-11-29 11:52:37 --> Security Class Initialized
DEBUG - 2022-11-29 11:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:52:37 --> Input Class Initialized
INFO - 2022-11-29 11:52:37 --> Language Class Initialized
INFO - 2022-11-29 11:52:37 --> Loader Class Initialized
INFO - 2022-11-29 11:52:37 --> Helper loaded: url_helper
INFO - 2022-11-29 11:52:37 --> Database Driver Class Initialized
INFO - 2022-11-29 11:52:37 --> Helper loaded: form_helper
INFO - 2022-11-29 11:52:37 --> Form Validation Class Initialized
INFO - 2022-11-29 11:52:37 --> Controller Class Initialized
INFO - 2022-11-29 11:52:37 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:52:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:52:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:52:37 --> Final output sent to browser
DEBUG - 2022-11-29 11:52:37 --> Total execution time: 0.0366
INFO - 2022-11-29 11:52:58 --> Config Class Initialized
INFO - 2022-11-29 11:52:58 --> Hooks Class Initialized
DEBUG - 2022-11-29 11:52:58 --> UTF-8 Support Enabled
INFO - 2022-11-29 11:52:58 --> Utf8 Class Initialized
INFO - 2022-11-29 11:52:58 --> URI Class Initialized
INFO - 2022-11-29 11:52:58 --> Router Class Initialized
INFO - 2022-11-29 11:52:58 --> Output Class Initialized
INFO - 2022-11-29 11:52:58 --> Security Class Initialized
DEBUG - 2022-11-29 11:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-29 11:52:58 --> Input Class Initialized
INFO - 2022-11-29 11:52:58 --> Language Class Initialized
INFO - 2022-11-29 11:52:58 --> Loader Class Initialized
INFO - 2022-11-29 11:52:58 --> Helper loaded: url_helper
INFO - 2022-11-29 11:52:58 --> Database Driver Class Initialized
INFO - 2022-11-29 11:52:58 --> Helper loaded: form_helper
INFO - 2022-11-29 11:52:58 --> Form Validation Class Initialized
INFO - 2022-11-29 11:52:58 --> Controller Class Initialized
INFO - 2022-11-29 11:52:58 --> Model "Buku_model" initialized
INFO - 2022-11-29 11:52:58 --> Model "Penerbit_model" initialized
INFO - 2022-11-29 11:52:58 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-29 11:52:58 --> Final output sent to browser
DEBUG - 2022-11-29 11:52:58 --> Total execution time: 0.0496
