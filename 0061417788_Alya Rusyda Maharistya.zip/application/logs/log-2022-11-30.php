<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-11-30 08:54:08 --> Config Class Initialized
INFO - 2022-11-30 08:54:08 --> Hooks Class Initialized
DEBUG - 2022-11-30 08:54:08 --> UTF-8 Support Enabled
INFO - 2022-11-30 08:54:08 --> Utf8 Class Initialized
INFO - 2022-11-30 08:54:08 --> URI Class Initialized
DEBUG - 2022-11-30 08:54:09 --> No URI present. Default controller set.
INFO - 2022-11-30 08:54:09 --> Router Class Initialized
INFO - 2022-11-30 08:54:09 --> Output Class Initialized
INFO - 2022-11-30 08:54:09 --> Security Class Initialized
DEBUG - 2022-11-30 08:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 08:54:09 --> Input Class Initialized
INFO - 2022-11-30 08:54:09 --> Language Class Initialized
INFO - 2022-11-30 08:54:09 --> Loader Class Initialized
INFO - 2022-11-30 08:54:09 --> Helper loaded: url_helper
INFO - 2022-11-30 08:54:09 --> Database Driver Class Initialized
INFO - 2022-11-30 08:54:09 --> Helper loaded: form_helper
INFO - 2022-11-30 08:54:09 --> Form Validation Class Initialized
INFO - 2022-11-30 08:54:09 --> Controller Class Initialized
INFO - 2022-11-30 08:54:09 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 08:54:09 --> Final output sent to browser
DEBUG - 2022-11-30 08:54:09 --> Total execution time: 0.8836
INFO - 2022-11-30 08:54:21 --> Config Class Initialized
INFO - 2022-11-30 08:54:21 --> Hooks Class Initialized
DEBUG - 2022-11-30 08:54:21 --> UTF-8 Support Enabled
INFO - 2022-11-30 08:54:21 --> Utf8 Class Initialized
INFO - 2022-11-30 08:54:21 --> URI Class Initialized
INFO - 2022-11-30 08:54:21 --> Router Class Initialized
INFO - 2022-11-30 08:54:21 --> Output Class Initialized
INFO - 2022-11-30 08:54:21 --> Security Class Initialized
DEBUG - 2022-11-30 08:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 08:54:21 --> Input Class Initialized
INFO - 2022-11-30 08:54:21 --> Language Class Initialized
INFO - 2022-11-30 08:54:21 --> Loader Class Initialized
INFO - 2022-11-30 08:54:21 --> Helper loaded: url_helper
INFO - 2022-11-30 08:54:21 --> Database Driver Class Initialized
INFO - 2022-11-30 08:54:21 --> Helper loaded: form_helper
INFO - 2022-11-30 08:54:21 --> Form Validation Class Initialized
INFO - 2022-11-30 08:54:21 --> Controller Class Initialized
INFO - 2022-11-30 08:54:21 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 08:54:22 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-30 08:54:22 --> Final output sent to browser
DEBUG - 2022-11-30 08:54:22 --> Total execution time: 0.2858
INFO - 2022-11-30 08:55:36 --> Config Class Initialized
INFO - 2022-11-30 08:55:36 --> Hooks Class Initialized
DEBUG - 2022-11-30 08:55:36 --> UTF-8 Support Enabled
INFO - 2022-11-30 08:55:36 --> Utf8 Class Initialized
INFO - 2022-11-30 08:55:36 --> URI Class Initialized
INFO - 2022-11-30 08:55:36 --> Router Class Initialized
INFO - 2022-11-30 08:55:36 --> Output Class Initialized
INFO - 2022-11-30 08:55:36 --> Security Class Initialized
DEBUG - 2022-11-30 08:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 08:55:36 --> Input Class Initialized
INFO - 2022-11-30 08:55:36 --> Language Class Initialized
ERROR - 2022-11-30 08:55:36 --> 404 Page Not Found: Penerbit/index
INFO - 2022-11-30 08:55:40 --> Config Class Initialized
INFO - 2022-11-30 08:55:40 --> Hooks Class Initialized
DEBUG - 2022-11-30 08:55:40 --> UTF-8 Support Enabled
INFO - 2022-11-30 08:55:40 --> Utf8 Class Initialized
INFO - 2022-11-30 08:55:40 --> URI Class Initialized
DEBUG - 2022-11-30 08:55:40 --> No URI present. Default controller set.
INFO - 2022-11-30 08:55:40 --> Router Class Initialized
INFO - 2022-11-30 08:55:40 --> Output Class Initialized
INFO - 2022-11-30 08:55:40 --> Security Class Initialized
DEBUG - 2022-11-30 08:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 08:55:40 --> Input Class Initialized
INFO - 2022-11-30 08:55:40 --> Language Class Initialized
INFO - 2022-11-30 08:55:40 --> Loader Class Initialized
INFO - 2022-11-30 08:55:40 --> Helper loaded: url_helper
INFO - 2022-11-30 08:55:40 --> Database Driver Class Initialized
INFO - 2022-11-30 08:55:40 --> Helper loaded: form_helper
INFO - 2022-11-30 08:55:40 --> Form Validation Class Initialized
INFO - 2022-11-30 08:55:40 --> Controller Class Initialized
INFO - 2022-11-30 08:55:40 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 08:55:40 --> Final output sent to browser
DEBUG - 2022-11-30 08:55:40 --> Total execution time: 0.0322
INFO - 2022-11-30 08:55:40 --> Config Class Initialized
INFO - 2022-11-30 08:55:40 --> Hooks Class Initialized
DEBUG - 2022-11-30 08:55:40 --> UTF-8 Support Enabled
INFO - 2022-11-30 08:55:40 --> Utf8 Class Initialized
INFO - 2022-11-30 08:55:40 --> URI Class Initialized
DEBUG - 2022-11-30 08:55:40 --> No URI present. Default controller set.
INFO - 2022-11-30 08:55:40 --> Router Class Initialized
INFO - 2022-11-30 08:55:40 --> Output Class Initialized
INFO - 2022-11-30 08:55:40 --> Security Class Initialized
DEBUG - 2022-11-30 08:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 08:55:40 --> Input Class Initialized
INFO - 2022-11-30 08:55:40 --> Language Class Initialized
INFO - 2022-11-30 08:55:40 --> Loader Class Initialized
INFO - 2022-11-30 08:55:40 --> Helper loaded: url_helper
INFO - 2022-11-30 08:55:40 --> Database Driver Class Initialized
INFO - 2022-11-30 08:55:40 --> Helper loaded: form_helper
INFO - 2022-11-30 08:55:40 --> Form Validation Class Initialized
INFO - 2022-11-30 08:55:40 --> Controller Class Initialized
INFO - 2022-11-30 08:55:40 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 08:55:40 --> Final output sent to browser
DEBUG - 2022-11-30 08:55:40 --> Total execution time: 0.0506
INFO - 2022-11-30 08:56:04 --> Config Class Initialized
INFO - 2022-11-30 08:56:04 --> Hooks Class Initialized
DEBUG - 2022-11-30 08:56:04 --> UTF-8 Support Enabled
INFO - 2022-11-30 08:56:04 --> Utf8 Class Initialized
INFO - 2022-11-30 08:56:04 --> URI Class Initialized
INFO - 2022-11-30 08:56:04 --> Router Class Initialized
INFO - 2022-11-30 08:56:04 --> Output Class Initialized
INFO - 2022-11-30 08:56:04 --> Security Class Initialized
DEBUG - 2022-11-30 08:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 08:56:04 --> Input Class Initialized
INFO - 2022-11-30 08:56:04 --> Language Class Initialized
INFO - 2022-11-30 08:56:04 --> Loader Class Initialized
INFO - 2022-11-30 08:56:04 --> Helper loaded: url_helper
INFO - 2022-11-30 08:56:04 --> Database Driver Class Initialized
INFO - 2022-11-30 08:56:04 --> Helper loaded: form_helper
INFO - 2022-11-30 08:56:04 --> Form Validation Class Initialized
INFO - 2022-11-30 08:56:04 --> Controller Class Initialized
INFO - 2022-11-30 08:56:04 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 08:56:04 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-30 08:56:04 --> Final output sent to browser
DEBUG - 2022-11-30 08:56:04 --> Total execution time: 0.0538
INFO - 2022-11-30 09:11:21 --> Config Class Initialized
INFO - 2022-11-30 09:11:21 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:11:21 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:11:21 --> Utf8 Class Initialized
INFO - 2022-11-30 09:11:21 --> URI Class Initialized
INFO - 2022-11-30 09:11:21 --> Router Class Initialized
INFO - 2022-11-30 09:11:21 --> Output Class Initialized
INFO - 2022-11-30 09:11:21 --> Security Class Initialized
DEBUG - 2022-11-30 09:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:11:21 --> Input Class Initialized
INFO - 2022-11-30 09:11:21 --> Language Class Initialized
INFO - 2022-11-30 09:11:21 --> Loader Class Initialized
INFO - 2022-11-30 09:11:21 --> Helper loaded: url_helper
INFO - 2022-11-30 09:11:21 --> Database Driver Class Initialized
INFO - 2022-11-30 09:11:21 --> Helper loaded: form_helper
INFO - 2022-11-30 09:11:21 --> Form Validation Class Initialized
INFO - 2022-11-30 09:11:21 --> Controller Class Initialized
INFO - 2022-11-30 09:11:21 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:11:21 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-30 09:11:21 --> Final output sent to browser
DEBUG - 2022-11-30 09:11:21 --> Total execution time: 0.0376
INFO - 2022-11-30 09:11:23 --> Config Class Initialized
INFO - 2022-11-30 09:11:23 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:11:23 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:11:23 --> Utf8 Class Initialized
INFO - 2022-11-30 09:11:23 --> URI Class Initialized
INFO - 2022-11-30 09:11:23 --> Router Class Initialized
INFO - 2022-11-30 09:11:23 --> Output Class Initialized
INFO - 2022-11-30 09:11:23 --> Security Class Initialized
DEBUG - 2022-11-30 09:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:11:23 --> Input Class Initialized
INFO - 2022-11-30 09:11:23 --> Language Class Initialized
INFO - 2022-11-30 09:11:23 --> Loader Class Initialized
INFO - 2022-11-30 09:11:23 --> Helper loaded: url_helper
INFO - 2022-11-30 09:11:23 --> Database Driver Class Initialized
INFO - 2022-11-30 09:11:23 --> Helper loaded: form_helper
INFO - 2022-11-30 09:11:23 --> Form Validation Class Initialized
INFO - 2022-11-30 09:11:23 --> Controller Class Initialized
INFO - 2022-11-30 09:11:23 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:11:23 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:11:23 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:11:23 --> Final output sent to browser
DEBUG - 2022-11-30 09:11:23 --> Total execution time: 0.0753
INFO - 2022-11-30 09:12:10 --> Config Class Initialized
INFO - 2022-11-30 09:12:10 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:12:10 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:12:10 --> Utf8 Class Initialized
INFO - 2022-11-30 09:12:10 --> URI Class Initialized
INFO - 2022-11-30 09:12:10 --> Router Class Initialized
INFO - 2022-11-30 09:12:10 --> Output Class Initialized
INFO - 2022-11-30 09:12:10 --> Security Class Initialized
DEBUG - 2022-11-30 09:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:12:10 --> Input Class Initialized
INFO - 2022-11-30 09:12:10 --> Language Class Initialized
INFO - 2022-11-30 09:12:10 --> Loader Class Initialized
INFO - 2022-11-30 09:12:10 --> Helper loaded: url_helper
INFO - 2022-11-30 09:12:10 --> Database Driver Class Initialized
INFO - 2022-11-30 09:12:10 --> Helper loaded: form_helper
INFO - 2022-11-30 09:12:10 --> Form Validation Class Initialized
INFO - 2022-11-30 09:12:10 --> Controller Class Initialized
INFO - 2022-11-30 09:12:10 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:12:10 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:12:10 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:12:10 --> Final output sent to browser
DEBUG - 2022-11-30 09:12:10 --> Total execution time: 0.0450
INFO - 2022-11-30 09:12:49 --> Config Class Initialized
INFO - 2022-11-30 09:12:49 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:12:49 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:12:49 --> Utf8 Class Initialized
INFO - 2022-11-30 09:12:49 --> URI Class Initialized
INFO - 2022-11-30 09:12:49 --> Router Class Initialized
INFO - 2022-11-30 09:12:49 --> Output Class Initialized
INFO - 2022-11-30 09:12:49 --> Security Class Initialized
DEBUG - 2022-11-30 09:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:12:49 --> Input Class Initialized
INFO - 2022-11-30 09:12:49 --> Language Class Initialized
INFO - 2022-11-30 09:12:49 --> Loader Class Initialized
INFO - 2022-11-30 09:12:49 --> Helper loaded: url_helper
INFO - 2022-11-30 09:12:49 --> Database Driver Class Initialized
INFO - 2022-11-30 09:12:49 --> Helper loaded: form_helper
INFO - 2022-11-30 09:12:49 --> Form Validation Class Initialized
INFO - 2022-11-30 09:12:49 --> Controller Class Initialized
INFO - 2022-11-30 09:12:49 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:12:49 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:12:49 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:12:49 --> Final output sent to browser
DEBUG - 2022-11-30 09:12:49 --> Total execution time: 0.0417
INFO - 2022-11-30 09:13:03 --> Config Class Initialized
INFO - 2022-11-30 09:13:03 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:13:03 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:13:03 --> Utf8 Class Initialized
INFO - 2022-11-30 09:13:03 --> URI Class Initialized
INFO - 2022-11-30 09:13:03 --> Router Class Initialized
INFO - 2022-11-30 09:13:03 --> Output Class Initialized
INFO - 2022-11-30 09:13:03 --> Security Class Initialized
DEBUG - 2022-11-30 09:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:13:03 --> Input Class Initialized
INFO - 2022-11-30 09:13:03 --> Language Class Initialized
INFO - 2022-11-30 09:13:03 --> Loader Class Initialized
INFO - 2022-11-30 09:13:03 --> Helper loaded: url_helper
INFO - 2022-11-30 09:13:03 --> Database Driver Class Initialized
INFO - 2022-11-30 09:13:03 --> Helper loaded: form_helper
INFO - 2022-11-30 09:13:03 --> Form Validation Class Initialized
INFO - 2022-11-30 09:13:03 --> Controller Class Initialized
INFO - 2022-11-30 09:13:03 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:13:03 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:13:03 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:13:03 --> Final output sent to browser
DEBUG - 2022-11-30 09:13:03 --> Total execution time: 0.0422
INFO - 2022-11-30 09:13:20 --> Config Class Initialized
INFO - 2022-11-30 09:13:20 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:13:20 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:13:20 --> Utf8 Class Initialized
INFO - 2022-11-30 09:13:20 --> URI Class Initialized
INFO - 2022-11-30 09:13:20 --> Router Class Initialized
INFO - 2022-11-30 09:13:20 --> Output Class Initialized
INFO - 2022-11-30 09:13:20 --> Security Class Initialized
DEBUG - 2022-11-30 09:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:13:20 --> Input Class Initialized
INFO - 2022-11-30 09:13:20 --> Language Class Initialized
INFO - 2022-11-30 09:13:20 --> Loader Class Initialized
INFO - 2022-11-30 09:13:20 --> Helper loaded: url_helper
INFO - 2022-11-30 09:13:20 --> Database Driver Class Initialized
INFO - 2022-11-30 09:13:20 --> Helper loaded: form_helper
INFO - 2022-11-30 09:13:20 --> Form Validation Class Initialized
INFO - 2022-11-30 09:13:20 --> Controller Class Initialized
INFO - 2022-11-30 09:13:20 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:13:20 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:13:20 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:13:20 --> Final output sent to browser
DEBUG - 2022-11-30 09:13:20 --> Total execution time: 0.0664
INFO - 2022-11-30 09:15:28 --> Config Class Initialized
INFO - 2022-11-30 09:15:28 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:15:28 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:15:28 --> Utf8 Class Initialized
INFO - 2022-11-30 09:15:28 --> URI Class Initialized
INFO - 2022-11-30 09:15:28 --> Router Class Initialized
INFO - 2022-11-30 09:15:28 --> Output Class Initialized
INFO - 2022-11-30 09:15:28 --> Security Class Initialized
DEBUG - 2022-11-30 09:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:15:28 --> Input Class Initialized
INFO - 2022-11-30 09:15:28 --> Language Class Initialized
INFO - 2022-11-30 09:15:28 --> Loader Class Initialized
INFO - 2022-11-30 09:15:28 --> Helper loaded: url_helper
INFO - 2022-11-30 09:15:28 --> Database Driver Class Initialized
INFO - 2022-11-30 09:15:28 --> Helper loaded: form_helper
INFO - 2022-11-30 09:15:28 --> Form Validation Class Initialized
INFO - 2022-11-30 09:15:28 --> Controller Class Initialized
INFO - 2022-11-30 09:15:28 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:15:28 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:15:28 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:15:28 --> Final output sent to browser
DEBUG - 2022-11-30 09:15:28 --> Total execution time: 0.0804
INFO - 2022-11-30 09:16:20 --> Config Class Initialized
INFO - 2022-11-30 09:16:20 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:16:20 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:16:20 --> Utf8 Class Initialized
INFO - 2022-11-30 09:16:20 --> URI Class Initialized
INFO - 2022-11-30 09:16:20 --> Router Class Initialized
INFO - 2022-11-30 09:16:20 --> Output Class Initialized
INFO - 2022-11-30 09:16:20 --> Security Class Initialized
DEBUG - 2022-11-30 09:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:16:20 --> Input Class Initialized
INFO - 2022-11-30 09:16:20 --> Language Class Initialized
INFO - 2022-11-30 09:16:20 --> Loader Class Initialized
INFO - 2022-11-30 09:16:20 --> Helper loaded: url_helper
INFO - 2022-11-30 09:16:20 --> Database Driver Class Initialized
INFO - 2022-11-30 09:16:20 --> Helper loaded: form_helper
INFO - 2022-11-30 09:16:20 --> Form Validation Class Initialized
INFO - 2022-11-30 09:16:20 --> Controller Class Initialized
INFO - 2022-11-30 09:16:20 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:16:20 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:16:20 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:16:20 --> Final output sent to browser
DEBUG - 2022-11-30 09:16:20 --> Total execution time: 0.0544
INFO - 2022-11-30 09:16:57 --> Config Class Initialized
INFO - 2022-11-30 09:16:57 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:16:57 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:16:57 --> Utf8 Class Initialized
INFO - 2022-11-30 09:16:57 --> URI Class Initialized
INFO - 2022-11-30 09:16:57 --> Router Class Initialized
INFO - 2022-11-30 09:16:57 --> Output Class Initialized
INFO - 2022-11-30 09:16:57 --> Security Class Initialized
DEBUG - 2022-11-30 09:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:16:57 --> Input Class Initialized
INFO - 2022-11-30 09:16:57 --> Language Class Initialized
INFO - 2022-11-30 09:16:57 --> Loader Class Initialized
INFO - 2022-11-30 09:16:57 --> Helper loaded: url_helper
INFO - 2022-11-30 09:16:57 --> Database Driver Class Initialized
INFO - 2022-11-30 09:16:57 --> Helper loaded: form_helper
INFO - 2022-11-30 09:16:57 --> Form Validation Class Initialized
INFO - 2022-11-30 09:16:57 --> Controller Class Initialized
INFO - 2022-11-30 09:16:57 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:16:57 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:16:57 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:16:57 --> Final output sent to browser
DEBUG - 2022-11-30 09:16:57 --> Total execution time: 0.0432
INFO - 2022-11-30 09:17:09 --> Config Class Initialized
INFO - 2022-11-30 09:17:09 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:17:09 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:17:09 --> Utf8 Class Initialized
INFO - 2022-11-30 09:17:09 --> URI Class Initialized
INFO - 2022-11-30 09:17:09 --> Router Class Initialized
INFO - 2022-11-30 09:17:09 --> Output Class Initialized
INFO - 2022-11-30 09:17:09 --> Security Class Initialized
DEBUG - 2022-11-30 09:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:17:09 --> Input Class Initialized
INFO - 2022-11-30 09:17:09 --> Language Class Initialized
INFO - 2022-11-30 09:17:09 --> Loader Class Initialized
INFO - 2022-11-30 09:17:09 --> Helper loaded: url_helper
INFO - 2022-11-30 09:17:09 --> Database Driver Class Initialized
INFO - 2022-11-30 09:17:09 --> Helper loaded: form_helper
INFO - 2022-11-30 09:17:09 --> Form Validation Class Initialized
INFO - 2022-11-30 09:17:09 --> Controller Class Initialized
INFO - 2022-11-30 09:17:09 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:17:09 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:17:09 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:17:09 --> Final output sent to browser
DEBUG - 2022-11-30 09:17:09 --> Total execution time: 0.0602
INFO - 2022-11-30 09:17:33 --> Config Class Initialized
INFO - 2022-11-30 09:17:33 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:17:33 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:17:33 --> Utf8 Class Initialized
INFO - 2022-11-30 09:17:33 --> URI Class Initialized
INFO - 2022-11-30 09:17:33 --> Router Class Initialized
INFO - 2022-11-30 09:17:33 --> Output Class Initialized
INFO - 2022-11-30 09:17:33 --> Security Class Initialized
DEBUG - 2022-11-30 09:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:17:33 --> Input Class Initialized
INFO - 2022-11-30 09:17:33 --> Language Class Initialized
INFO - 2022-11-30 09:17:33 --> Loader Class Initialized
INFO - 2022-11-30 09:17:33 --> Helper loaded: url_helper
INFO - 2022-11-30 09:17:33 --> Database Driver Class Initialized
INFO - 2022-11-30 09:17:33 --> Helper loaded: form_helper
INFO - 2022-11-30 09:17:33 --> Form Validation Class Initialized
INFO - 2022-11-30 09:17:33 --> Controller Class Initialized
INFO - 2022-11-30 09:17:33 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:17:33 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:17:33 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:17:33 --> Final output sent to browser
DEBUG - 2022-11-30 09:17:33 --> Total execution time: 0.0540
INFO - 2022-11-30 09:19:17 --> Config Class Initialized
INFO - 2022-11-30 09:19:17 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:19:17 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:19:17 --> Utf8 Class Initialized
INFO - 2022-11-30 09:19:17 --> URI Class Initialized
INFO - 2022-11-30 09:19:17 --> Router Class Initialized
INFO - 2022-11-30 09:19:17 --> Output Class Initialized
INFO - 2022-11-30 09:19:17 --> Security Class Initialized
DEBUG - 2022-11-30 09:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:19:17 --> Input Class Initialized
INFO - 2022-11-30 09:19:17 --> Language Class Initialized
INFO - 2022-11-30 09:19:17 --> Loader Class Initialized
INFO - 2022-11-30 09:19:17 --> Helper loaded: url_helper
INFO - 2022-11-30 09:19:17 --> Database Driver Class Initialized
INFO - 2022-11-30 09:19:17 --> Helper loaded: form_helper
INFO - 2022-11-30 09:19:17 --> Form Validation Class Initialized
INFO - 2022-11-30 09:19:17 --> Controller Class Initialized
INFO - 2022-11-30 09:19:17 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:19:17 --> Model "Penerbit_model" initialized
ERROR - 2022-11-30 09:19:17 --> Severity: Warning --> Undefined variable $nama C:\xampp\htdocs\ekatalog\application\views\buku\form.php 31
INFO - 2022-11-30 09:19:17 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 09:19:17 --> Final output sent to browser
DEBUG - 2022-11-30 09:19:17 --> Total execution time: 0.0664
INFO - 2022-11-30 09:20:02 --> Config Class Initialized
INFO - 2022-11-30 09:20:02 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:20:02 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:20:02 --> Utf8 Class Initialized
INFO - 2022-11-30 09:20:02 --> URI Class Initialized
INFO - 2022-11-30 09:20:02 --> Router Class Initialized
INFO - 2022-11-30 09:20:02 --> Output Class Initialized
INFO - 2022-11-30 09:20:02 --> Security Class Initialized
DEBUG - 2022-11-30 09:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:20:02 --> Input Class Initialized
INFO - 2022-11-30 09:20:02 --> Language Class Initialized
INFO - 2022-11-30 09:20:02 --> Loader Class Initialized
INFO - 2022-11-30 09:20:02 --> Helper loaded: url_helper
INFO - 2022-11-30 09:20:02 --> Database Driver Class Initialized
INFO - 2022-11-30 09:20:02 --> Helper loaded: form_helper
INFO - 2022-11-30 09:20:02 --> Form Validation Class Initialized
INFO - 2022-11-30 09:20:02 --> Controller Class Initialized
INFO - 2022-11-30 09:20:02 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:20:02 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:20:02 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 09:20:02 --> Final output sent to browser
DEBUG - 2022-11-30 09:20:02 --> Total execution time: 0.0495
INFO - 2022-11-30 09:21:00 --> Config Class Initialized
INFO - 2022-11-30 09:21:00 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:21:00 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:21:00 --> Utf8 Class Initialized
INFO - 2022-11-30 09:21:00 --> URI Class Initialized
INFO - 2022-11-30 09:21:00 --> Router Class Initialized
INFO - 2022-11-30 09:21:00 --> Output Class Initialized
INFO - 2022-11-30 09:21:00 --> Security Class Initialized
DEBUG - 2022-11-30 09:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:21:00 --> Input Class Initialized
INFO - 2022-11-30 09:21:00 --> Language Class Initialized
INFO - 2022-11-30 09:21:00 --> Loader Class Initialized
INFO - 2022-11-30 09:21:00 --> Helper loaded: url_helper
INFO - 2022-11-30 09:21:00 --> Database Driver Class Initialized
INFO - 2022-11-30 09:21:00 --> Helper loaded: form_helper
INFO - 2022-11-30 09:21:00 --> Form Validation Class Initialized
INFO - 2022-11-30 09:21:00 --> Controller Class Initialized
INFO - 2022-11-30 09:21:00 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:21:00 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:21:00 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 09:21:00 --> Final output sent to browser
DEBUG - 2022-11-30 09:21:00 --> Total execution time: 0.0374
INFO - 2022-11-30 09:21:36 --> Config Class Initialized
INFO - 2022-11-30 09:21:36 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:21:36 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:21:36 --> Utf8 Class Initialized
INFO - 2022-11-30 09:21:36 --> URI Class Initialized
INFO - 2022-11-30 09:21:36 --> Router Class Initialized
INFO - 2022-11-30 09:21:36 --> Output Class Initialized
INFO - 2022-11-30 09:21:36 --> Security Class Initialized
DEBUG - 2022-11-30 09:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:21:36 --> Input Class Initialized
INFO - 2022-11-30 09:21:36 --> Language Class Initialized
INFO - 2022-11-30 09:21:36 --> Loader Class Initialized
INFO - 2022-11-30 09:21:36 --> Helper loaded: url_helper
INFO - 2022-11-30 09:21:36 --> Database Driver Class Initialized
INFO - 2022-11-30 09:21:36 --> Helper loaded: form_helper
INFO - 2022-11-30 09:21:36 --> Form Validation Class Initialized
INFO - 2022-11-30 09:21:36 --> Controller Class Initialized
INFO - 2022-11-30 09:21:36 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:21:36 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:21:36 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 09:21:36 --> Final output sent to browser
DEBUG - 2022-11-30 09:21:36 --> Total execution time: 0.0412
INFO - 2022-11-30 09:22:04 --> Config Class Initialized
INFO - 2022-11-30 09:22:04 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:22:04 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:22:04 --> Utf8 Class Initialized
INFO - 2022-11-30 09:22:04 --> URI Class Initialized
INFO - 2022-11-30 09:22:04 --> Router Class Initialized
INFO - 2022-11-30 09:22:04 --> Output Class Initialized
INFO - 2022-11-30 09:22:04 --> Security Class Initialized
DEBUG - 2022-11-30 09:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:22:04 --> Input Class Initialized
INFO - 2022-11-30 09:22:04 --> Language Class Initialized
INFO - 2022-11-30 09:22:04 --> Loader Class Initialized
INFO - 2022-11-30 09:22:04 --> Helper loaded: url_helper
INFO - 2022-11-30 09:22:04 --> Database Driver Class Initialized
INFO - 2022-11-30 09:22:04 --> Helper loaded: form_helper
INFO - 2022-11-30 09:22:04 --> Form Validation Class Initialized
INFO - 2022-11-30 09:22:04 --> Controller Class Initialized
INFO - 2022-11-30 09:22:04 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:22:04 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:22:04 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 09:22:04 --> Final output sent to browser
DEBUG - 2022-11-30 09:22:04 --> Total execution time: 0.0593
INFO - 2022-11-30 09:24:06 --> Config Class Initialized
INFO - 2022-11-30 09:24:06 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:24:06 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:24:06 --> Utf8 Class Initialized
INFO - 2022-11-30 09:24:06 --> URI Class Initialized
INFO - 2022-11-30 09:24:06 --> Router Class Initialized
INFO - 2022-11-30 09:24:06 --> Output Class Initialized
INFO - 2022-11-30 09:24:06 --> Security Class Initialized
DEBUG - 2022-11-30 09:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:24:06 --> Input Class Initialized
INFO - 2022-11-30 09:24:06 --> Language Class Initialized
INFO - 2022-11-30 09:24:06 --> Loader Class Initialized
INFO - 2022-11-30 09:24:06 --> Helper loaded: url_helper
INFO - 2022-11-30 09:24:06 --> Database Driver Class Initialized
INFO - 2022-11-30 09:24:06 --> Helper loaded: form_helper
INFO - 2022-11-30 09:24:06 --> Form Validation Class Initialized
INFO - 2022-11-30 09:24:06 --> Controller Class Initialized
INFO - 2022-11-30 09:24:06 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:24:06 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-30 09:24:06 --> Final output sent to browser
DEBUG - 2022-11-30 09:24:06 --> Total execution time: 0.0507
INFO - 2022-11-30 09:24:09 --> Config Class Initialized
INFO - 2022-11-30 09:24:09 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:24:09 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:24:09 --> Utf8 Class Initialized
INFO - 2022-11-30 09:24:09 --> URI Class Initialized
INFO - 2022-11-30 09:24:09 --> Router Class Initialized
INFO - 2022-11-30 09:24:09 --> Output Class Initialized
INFO - 2022-11-30 09:24:09 --> Security Class Initialized
DEBUG - 2022-11-30 09:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:24:09 --> Input Class Initialized
INFO - 2022-11-30 09:24:09 --> Language Class Initialized
INFO - 2022-11-30 09:24:09 --> Loader Class Initialized
INFO - 2022-11-30 09:24:09 --> Helper loaded: url_helper
INFO - 2022-11-30 09:24:09 --> Database Driver Class Initialized
INFO - 2022-11-30 09:24:09 --> Helper loaded: form_helper
INFO - 2022-11-30 09:24:09 --> Form Validation Class Initialized
INFO - 2022-11-30 09:24:09 --> Controller Class Initialized
INFO - 2022-11-30 09:24:09 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:24:09 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-30 09:24:09 --> Final output sent to browser
DEBUG - 2022-11-30 09:24:09 --> Total execution time: 0.0640
INFO - 2022-11-30 09:24:57 --> Config Class Initialized
INFO - 2022-11-30 09:24:57 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:24:57 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:24:57 --> Utf8 Class Initialized
INFO - 2022-11-30 09:24:57 --> URI Class Initialized
INFO - 2022-11-30 09:24:57 --> Router Class Initialized
INFO - 2022-11-30 09:24:57 --> Output Class Initialized
INFO - 2022-11-30 09:24:57 --> Security Class Initialized
DEBUG - 2022-11-30 09:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:24:57 --> Input Class Initialized
INFO - 2022-11-30 09:24:57 --> Language Class Initialized
INFO - 2022-11-30 09:24:57 --> Loader Class Initialized
INFO - 2022-11-30 09:24:57 --> Helper loaded: url_helper
INFO - 2022-11-30 09:24:57 --> Database Driver Class Initialized
INFO - 2022-11-30 09:24:57 --> Helper loaded: form_helper
INFO - 2022-11-30 09:24:57 --> Form Validation Class Initialized
INFO - 2022-11-30 09:24:57 --> Controller Class Initialized
INFO - 2022-11-30 09:24:57 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:24:57 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-30 09:24:57 --> Final output sent to browser
DEBUG - 2022-11-30 09:24:57 --> Total execution time: 0.0603
INFO - 2022-11-30 09:25:11 --> Config Class Initialized
INFO - 2022-11-30 09:25:11 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:25:11 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:25:11 --> Utf8 Class Initialized
INFO - 2022-11-30 09:25:11 --> URI Class Initialized
INFO - 2022-11-30 09:25:11 --> Router Class Initialized
INFO - 2022-11-30 09:25:11 --> Output Class Initialized
INFO - 2022-11-30 09:25:11 --> Security Class Initialized
DEBUG - 2022-11-30 09:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:25:11 --> Input Class Initialized
INFO - 2022-11-30 09:25:11 --> Language Class Initialized
INFO - 2022-11-30 09:25:11 --> Loader Class Initialized
INFO - 2022-11-30 09:25:11 --> Helper loaded: url_helper
INFO - 2022-11-30 09:25:11 --> Database Driver Class Initialized
INFO - 2022-11-30 09:25:11 --> Helper loaded: form_helper
INFO - 2022-11-30 09:25:11 --> Form Validation Class Initialized
INFO - 2022-11-30 09:25:11 --> Controller Class Initialized
INFO - 2022-11-30 09:25:11 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:25:11 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-30 09:25:11 --> Final output sent to browser
DEBUG - 2022-11-30 09:25:11 --> Total execution time: 0.0631
INFO - 2022-11-30 09:25:13 --> Config Class Initialized
INFO - 2022-11-30 09:25:13 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:25:13 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:25:13 --> Utf8 Class Initialized
INFO - 2022-11-30 09:25:13 --> URI Class Initialized
INFO - 2022-11-30 09:25:13 --> Router Class Initialized
INFO - 2022-11-30 09:25:13 --> Output Class Initialized
INFO - 2022-11-30 09:25:13 --> Security Class Initialized
DEBUG - 2022-11-30 09:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:25:13 --> Input Class Initialized
INFO - 2022-11-30 09:25:13 --> Language Class Initialized
INFO - 2022-11-30 09:25:13 --> Loader Class Initialized
INFO - 2022-11-30 09:25:13 --> Helper loaded: url_helper
INFO - 2022-11-30 09:25:13 --> Database Driver Class Initialized
INFO - 2022-11-30 09:25:13 --> Helper loaded: form_helper
INFO - 2022-11-30 09:25:13 --> Form Validation Class Initialized
INFO - 2022-11-30 09:25:13 --> Controller Class Initialized
INFO - 2022-11-30 09:25:13 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:25:13 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-30 09:25:13 --> Final output sent to browser
DEBUG - 2022-11-30 09:25:13 --> Total execution time: 0.0537
INFO - 2022-11-30 09:27:38 --> Config Class Initialized
INFO - 2022-11-30 09:27:38 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:27:38 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:27:38 --> Utf8 Class Initialized
INFO - 2022-11-30 09:27:38 --> URI Class Initialized
INFO - 2022-11-30 09:27:38 --> Router Class Initialized
INFO - 2022-11-30 09:27:38 --> Output Class Initialized
INFO - 2022-11-30 09:27:38 --> Security Class Initialized
DEBUG - 2022-11-30 09:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:27:38 --> Input Class Initialized
INFO - 2022-11-30 09:27:38 --> Language Class Initialized
INFO - 2022-11-30 09:27:38 --> Loader Class Initialized
INFO - 2022-11-30 09:27:38 --> Helper loaded: url_helper
INFO - 2022-11-30 09:27:38 --> Database Driver Class Initialized
INFO - 2022-11-30 09:27:38 --> Helper loaded: form_helper
INFO - 2022-11-30 09:27:38 --> Form Validation Class Initialized
INFO - 2022-11-30 09:27:38 --> Controller Class Initialized
INFO - 2022-11-30 09:27:38 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:27:38 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-30 09:27:38 --> Final output sent to browser
DEBUG - 2022-11-30 09:27:38 --> Total execution time: 0.0442
INFO - 2022-11-30 09:27:41 --> Config Class Initialized
INFO - 2022-11-30 09:27:41 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:27:41 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:27:41 --> Utf8 Class Initialized
INFO - 2022-11-30 09:27:41 --> URI Class Initialized
INFO - 2022-11-30 09:27:41 --> Router Class Initialized
INFO - 2022-11-30 09:27:41 --> Output Class Initialized
INFO - 2022-11-30 09:27:41 --> Security Class Initialized
DEBUG - 2022-11-30 09:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:27:41 --> Input Class Initialized
INFO - 2022-11-30 09:27:41 --> Language Class Initialized
INFO - 2022-11-30 09:27:41 --> Loader Class Initialized
INFO - 2022-11-30 09:27:41 --> Helper loaded: url_helper
INFO - 2022-11-30 09:27:41 --> Database Driver Class Initialized
INFO - 2022-11-30 09:27:41 --> Helper loaded: form_helper
INFO - 2022-11-30 09:27:41 --> Form Validation Class Initialized
INFO - 2022-11-30 09:27:41 --> Controller Class Initialized
INFO - 2022-11-30 09:27:41 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:27:41 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-30 09:27:41 --> Final output sent to browser
DEBUG - 2022-11-30 09:27:41 --> Total execution time: 0.0350
INFO - 2022-11-30 09:27:41 --> Config Class Initialized
INFO - 2022-11-30 09:27:41 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:27:41 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:27:41 --> Utf8 Class Initialized
INFO - 2022-11-30 09:27:41 --> URI Class Initialized
INFO - 2022-11-30 09:27:41 --> Router Class Initialized
INFO - 2022-11-30 09:27:41 --> Output Class Initialized
INFO - 2022-11-30 09:27:41 --> Security Class Initialized
DEBUG - 2022-11-30 09:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:27:41 --> Input Class Initialized
INFO - 2022-11-30 09:27:41 --> Language Class Initialized
INFO - 2022-11-30 09:27:41 --> Loader Class Initialized
INFO - 2022-11-30 09:27:41 --> Helper loaded: url_helper
INFO - 2022-11-30 09:27:41 --> Database Driver Class Initialized
INFO - 2022-11-30 09:27:41 --> Helper loaded: form_helper
INFO - 2022-11-30 09:27:41 --> Form Validation Class Initialized
INFO - 2022-11-30 09:27:41 --> Controller Class Initialized
INFO - 2022-11-30 09:27:41 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:27:41 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-30 09:27:41 --> Final output sent to browser
DEBUG - 2022-11-30 09:27:41 --> Total execution time: 0.0350
INFO - 2022-11-30 09:27:41 --> Config Class Initialized
INFO - 2022-11-30 09:27:41 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:27:41 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:27:41 --> Utf8 Class Initialized
INFO - 2022-11-30 09:27:41 --> URI Class Initialized
INFO - 2022-11-30 09:27:41 --> Router Class Initialized
INFO - 2022-11-30 09:27:41 --> Output Class Initialized
INFO - 2022-11-30 09:27:41 --> Security Class Initialized
DEBUG - 2022-11-30 09:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:27:41 --> Input Class Initialized
INFO - 2022-11-30 09:27:41 --> Language Class Initialized
INFO - 2022-11-30 09:27:41 --> Loader Class Initialized
INFO - 2022-11-30 09:27:41 --> Helper loaded: url_helper
INFO - 2022-11-30 09:27:41 --> Database Driver Class Initialized
INFO - 2022-11-30 09:27:41 --> Helper loaded: form_helper
INFO - 2022-11-30 09:27:41 --> Form Validation Class Initialized
INFO - 2022-11-30 09:27:41 --> Controller Class Initialized
INFO - 2022-11-30 09:27:41 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:27:41 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-30 09:27:41 --> Final output sent to browser
DEBUG - 2022-11-30 09:27:41 --> Total execution time: 0.0588
INFO - 2022-11-30 09:28:29 --> Config Class Initialized
INFO - 2022-11-30 09:28:29 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:28:29 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:28:29 --> Utf8 Class Initialized
INFO - 2022-11-30 09:28:29 --> URI Class Initialized
INFO - 2022-11-30 09:28:29 --> Router Class Initialized
INFO - 2022-11-30 09:28:29 --> Output Class Initialized
INFO - 2022-11-30 09:28:29 --> Security Class Initialized
DEBUG - 2022-11-30 09:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:28:29 --> Input Class Initialized
INFO - 2022-11-30 09:28:29 --> Language Class Initialized
INFO - 2022-11-30 09:28:29 --> Loader Class Initialized
INFO - 2022-11-30 09:28:29 --> Helper loaded: url_helper
INFO - 2022-11-30 09:28:29 --> Database Driver Class Initialized
INFO - 2022-11-30 09:28:29 --> Helper loaded: form_helper
INFO - 2022-11-30 09:28:29 --> Form Validation Class Initialized
INFO - 2022-11-30 09:28:29 --> Controller Class Initialized
INFO - 2022-11-30 09:28:29 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:28:29 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-30 09:28:29 --> Final output sent to browser
DEBUG - 2022-11-30 09:28:29 --> Total execution time: 0.0387
INFO - 2022-11-30 09:28:30 --> Config Class Initialized
INFO - 2022-11-30 09:28:30 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:28:30 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:28:30 --> Utf8 Class Initialized
INFO - 2022-11-30 09:28:30 --> URI Class Initialized
INFO - 2022-11-30 09:28:30 --> Router Class Initialized
INFO - 2022-11-30 09:28:30 --> Output Class Initialized
INFO - 2022-11-30 09:28:30 --> Security Class Initialized
DEBUG - 2022-11-30 09:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:28:30 --> Input Class Initialized
INFO - 2022-11-30 09:28:30 --> Language Class Initialized
INFO - 2022-11-30 09:28:30 --> Loader Class Initialized
INFO - 2022-11-30 09:28:30 --> Helper loaded: url_helper
INFO - 2022-11-30 09:28:30 --> Database Driver Class Initialized
INFO - 2022-11-30 09:28:30 --> Helper loaded: form_helper
INFO - 2022-11-30 09:28:30 --> Form Validation Class Initialized
INFO - 2022-11-30 09:28:30 --> Controller Class Initialized
INFO - 2022-11-30 09:28:30 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:28:30 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-30 09:28:30 --> Final output sent to browser
DEBUG - 2022-11-30 09:28:30 --> Total execution time: 0.0341
INFO - 2022-11-30 09:28:30 --> Config Class Initialized
INFO - 2022-11-30 09:28:30 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:28:30 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:28:30 --> Utf8 Class Initialized
INFO - 2022-11-30 09:28:30 --> URI Class Initialized
INFO - 2022-11-30 09:28:30 --> Router Class Initialized
INFO - 2022-11-30 09:28:30 --> Output Class Initialized
INFO - 2022-11-30 09:28:30 --> Security Class Initialized
DEBUG - 2022-11-30 09:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:28:30 --> Input Class Initialized
INFO - 2022-11-30 09:28:30 --> Language Class Initialized
INFO - 2022-11-30 09:28:30 --> Loader Class Initialized
INFO - 2022-11-30 09:28:30 --> Helper loaded: url_helper
INFO - 2022-11-30 09:28:30 --> Database Driver Class Initialized
INFO - 2022-11-30 09:28:30 --> Helper loaded: form_helper
INFO - 2022-11-30 09:28:30 --> Form Validation Class Initialized
INFO - 2022-11-30 09:28:30 --> Controller Class Initialized
INFO - 2022-11-30 09:28:30 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:28:30 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-30 09:28:30 --> Final output sent to browser
DEBUG - 2022-11-30 09:28:30 --> Total execution time: 0.0335
INFO - 2022-11-30 09:28:31 --> Config Class Initialized
INFO - 2022-11-30 09:28:31 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:28:31 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:28:31 --> Utf8 Class Initialized
INFO - 2022-11-30 09:28:31 --> URI Class Initialized
INFO - 2022-11-30 09:28:31 --> Router Class Initialized
INFO - 2022-11-30 09:28:31 --> Output Class Initialized
INFO - 2022-11-30 09:28:31 --> Security Class Initialized
DEBUG - 2022-11-30 09:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:28:31 --> Input Class Initialized
INFO - 2022-11-30 09:28:31 --> Language Class Initialized
INFO - 2022-11-30 09:28:31 --> Loader Class Initialized
INFO - 2022-11-30 09:28:31 --> Helper loaded: url_helper
INFO - 2022-11-30 09:28:31 --> Database Driver Class Initialized
INFO - 2022-11-30 09:28:31 --> Helper loaded: form_helper
INFO - 2022-11-30 09:28:31 --> Form Validation Class Initialized
INFO - 2022-11-30 09:28:31 --> Controller Class Initialized
INFO - 2022-11-30 09:28:31 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:28:31 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:28:31 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:28:31 --> Final output sent to browser
DEBUG - 2022-11-30 09:28:31 --> Total execution time: 0.0537
INFO - 2022-11-30 09:28:33 --> Config Class Initialized
INFO - 2022-11-30 09:28:33 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:28:33 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:28:33 --> Utf8 Class Initialized
INFO - 2022-11-30 09:28:33 --> URI Class Initialized
INFO - 2022-11-30 09:28:33 --> Router Class Initialized
INFO - 2022-11-30 09:28:33 --> Output Class Initialized
INFO - 2022-11-30 09:28:33 --> Security Class Initialized
DEBUG - 2022-11-30 09:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:28:33 --> Input Class Initialized
INFO - 2022-11-30 09:28:33 --> Language Class Initialized
INFO - 2022-11-30 09:28:33 --> Loader Class Initialized
INFO - 2022-11-30 09:28:33 --> Helper loaded: url_helper
INFO - 2022-11-30 09:28:33 --> Database Driver Class Initialized
INFO - 2022-11-30 09:28:33 --> Helper loaded: form_helper
INFO - 2022-11-30 09:28:33 --> Form Validation Class Initialized
INFO - 2022-11-30 09:28:33 --> Controller Class Initialized
INFO - 2022-11-30 09:28:33 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:28:33 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:28:33 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 09:28:33 --> Final output sent to browser
DEBUG - 2022-11-30 09:28:33 --> Total execution time: 0.0626
INFO - 2022-11-30 09:28:49 --> Config Class Initialized
INFO - 2022-11-30 09:28:49 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:28:49 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:28:49 --> Utf8 Class Initialized
INFO - 2022-11-30 09:28:49 --> URI Class Initialized
INFO - 2022-11-30 09:28:49 --> Router Class Initialized
INFO - 2022-11-30 09:28:49 --> Output Class Initialized
INFO - 2022-11-30 09:28:49 --> Security Class Initialized
DEBUG - 2022-11-30 09:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:28:49 --> Input Class Initialized
INFO - 2022-11-30 09:28:49 --> Language Class Initialized
INFO - 2022-11-30 09:28:49 --> Loader Class Initialized
INFO - 2022-11-30 09:28:49 --> Helper loaded: url_helper
INFO - 2022-11-30 09:28:49 --> Database Driver Class Initialized
INFO - 2022-11-30 09:28:49 --> Helper loaded: form_helper
INFO - 2022-11-30 09:28:49 --> Form Validation Class Initialized
INFO - 2022-11-30 09:28:49 --> Controller Class Initialized
INFO - 2022-11-30 09:28:49 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:28:49 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:28:49 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-30 09:28:49 --> Final output sent to browser
DEBUG - 2022-11-30 09:28:49 --> Total execution time: 0.0518
INFO - 2022-11-30 09:29:04 --> Config Class Initialized
INFO - 2022-11-30 09:29:04 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:29:04 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:29:04 --> Utf8 Class Initialized
INFO - 2022-11-30 09:29:04 --> URI Class Initialized
INFO - 2022-11-30 09:29:04 --> Router Class Initialized
INFO - 2022-11-30 09:29:04 --> Output Class Initialized
INFO - 2022-11-30 09:29:04 --> Security Class Initialized
DEBUG - 2022-11-30 09:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:29:04 --> Input Class Initialized
INFO - 2022-11-30 09:29:04 --> Language Class Initialized
INFO - 2022-11-30 09:29:04 --> Loader Class Initialized
INFO - 2022-11-30 09:29:04 --> Helper loaded: url_helper
INFO - 2022-11-30 09:29:04 --> Database Driver Class Initialized
INFO - 2022-11-30 09:29:04 --> Helper loaded: form_helper
INFO - 2022-11-30 09:29:04 --> Form Validation Class Initialized
INFO - 2022-11-30 09:29:04 --> Controller Class Initialized
INFO - 2022-11-30 09:29:04 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:29:04 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:29:04 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:29:04 --> Final output sent to browser
DEBUG - 2022-11-30 09:29:04 --> Total execution time: 0.0404
INFO - 2022-11-30 09:29:05 --> Config Class Initialized
INFO - 2022-11-30 09:29:05 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:29:05 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:29:05 --> Utf8 Class Initialized
INFO - 2022-11-30 09:29:05 --> URI Class Initialized
INFO - 2022-11-30 09:29:05 --> Router Class Initialized
INFO - 2022-11-30 09:29:05 --> Output Class Initialized
INFO - 2022-11-30 09:29:05 --> Security Class Initialized
DEBUG - 2022-11-30 09:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:29:05 --> Input Class Initialized
INFO - 2022-11-30 09:29:05 --> Language Class Initialized
INFO - 2022-11-30 09:29:05 --> Loader Class Initialized
INFO - 2022-11-30 09:29:05 --> Helper loaded: url_helper
INFO - 2022-11-30 09:29:05 --> Database Driver Class Initialized
INFO - 2022-11-30 09:29:05 --> Helper loaded: form_helper
INFO - 2022-11-30 09:29:05 --> Form Validation Class Initialized
INFO - 2022-11-30 09:29:05 --> Controller Class Initialized
INFO - 2022-11-30 09:29:05 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:29:05 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:29:05 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-30 09:29:05 --> Final output sent to browser
DEBUG - 2022-11-30 09:29:05 --> Total execution time: 0.0509
INFO - 2022-11-30 09:29:06 --> Config Class Initialized
INFO - 2022-11-30 09:29:06 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:29:06 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:29:06 --> Utf8 Class Initialized
INFO - 2022-11-30 09:29:06 --> URI Class Initialized
INFO - 2022-11-30 09:29:06 --> Router Class Initialized
INFO - 2022-11-30 09:29:06 --> Output Class Initialized
INFO - 2022-11-30 09:29:06 --> Security Class Initialized
DEBUG - 2022-11-30 09:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:29:06 --> Input Class Initialized
INFO - 2022-11-30 09:29:07 --> Language Class Initialized
INFO - 2022-11-30 09:29:07 --> Loader Class Initialized
INFO - 2022-11-30 09:29:07 --> Helper loaded: url_helper
INFO - 2022-11-30 09:29:07 --> Database Driver Class Initialized
INFO - 2022-11-30 09:29:07 --> Helper loaded: form_helper
INFO - 2022-11-30 09:29:07 --> Form Validation Class Initialized
INFO - 2022-11-30 09:29:07 --> Controller Class Initialized
INFO - 2022-11-30 09:29:07 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:29:07 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-30 09:29:07 --> Final output sent to browser
DEBUG - 2022-11-30 09:29:07 --> Total execution time: 0.0536
INFO - 2022-11-30 09:29:08 --> Config Class Initialized
INFO - 2022-11-30 09:29:08 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:29:08 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:29:08 --> Utf8 Class Initialized
INFO - 2022-11-30 09:29:08 --> URI Class Initialized
INFO - 2022-11-30 09:29:08 --> Router Class Initialized
INFO - 2022-11-30 09:29:08 --> Output Class Initialized
INFO - 2022-11-30 09:29:08 --> Security Class Initialized
DEBUG - 2022-11-30 09:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:29:08 --> Input Class Initialized
INFO - 2022-11-30 09:29:08 --> Language Class Initialized
INFO - 2022-11-30 09:29:08 --> Loader Class Initialized
INFO - 2022-11-30 09:29:08 --> Helper loaded: url_helper
INFO - 2022-11-30 09:29:08 --> Database Driver Class Initialized
INFO - 2022-11-30 09:29:08 --> Helper loaded: form_helper
INFO - 2022-11-30 09:29:08 --> Form Validation Class Initialized
INFO - 2022-11-30 09:29:08 --> Controller Class Initialized
INFO - 2022-11-30 09:29:08 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:29:08 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-30 09:29:08 --> Final output sent to browser
DEBUG - 2022-11-30 09:29:08 --> Total execution time: 0.0557
INFO - 2022-11-30 09:29:14 --> Config Class Initialized
INFO - 2022-11-30 09:29:14 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:29:14 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:29:14 --> Utf8 Class Initialized
INFO - 2022-11-30 09:29:14 --> URI Class Initialized
INFO - 2022-11-30 09:29:14 --> Router Class Initialized
INFO - 2022-11-30 09:29:14 --> Output Class Initialized
INFO - 2022-11-30 09:29:14 --> Security Class Initialized
DEBUG - 2022-11-30 09:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:29:14 --> Input Class Initialized
INFO - 2022-11-30 09:29:14 --> Language Class Initialized
INFO - 2022-11-30 09:29:14 --> Loader Class Initialized
INFO - 2022-11-30 09:29:14 --> Helper loaded: url_helper
INFO - 2022-11-30 09:29:14 --> Database Driver Class Initialized
INFO - 2022-11-30 09:29:14 --> Helper loaded: form_helper
INFO - 2022-11-30 09:29:14 --> Form Validation Class Initialized
INFO - 2022-11-30 09:29:14 --> Controller Class Initialized
INFO - 2022-11-30 09:29:14 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:29:14 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:29:14 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:29:14 --> Final output sent to browser
DEBUG - 2022-11-30 09:29:14 --> Total execution time: 0.0356
INFO - 2022-11-30 09:29:45 --> Config Class Initialized
INFO - 2022-11-30 09:29:45 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:29:45 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:29:45 --> Utf8 Class Initialized
INFO - 2022-11-30 09:29:45 --> URI Class Initialized
INFO - 2022-11-30 09:29:45 --> Router Class Initialized
INFO - 2022-11-30 09:29:45 --> Output Class Initialized
INFO - 2022-11-30 09:29:45 --> Security Class Initialized
DEBUG - 2022-11-30 09:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:29:45 --> Input Class Initialized
INFO - 2022-11-30 09:29:45 --> Language Class Initialized
INFO - 2022-11-30 09:29:45 --> Loader Class Initialized
INFO - 2022-11-30 09:29:45 --> Helper loaded: url_helper
INFO - 2022-11-30 09:29:45 --> Database Driver Class Initialized
INFO - 2022-11-30 09:29:45 --> Helper loaded: form_helper
INFO - 2022-11-30 09:29:45 --> Form Validation Class Initialized
INFO - 2022-11-30 09:29:45 --> Controller Class Initialized
INFO - 2022-11-30 09:29:45 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:29:45 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-30 09:29:45 --> Final output sent to browser
DEBUG - 2022-11-30 09:29:45 --> Total execution time: 0.0683
INFO - 2022-11-30 09:29:51 --> Config Class Initialized
INFO - 2022-11-30 09:29:51 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:29:51 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:29:51 --> Utf8 Class Initialized
INFO - 2022-11-30 09:29:51 --> URI Class Initialized
INFO - 2022-11-30 09:29:51 --> Router Class Initialized
INFO - 2022-11-30 09:29:51 --> Output Class Initialized
INFO - 2022-11-30 09:29:51 --> Security Class Initialized
DEBUG - 2022-11-30 09:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:29:51 --> Input Class Initialized
INFO - 2022-11-30 09:29:51 --> Language Class Initialized
INFO - 2022-11-30 09:29:51 --> Loader Class Initialized
INFO - 2022-11-30 09:29:51 --> Helper loaded: url_helper
INFO - 2022-11-30 09:29:51 --> Database Driver Class Initialized
INFO - 2022-11-30 09:29:51 --> Helper loaded: form_helper
INFO - 2022-11-30 09:29:51 --> Form Validation Class Initialized
INFO - 2022-11-30 09:29:51 --> Controller Class Initialized
INFO - 2022-11-30 09:29:51 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:29:51 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:29:51 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 09:29:51 --> Final output sent to browser
DEBUG - 2022-11-30 09:29:51 --> Total execution time: 0.0472
INFO - 2022-11-30 09:29:53 --> Config Class Initialized
INFO - 2022-11-30 09:29:53 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:29:53 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:29:53 --> Utf8 Class Initialized
INFO - 2022-11-30 09:29:53 --> URI Class Initialized
INFO - 2022-11-30 09:29:53 --> Router Class Initialized
INFO - 2022-11-30 09:29:53 --> Output Class Initialized
INFO - 2022-11-30 09:29:53 --> Security Class Initialized
DEBUG - 2022-11-30 09:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:29:53 --> Input Class Initialized
INFO - 2022-11-30 09:29:53 --> Language Class Initialized
INFO - 2022-11-30 09:29:53 --> Loader Class Initialized
INFO - 2022-11-30 09:29:53 --> Helper loaded: url_helper
INFO - 2022-11-30 09:29:53 --> Database Driver Class Initialized
INFO - 2022-11-30 09:29:53 --> Helper loaded: form_helper
INFO - 2022-11-30 09:29:53 --> Form Validation Class Initialized
INFO - 2022-11-30 09:29:53 --> Controller Class Initialized
INFO - 2022-11-30 09:29:53 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:29:53 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:29:53 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-30 09:29:53 --> Final output sent to browser
DEBUG - 2022-11-30 09:29:53 --> Total execution time: 0.0560
INFO - 2022-11-30 09:29:56 --> Config Class Initialized
INFO - 2022-11-30 09:29:56 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:29:56 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:29:56 --> Utf8 Class Initialized
INFO - 2022-11-30 09:29:56 --> URI Class Initialized
INFO - 2022-11-30 09:29:56 --> Router Class Initialized
INFO - 2022-11-30 09:29:56 --> Output Class Initialized
INFO - 2022-11-30 09:29:56 --> Security Class Initialized
DEBUG - 2022-11-30 09:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:29:56 --> Input Class Initialized
INFO - 2022-11-30 09:29:56 --> Language Class Initialized
INFO - 2022-11-30 09:29:56 --> Loader Class Initialized
INFO - 2022-11-30 09:29:56 --> Helper loaded: url_helper
INFO - 2022-11-30 09:29:56 --> Database Driver Class Initialized
INFO - 2022-11-30 09:29:56 --> Helper loaded: form_helper
INFO - 2022-11-30 09:29:56 --> Form Validation Class Initialized
INFO - 2022-11-30 09:29:56 --> Controller Class Initialized
INFO - 2022-11-30 09:29:56 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:29:56 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:29:56 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 09:29:56 --> Final output sent to browser
DEBUG - 2022-11-30 09:29:56 --> Total execution time: 0.0652
INFO - 2022-11-30 09:30:31 --> Config Class Initialized
INFO - 2022-11-30 09:30:31 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:30:31 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:30:31 --> Utf8 Class Initialized
INFO - 2022-11-30 09:30:31 --> URI Class Initialized
INFO - 2022-11-30 09:30:31 --> Router Class Initialized
INFO - 2022-11-30 09:30:31 --> Output Class Initialized
INFO - 2022-11-30 09:30:31 --> Security Class Initialized
DEBUG - 2022-11-30 09:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:30:31 --> Input Class Initialized
INFO - 2022-11-30 09:30:31 --> Language Class Initialized
INFO - 2022-11-30 09:30:31 --> Loader Class Initialized
INFO - 2022-11-30 09:30:31 --> Helper loaded: url_helper
INFO - 2022-11-30 09:30:31 --> Database Driver Class Initialized
INFO - 2022-11-30 09:30:31 --> Helper loaded: form_helper
INFO - 2022-11-30 09:30:31 --> Form Validation Class Initialized
INFO - 2022-11-30 09:30:31 --> Controller Class Initialized
INFO - 2022-11-30 09:30:31 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:30:31 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:30:31 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:30:31 --> Final output sent to browser
DEBUG - 2022-11-30 09:30:31 --> Total execution time: 0.0334
INFO - 2022-11-30 09:30:32 --> Config Class Initialized
INFO - 2022-11-30 09:30:32 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:30:32 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:30:32 --> Utf8 Class Initialized
INFO - 2022-11-30 09:30:32 --> URI Class Initialized
INFO - 2022-11-30 09:30:32 --> Router Class Initialized
INFO - 2022-11-30 09:30:32 --> Output Class Initialized
INFO - 2022-11-30 09:30:32 --> Security Class Initialized
DEBUG - 2022-11-30 09:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:30:32 --> Input Class Initialized
INFO - 2022-11-30 09:30:32 --> Language Class Initialized
INFO - 2022-11-30 09:30:32 --> Loader Class Initialized
INFO - 2022-11-30 09:30:32 --> Helper loaded: url_helper
INFO - 2022-11-30 09:30:32 --> Database Driver Class Initialized
INFO - 2022-11-30 09:30:33 --> Helper loaded: form_helper
INFO - 2022-11-30 09:30:33 --> Form Validation Class Initialized
INFO - 2022-11-30 09:30:33 --> Controller Class Initialized
INFO - 2022-11-30 09:30:33 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:30:33 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:30:33 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 09:30:33 --> Final output sent to browser
DEBUG - 2022-11-30 09:30:33 --> Total execution time: 0.0617
INFO - 2022-11-30 09:30:37 --> Config Class Initialized
INFO - 2022-11-30 09:30:37 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:30:37 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:30:37 --> Utf8 Class Initialized
INFO - 2022-11-30 09:30:37 --> URI Class Initialized
INFO - 2022-11-30 09:30:37 --> Router Class Initialized
INFO - 2022-11-30 09:30:37 --> Output Class Initialized
INFO - 2022-11-30 09:30:37 --> Security Class Initialized
DEBUG - 2022-11-30 09:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:30:37 --> Input Class Initialized
INFO - 2022-11-30 09:30:37 --> Language Class Initialized
INFO - 2022-11-30 09:30:37 --> Loader Class Initialized
INFO - 2022-11-30 09:30:37 --> Helper loaded: url_helper
INFO - 2022-11-30 09:30:37 --> Database Driver Class Initialized
INFO - 2022-11-30 09:30:37 --> Helper loaded: form_helper
INFO - 2022-11-30 09:30:37 --> Form Validation Class Initialized
INFO - 2022-11-30 09:30:37 --> Controller Class Initialized
INFO - 2022-11-30 09:30:37 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:30:37 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:30:37 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 09:30:37 --> Final output sent to browser
DEBUG - 2022-11-30 09:30:37 --> Total execution time: 0.0493
INFO - 2022-11-30 09:30:51 --> Config Class Initialized
INFO - 2022-11-30 09:30:51 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:30:51 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:30:51 --> Utf8 Class Initialized
INFO - 2022-11-30 09:30:51 --> URI Class Initialized
INFO - 2022-11-30 09:30:51 --> Router Class Initialized
INFO - 2022-11-30 09:30:51 --> Output Class Initialized
INFO - 2022-11-30 09:30:51 --> Security Class Initialized
DEBUG - 2022-11-30 09:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:30:51 --> Input Class Initialized
INFO - 2022-11-30 09:30:51 --> Language Class Initialized
INFO - 2022-11-30 09:30:51 --> Loader Class Initialized
INFO - 2022-11-30 09:30:51 --> Helper loaded: url_helper
INFO - 2022-11-30 09:30:51 --> Database Driver Class Initialized
INFO - 2022-11-30 09:30:51 --> Helper loaded: form_helper
INFO - 2022-11-30 09:30:51 --> Form Validation Class Initialized
INFO - 2022-11-30 09:30:51 --> Controller Class Initialized
INFO - 2022-11-30 09:30:51 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:30:51 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:30:51 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:30:51 --> Final output sent to browser
DEBUG - 2022-11-30 09:30:51 --> Total execution time: 0.0364
INFO - 2022-11-30 09:30:52 --> Config Class Initialized
INFO - 2022-11-30 09:30:52 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:30:52 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:30:52 --> Utf8 Class Initialized
INFO - 2022-11-30 09:30:52 --> URI Class Initialized
INFO - 2022-11-30 09:30:52 --> Router Class Initialized
INFO - 2022-11-30 09:30:52 --> Output Class Initialized
INFO - 2022-11-30 09:30:52 --> Security Class Initialized
DEBUG - 2022-11-30 09:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:30:52 --> Input Class Initialized
INFO - 2022-11-30 09:30:52 --> Language Class Initialized
INFO - 2022-11-30 09:30:52 --> Loader Class Initialized
INFO - 2022-11-30 09:30:52 --> Helper loaded: url_helper
INFO - 2022-11-30 09:30:52 --> Database Driver Class Initialized
INFO - 2022-11-30 09:30:52 --> Helper loaded: form_helper
INFO - 2022-11-30 09:30:52 --> Form Validation Class Initialized
INFO - 2022-11-30 09:30:52 --> Controller Class Initialized
INFO - 2022-11-30 09:30:52 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 09:30:52 --> Final output sent to browser
DEBUG - 2022-11-30 09:30:52 --> Total execution time: 0.0300
INFO - 2022-11-30 09:46:34 --> Config Class Initialized
INFO - 2022-11-30 09:46:34 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:46:34 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:46:34 --> Utf8 Class Initialized
INFO - 2022-11-30 09:46:34 --> URI Class Initialized
INFO - 2022-11-30 09:46:34 --> Router Class Initialized
INFO - 2022-11-30 09:46:34 --> Output Class Initialized
INFO - 2022-11-30 09:46:34 --> Security Class Initialized
DEBUG - 2022-11-30 09:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:46:34 --> Input Class Initialized
INFO - 2022-11-30 09:46:34 --> Language Class Initialized
INFO - 2022-11-30 09:46:34 --> Loader Class Initialized
INFO - 2022-11-30 09:46:34 --> Helper loaded: url_helper
INFO - 2022-11-30 09:46:34 --> Database Driver Class Initialized
INFO - 2022-11-30 09:46:34 --> Helper loaded: form_helper
INFO - 2022-11-30 09:46:34 --> Form Validation Class Initialized
INFO - 2022-11-30 09:46:34 --> Controller Class Initialized
INFO - 2022-11-30 09:46:34 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:46:34 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-30 09:46:34 --> Final output sent to browser
DEBUG - 2022-11-30 09:46:34 --> Total execution time: 0.0483
INFO - 2022-11-30 09:46:36 --> Config Class Initialized
INFO - 2022-11-30 09:46:36 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:46:36 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:46:36 --> Utf8 Class Initialized
INFO - 2022-11-30 09:46:36 --> URI Class Initialized
INFO - 2022-11-30 09:46:36 --> Router Class Initialized
INFO - 2022-11-30 09:46:36 --> Output Class Initialized
INFO - 2022-11-30 09:46:36 --> Security Class Initialized
DEBUG - 2022-11-30 09:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:46:36 --> Input Class Initialized
INFO - 2022-11-30 09:46:36 --> Language Class Initialized
INFO - 2022-11-30 09:46:36 --> Loader Class Initialized
INFO - 2022-11-30 09:46:36 --> Helper loaded: url_helper
INFO - 2022-11-30 09:46:36 --> Database Driver Class Initialized
INFO - 2022-11-30 09:46:36 --> Helper loaded: form_helper
INFO - 2022-11-30 09:46:36 --> Form Validation Class Initialized
INFO - 2022-11-30 09:46:36 --> Controller Class Initialized
INFO - 2022-11-30 09:46:36 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:46:36 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:46:36 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:46:36 --> Final output sent to browser
DEBUG - 2022-11-30 09:46:36 --> Total execution time: 0.0479
INFO - 2022-11-30 09:46:38 --> Config Class Initialized
INFO - 2022-11-30 09:46:38 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:46:38 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:46:38 --> Utf8 Class Initialized
INFO - 2022-11-30 09:46:38 --> URI Class Initialized
INFO - 2022-11-30 09:46:38 --> Router Class Initialized
INFO - 2022-11-30 09:46:38 --> Output Class Initialized
INFO - 2022-11-30 09:46:38 --> Security Class Initialized
DEBUG - 2022-11-30 09:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:46:38 --> Input Class Initialized
INFO - 2022-11-30 09:46:38 --> Language Class Initialized
INFO - 2022-11-30 09:46:38 --> Loader Class Initialized
INFO - 2022-11-30 09:46:38 --> Helper loaded: url_helper
INFO - 2022-11-30 09:46:38 --> Database Driver Class Initialized
INFO - 2022-11-30 09:46:38 --> Helper loaded: form_helper
INFO - 2022-11-30 09:46:38 --> Form Validation Class Initialized
INFO - 2022-11-30 09:46:38 --> Controller Class Initialized
INFO - 2022-11-30 09:46:38 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:46:38 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:46:38 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 09:46:38 --> Final output sent to browser
DEBUG - 2022-11-30 09:46:38 --> Total execution time: 0.0767
INFO - 2022-11-30 09:50:20 --> Config Class Initialized
INFO - 2022-11-30 09:50:20 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:50:20 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:50:20 --> Utf8 Class Initialized
INFO - 2022-11-30 09:50:20 --> URI Class Initialized
INFO - 2022-11-30 09:50:20 --> Router Class Initialized
INFO - 2022-11-30 09:50:20 --> Output Class Initialized
INFO - 2022-11-30 09:50:20 --> Security Class Initialized
DEBUG - 2022-11-30 09:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:50:20 --> Input Class Initialized
INFO - 2022-11-30 09:50:20 --> Language Class Initialized
INFO - 2022-11-30 09:50:20 --> Loader Class Initialized
INFO - 2022-11-30 09:50:20 --> Helper loaded: url_helper
INFO - 2022-11-30 09:50:20 --> Database Driver Class Initialized
INFO - 2022-11-30 09:50:20 --> Helper loaded: form_helper
INFO - 2022-11-30 09:50:20 --> Form Validation Class Initialized
INFO - 2022-11-30 09:50:20 --> Controller Class Initialized
INFO - 2022-11-30 09:50:20 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:50:20 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:50:20 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:50:20 --> Final output sent to browser
DEBUG - 2022-11-30 09:50:20 --> Total execution time: 0.0590
INFO - 2022-11-30 09:50:25 --> Config Class Initialized
INFO - 2022-11-30 09:50:25 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:50:25 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:50:25 --> Utf8 Class Initialized
INFO - 2022-11-30 09:50:25 --> URI Class Initialized
INFO - 2022-11-30 09:50:25 --> Router Class Initialized
INFO - 2022-11-30 09:50:25 --> Output Class Initialized
INFO - 2022-11-30 09:50:25 --> Security Class Initialized
DEBUG - 2022-11-30 09:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:50:25 --> Input Class Initialized
INFO - 2022-11-30 09:50:25 --> Language Class Initialized
INFO - 2022-11-30 09:50:25 --> Loader Class Initialized
INFO - 2022-11-30 09:50:25 --> Helper loaded: url_helper
INFO - 2022-11-30 09:50:25 --> Database Driver Class Initialized
INFO - 2022-11-30 09:50:25 --> Helper loaded: form_helper
INFO - 2022-11-30 09:50:25 --> Form Validation Class Initialized
INFO - 2022-11-30 09:50:25 --> Controller Class Initialized
INFO - 2022-11-30 09:50:25 --> Model "Buku_model" initialized
ERROR - 2022-11-30 09:50:25 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 26
INFO - 2022-11-30 09:51:50 --> Config Class Initialized
INFO - 2022-11-30 09:51:50 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:51:50 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:51:50 --> Utf8 Class Initialized
INFO - 2022-11-30 09:51:50 --> URI Class Initialized
INFO - 2022-11-30 09:51:50 --> Router Class Initialized
INFO - 2022-11-30 09:51:50 --> Output Class Initialized
INFO - 2022-11-30 09:51:50 --> Security Class Initialized
DEBUG - 2022-11-30 09:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:51:50 --> Input Class Initialized
INFO - 2022-11-30 09:51:50 --> Language Class Initialized
INFO - 2022-11-30 09:51:50 --> Loader Class Initialized
INFO - 2022-11-30 09:51:50 --> Helper loaded: url_helper
INFO - 2022-11-30 09:51:50 --> Database Driver Class Initialized
INFO - 2022-11-30 09:51:50 --> Helper loaded: form_helper
INFO - 2022-11-30 09:51:50 --> Form Validation Class Initialized
INFO - 2022-11-30 09:51:50 --> Controller Class Initialized
INFO - 2022-11-30 09:51:50 --> Model "Buku_model" initialized
ERROR - 2022-11-30 09:51:50 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 09:51:51 --> Config Class Initialized
INFO - 2022-11-30 09:51:51 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:51:51 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:51:51 --> Utf8 Class Initialized
INFO - 2022-11-30 09:51:51 --> URI Class Initialized
INFO - 2022-11-30 09:51:51 --> Router Class Initialized
INFO - 2022-11-30 09:51:51 --> Output Class Initialized
INFO - 2022-11-30 09:51:51 --> Security Class Initialized
DEBUG - 2022-11-30 09:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:51:51 --> Input Class Initialized
INFO - 2022-11-30 09:51:51 --> Language Class Initialized
INFO - 2022-11-30 09:51:51 --> Loader Class Initialized
INFO - 2022-11-30 09:51:51 --> Helper loaded: url_helper
INFO - 2022-11-30 09:51:51 --> Database Driver Class Initialized
INFO - 2022-11-30 09:51:51 --> Helper loaded: form_helper
INFO - 2022-11-30 09:51:51 --> Form Validation Class Initialized
INFO - 2022-11-30 09:51:51 --> Controller Class Initialized
INFO - 2022-11-30 09:51:51 --> Model "Buku_model" initialized
ERROR - 2022-11-30 09:51:51 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 09:52:32 --> Config Class Initialized
INFO - 2022-11-30 09:52:32 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:52:32 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:52:32 --> Utf8 Class Initialized
INFO - 2022-11-30 09:52:32 --> URI Class Initialized
INFO - 2022-11-30 09:52:32 --> Router Class Initialized
INFO - 2022-11-30 09:52:32 --> Output Class Initialized
INFO - 2022-11-30 09:52:32 --> Security Class Initialized
DEBUG - 2022-11-30 09:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:52:32 --> Input Class Initialized
INFO - 2022-11-30 09:52:32 --> Language Class Initialized
INFO - 2022-11-30 09:52:32 --> Loader Class Initialized
INFO - 2022-11-30 09:52:32 --> Helper loaded: url_helper
INFO - 2022-11-30 09:52:32 --> Database Driver Class Initialized
INFO - 2022-11-30 09:52:32 --> Helper loaded: form_helper
INFO - 2022-11-30 09:52:32 --> Form Validation Class Initialized
INFO - 2022-11-30 09:52:32 --> Controller Class Initialized
INFO - 2022-11-30 09:52:32 --> Model "Buku_model" initialized
ERROR - 2022-11-30 09:52:32 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 09:53:50 --> Config Class Initialized
INFO - 2022-11-30 09:53:50 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:53:50 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:53:50 --> Utf8 Class Initialized
INFO - 2022-11-30 09:53:50 --> URI Class Initialized
INFO - 2022-11-30 09:53:50 --> Router Class Initialized
INFO - 2022-11-30 09:53:50 --> Output Class Initialized
INFO - 2022-11-30 09:53:50 --> Security Class Initialized
DEBUG - 2022-11-30 09:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:53:50 --> Input Class Initialized
INFO - 2022-11-30 09:53:50 --> Language Class Initialized
INFO - 2022-11-30 09:53:50 --> Loader Class Initialized
INFO - 2022-11-30 09:53:50 --> Helper loaded: url_helper
INFO - 2022-11-30 09:53:50 --> Database Driver Class Initialized
INFO - 2022-11-30 09:53:50 --> Helper loaded: form_helper
INFO - 2022-11-30 09:53:50 --> Form Validation Class Initialized
INFO - 2022-11-30 09:53:50 --> Controller Class Initialized
INFO - 2022-11-30 09:53:50 --> Model "Buku_model" initialized
ERROR - 2022-11-30 09:53:50 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 09:54:16 --> Config Class Initialized
INFO - 2022-11-30 09:54:16 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:54:16 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:54:16 --> Utf8 Class Initialized
INFO - 2022-11-30 09:54:16 --> URI Class Initialized
INFO - 2022-11-30 09:54:16 --> Router Class Initialized
INFO - 2022-11-30 09:54:16 --> Output Class Initialized
INFO - 2022-11-30 09:54:16 --> Security Class Initialized
DEBUG - 2022-11-30 09:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:54:16 --> Input Class Initialized
INFO - 2022-11-30 09:54:16 --> Language Class Initialized
INFO - 2022-11-30 09:54:16 --> Loader Class Initialized
INFO - 2022-11-30 09:54:16 --> Helper loaded: url_helper
INFO - 2022-11-30 09:54:16 --> Database Driver Class Initialized
INFO - 2022-11-30 09:54:16 --> Helper loaded: form_helper
INFO - 2022-11-30 09:54:16 --> Form Validation Class Initialized
INFO - 2022-11-30 09:54:16 --> Controller Class Initialized
INFO - 2022-11-30 09:54:16 --> Model "Buku_model" initialized
ERROR - 2022-11-30 09:54:16 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 09:54:17 --> Config Class Initialized
INFO - 2022-11-30 09:54:17 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:54:17 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:54:17 --> Utf8 Class Initialized
INFO - 2022-11-30 09:54:17 --> URI Class Initialized
INFO - 2022-11-30 09:54:17 --> Router Class Initialized
INFO - 2022-11-30 09:54:17 --> Output Class Initialized
INFO - 2022-11-30 09:54:17 --> Security Class Initialized
DEBUG - 2022-11-30 09:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:54:17 --> Input Class Initialized
INFO - 2022-11-30 09:54:17 --> Language Class Initialized
INFO - 2022-11-30 09:54:17 --> Loader Class Initialized
INFO - 2022-11-30 09:54:17 --> Helper loaded: url_helper
INFO - 2022-11-30 09:54:17 --> Database Driver Class Initialized
INFO - 2022-11-30 09:54:17 --> Helper loaded: form_helper
INFO - 2022-11-30 09:54:17 --> Form Validation Class Initialized
INFO - 2022-11-30 09:54:17 --> Controller Class Initialized
INFO - 2022-11-30 09:54:17 --> Model "Buku_model" initialized
ERROR - 2022-11-30 09:54:17 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 09:57:55 --> Config Class Initialized
INFO - 2022-11-30 09:57:55 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:57:55 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:57:55 --> Utf8 Class Initialized
INFO - 2022-11-30 09:57:55 --> URI Class Initialized
INFO - 2022-11-30 09:57:55 --> Router Class Initialized
INFO - 2022-11-30 09:57:55 --> Output Class Initialized
INFO - 2022-11-30 09:57:55 --> Security Class Initialized
DEBUG - 2022-11-30 09:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:57:55 --> Input Class Initialized
INFO - 2022-11-30 09:57:55 --> Language Class Initialized
INFO - 2022-11-30 09:57:55 --> Loader Class Initialized
INFO - 2022-11-30 09:57:55 --> Helper loaded: url_helper
INFO - 2022-11-30 09:57:55 --> Database Driver Class Initialized
INFO - 2022-11-30 09:57:55 --> Helper loaded: form_helper
INFO - 2022-11-30 09:57:55 --> Form Validation Class Initialized
INFO - 2022-11-30 09:57:55 --> Controller Class Initialized
INFO - 2022-11-30 09:57:55 --> Model "Buku_model" initialized
INFO - 2022-11-30 09:57:55 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 09:57:55 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 09:57:55 --> Final output sent to browser
DEBUG - 2022-11-30 09:57:55 --> Total execution time: 0.0688
INFO - 2022-11-30 09:58:10 --> Config Class Initialized
INFO - 2022-11-30 09:58:10 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:58:10 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:58:10 --> Utf8 Class Initialized
INFO - 2022-11-30 09:58:10 --> URI Class Initialized
INFO - 2022-11-30 09:58:10 --> Router Class Initialized
INFO - 2022-11-30 09:58:10 --> Output Class Initialized
INFO - 2022-11-30 09:58:10 --> Security Class Initialized
DEBUG - 2022-11-30 09:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:58:10 --> Input Class Initialized
INFO - 2022-11-30 09:58:10 --> Language Class Initialized
INFO - 2022-11-30 09:58:10 --> Loader Class Initialized
INFO - 2022-11-30 09:58:10 --> Helper loaded: url_helper
INFO - 2022-11-30 09:58:10 --> Database Driver Class Initialized
INFO - 2022-11-30 09:58:10 --> Helper loaded: form_helper
INFO - 2022-11-30 09:58:10 --> Form Validation Class Initialized
INFO - 2022-11-30 09:58:10 --> Controller Class Initialized
INFO - 2022-11-30 09:58:10 --> Model "Buku_model" initialized
ERROR - 2022-11-30 09:58:10 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 09:59:25 --> Config Class Initialized
INFO - 2022-11-30 09:59:25 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:59:25 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:59:25 --> Utf8 Class Initialized
INFO - 2022-11-30 09:59:25 --> URI Class Initialized
INFO - 2022-11-30 09:59:25 --> Router Class Initialized
INFO - 2022-11-30 09:59:25 --> Output Class Initialized
INFO - 2022-11-30 09:59:25 --> Security Class Initialized
DEBUG - 2022-11-30 09:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:59:25 --> Input Class Initialized
INFO - 2022-11-30 09:59:25 --> Language Class Initialized
INFO - 2022-11-30 09:59:25 --> Loader Class Initialized
INFO - 2022-11-30 09:59:25 --> Helper loaded: url_helper
INFO - 2022-11-30 09:59:25 --> Database Driver Class Initialized
INFO - 2022-11-30 09:59:25 --> Helper loaded: form_helper
INFO - 2022-11-30 09:59:25 --> Form Validation Class Initialized
INFO - 2022-11-30 09:59:25 --> Controller Class Initialized
INFO - 2022-11-30 09:59:25 --> Model "Buku_model" initialized
ERROR - 2022-11-30 09:59:25 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 09:59:25 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 09:59:25 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 09:59:25 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
INFO - 2022-11-30 09:59:25 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 09:59:25 --> Final output sent to browser
DEBUG - 2022-11-30 09:59:25 --> Total execution time: 0.0814
INFO - 2022-11-30 09:59:51 --> Config Class Initialized
INFO - 2022-11-30 09:59:51 --> Hooks Class Initialized
DEBUG - 2022-11-30 09:59:51 --> UTF-8 Support Enabled
INFO - 2022-11-30 09:59:51 --> Utf8 Class Initialized
INFO - 2022-11-30 09:59:51 --> URI Class Initialized
INFO - 2022-11-30 09:59:51 --> Router Class Initialized
INFO - 2022-11-30 09:59:51 --> Output Class Initialized
INFO - 2022-11-30 09:59:51 --> Security Class Initialized
DEBUG - 2022-11-30 09:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 09:59:51 --> Input Class Initialized
INFO - 2022-11-30 09:59:51 --> Language Class Initialized
INFO - 2022-11-30 09:59:51 --> Loader Class Initialized
INFO - 2022-11-30 09:59:51 --> Helper loaded: url_helper
INFO - 2022-11-30 09:59:51 --> Database Driver Class Initialized
INFO - 2022-11-30 09:59:51 --> Helper loaded: form_helper
INFO - 2022-11-30 09:59:51 --> Form Validation Class Initialized
INFO - 2022-11-30 09:59:51 --> Controller Class Initialized
INFO - 2022-11-30 09:59:51 --> Model "Buku_model" initialized
ERROR - 2022-11-30 09:59:51 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 10:00:00 --> Config Class Initialized
INFO - 2022-11-30 10:00:00 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:00:00 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:00:00 --> Utf8 Class Initialized
INFO - 2022-11-30 10:00:00 --> URI Class Initialized
INFO - 2022-11-30 10:00:00 --> Router Class Initialized
INFO - 2022-11-30 10:00:00 --> Output Class Initialized
INFO - 2022-11-30 10:00:00 --> Security Class Initialized
DEBUG - 2022-11-30 10:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:00:00 --> Input Class Initialized
INFO - 2022-11-30 10:00:00 --> Language Class Initialized
INFO - 2022-11-30 10:00:00 --> Loader Class Initialized
INFO - 2022-11-30 10:00:00 --> Helper loaded: url_helper
INFO - 2022-11-30 10:00:00 --> Database Driver Class Initialized
INFO - 2022-11-30 10:00:00 --> Helper loaded: form_helper
INFO - 2022-11-30 10:00:00 --> Form Validation Class Initialized
INFO - 2022-11-30 10:00:00 --> Controller Class Initialized
INFO - 2022-11-30 10:00:00 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:00:00 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:00:00 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:00:00 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:00:00 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
INFO - 2022-11-30 10:00:00 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:00:00 --> Final output sent to browser
DEBUG - 2022-11-30 10:00:00 --> Total execution time: 0.1632
INFO - 2022-11-30 10:00:00 --> Config Class Initialized
INFO - 2022-11-30 10:00:00 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:00:00 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:00:00 --> Utf8 Class Initialized
INFO - 2022-11-30 10:00:00 --> URI Class Initialized
INFO - 2022-11-30 10:00:00 --> Router Class Initialized
INFO - 2022-11-30 10:00:01 --> Output Class Initialized
INFO - 2022-11-30 10:00:01 --> Security Class Initialized
DEBUG - 2022-11-30 10:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:00:01 --> Input Class Initialized
INFO - 2022-11-30 10:00:01 --> Language Class Initialized
INFO - 2022-11-30 10:00:01 --> Loader Class Initialized
INFO - 2022-11-30 10:00:01 --> Helper loaded: url_helper
INFO - 2022-11-30 10:00:01 --> Database Driver Class Initialized
INFO - 2022-11-30 10:00:01 --> Helper loaded: form_helper
INFO - 2022-11-30 10:00:01 --> Form Validation Class Initialized
INFO - 2022-11-30 10:00:01 --> Controller Class Initialized
INFO - 2022-11-30 10:00:01 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:00:01 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:00:01 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:00:01 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:00:01 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
INFO - 2022-11-30 10:00:01 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:00:01 --> Final output sent to browser
DEBUG - 2022-11-30 10:00:01 --> Total execution time: 0.1427
INFO - 2022-11-30 10:01:27 --> Config Class Initialized
INFO - 2022-11-30 10:01:27 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:01:27 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:01:27 --> Utf8 Class Initialized
INFO - 2022-11-30 10:01:27 --> URI Class Initialized
INFO - 2022-11-30 10:01:27 --> Router Class Initialized
INFO - 2022-11-30 10:01:27 --> Output Class Initialized
INFO - 2022-11-30 10:01:27 --> Security Class Initialized
DEBUG - 2022-11-30 10:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:01:27 --> Input Class Initialized
INFO - 2022-11-30 10:01:27 --> Language Class Initialized
INFO - 2022-11-30 10:01:27 --> Loader Class Initialized
INFO - 2022-11-30 10:01:27 --> Helper loaded: url_helper
INFO - 2022-11-30 10:01:27 --> Database Driver Class Initialized
INFO - 2022-11-30 10:01:27 --> Helper loaded: form_helper
INFO - 2022-11-30 10:01:27 --> Form Validation Class Initialized
INFO - 2022-11-30 10:01:27 --> Controller Class Initialized
INFO - 2022-11-30 10:01:27 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:01:27 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:27 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:27 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:27 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:27 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:27 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:27 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:27 --> Severity: Warning --> Undefined array key "nama_penerbit" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
INFO - 2022-11-30 10:01:27 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:01:27 --> Final output sent to browser
DEBUG - 2022-11-30 10:01:27 --> Total execution time: 0.0587
INFO - 2022-11-30 10:01:40 --> Config Class Initialized
INFO - 2022-11-30 10:01:40 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:01:40 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:01:40 --> Utf8 Class Initialized
INFO - 2022-11-30 10:01:40 --> URI Class Initialized
INFO - 2022-11-30 10:01:40 --> Router Class Initialized
INFO - 2022-11-30 10:01:40 --> Output Class Initialized
INFO - 2022-11-30 10:01:40 --> Security Class Initialized
DEBUG - 2022-11-30 10:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:01:40 --> Input Class Initialized
INFO - 2022-11-30 10:01:40 --> Language Class Initialized
INFO - 2022-11-30 10:01:40 --> Loader Class Initialized
INFO - 2022-11-30 10:01:40 --> Helper loaded: url_helper
INFO - 2022-11-30 10:01:40 --> Database Driver Class Initialized
INFO - 2022-11-30 10:01:40 --> Helper loaded: form_helper
INFO - 2022-11-30 10:01:40 --> Form Validation Class Initialized
INFO - 2022-11-30 10:01:40 --> Controller Class Initialized
INFO - 2022-11-30 10:01:40 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:01:40 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:40 --> Severity: Warning --> Undefined array key "nama" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:40 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:40 --> Severity: Warning --> Undefined array key "nama" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:40 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:40 --> Severity: Warning --> Undefined array key "nama" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:40 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:40 --> Severity: Warning --> Undefined array key "nama" C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
INFO - 2022-11-30 10:01:40 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:01:40 --> Final output sent to browser
DEBUG - 2022-11-30 10:01:40 --> Total execution time: 0.0742
INFO - 2022-11-30 10:01:55 --> Config Class Initialized
INFO - 2022-11-30 10:01:55 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:01:55 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:01:55 --> Utf8 Class Initialized
INFO - 2022-11-30 10:01:55 --> URI Class Initialized
INFO - 2022-11-30 10:01:55 --> Router Class Initialized
INFO - 2022-11-30 10:01:55 --> Output Class Initialized
INFO - 2022-11-30 10:01:55 --> Security Class Initialized
DEBUG - 2022-11-30 10:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:01:55 --> Input Class Initialized
INFO - 2022-11-30 10:01:55 --> Language Class Initialized
INFO - 2022-11-30 10:01:55 --> Loader Class Initialized
INFO - 2022-11-30 10:01:55 --> Helper loaded: url_helper
INFO - 2022-11-30 10:01:55 --> Database Driver Class Initialized
INFO - 2022-11-30 10:01:55 --> Helper loaded: form_helper
INFO - 2022-11-30 10:01:55 --> Form Validation Class Initialized
INFO - 2022-11-30 10:01:55 --> Controller Class Initialized
INFO - 2022-11-30 10:01:55 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:01:55 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:55 --> Severity: Warning --> Undefined variable $NamaPenerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:55 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:55 --> Severity: Warning --> Undefined variable $NamaPenerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:55 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:55 --> Severity: Warning --> Undefined variable $NamaPenerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:55 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:55 --> Severity: Warning --> Undefined variable $NamaPenerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
INFO - 2022-11-30 10:01:55 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:01:55 --> Final output sent to browser
DEBUG - 2022-11-30 10:01:55 --> Total execution time: 0.0696
INFO - 2022-11-30 10:01:56 --> Config Class Initialized
INFO - 2022-11-30 10:01:56 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:01:56 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:01:56 --> Utf8 Class Initialized
INFO - 2022-11-30 10:01:56 --> URI Class Initialized
INFO - 2022-11-30 10:01:56 --> Router Class Initialized
INFO - 2022-11-30 10:01:56 --> Output Class Initialized
INFO - 2022-11-30 10:01:56 --> Security Class Initialized
DEBUG - 2022-11-30 10:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:01:56 --> Input Class Initialized
INFO - 2022-11-30 10:01:56 --> Language Class Initialized
INFO - 2022-11-30 10:01:56 --> Loader Class Initialized
INFO - 2022-11-30 10:01:56 --> Helper loaded: url_helper
INFO - 2022-11-30 10:01:56 --> Database Driver Class Initialized
INFO - 2022-11-30 10:01:56 --> Helper loaded: form_helper
INFO - 2022-11-30 10:01:56 --> Form Validation Class Initialized
INFO - 2022-11-30 10:01:56 --> Controller Class Initialized
INFO - 2022-11-30 10:01:56 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $NamaPenerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $NamaPenerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $NamaPenerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $NamaPenerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
INFO - 2022-11-30 10:01:56 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:01:56 --> Final output sent to browser
DEBUG - 2022-11-30 10:01:56 --> Total execution time: 0.0788
INFO - 2022-11-30 10:01:56 --> Config Class Initialized
INFO - 2022-11-30 10:01:56 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:01:56 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:01:56 --> Utf8 Class Initialized
INFO - 2022-11-30 10:01:56 --> URI Class Initialized
INFO - 2022-11-30 10:01:56 --> Router Class Initialized
INFO - 2022-11-30 10:01:56 --> Output Class Initialized
INFO - 2022-11-30 10:01:56 --> Security Class Initialized
DEBUG - 2022-11-30 10:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:01:56 --> Input Class Initialized
INFO - 2022-11-30 10:01:56 --> Language Class Initialized
INFO - 2022-11-30 10:01:56 --> Loader Class Initialized
INFO - 2022-11-30 10:01:56 --> Helper loaded: url_helper
INFO - 2022-11-30 10:01:56 --> Database Driver Class Initialized
INFO - 2022-11-30 10:01:56 --> Helper loaded: form_helper
INFO - 2022-11-30 10:01:56 --> Form Validation Class Initialized
INFO - 2022-11-30 10:01:56 --> Controller Class Initialized
INFO - 2022-11-30 10:01:56 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $NamaPenerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $NamaPenerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $NamaPenerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $id_penerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 21
ERROR - 2022-11-30 10:01:56 --> Severity: Warning --> Undefined variable $NamaPenerbit C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 45
INFO - 2022-11-30 10:01:56 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:01:56 --> Final output sent to browser
DEBUG - 2022-11-30 10:01:56 --> Total execution time: 0.0705
INFO - 2022-11-30 10:02:53 --> Config Class Initialized
INFO - 2022-11-30 10:02:53 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:02:53 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:02:53 --> Utf8 Class Initialized
INFO - 2022-11-30 10:02:53 --> URI Class Initialized
INFO - 2022-11-30 10:02:53 --> Router Class Initialized
INFO - 2022-11-30 10:02:53 --> Output Class Initialized
INFO - 2022-11-30 10:02:53 --> Security Class Initialized
DEBUG - 2022-11-30 10:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:02:53 --> Input Class Initialized
INFO - 2022-11-30 10:02:53 --> Language Class Initialized
INFO - 2022-11-30 10:02:53 --> Loader Class Initialized
INFO - 2022-11-30 10:02:53 --> Helper loaded: url_helper
INFO - 2022-11-30 10:02:53 --> Database Driver Class Initialized
INFO - 2022-11-30 10:02:53 --> Helper loaded: form_helper
INFO - 2022-11-30 10:02:53 --> Form Validation Class Initialized
INFO - 2022-11-30 10:02:53 --> Controller Class Initialized
INFO - 2022-11-30 10:02:53 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:02:53 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:02:53 --> Final output sent to browser
DEBUG - 2022-11-30 10:02:53 --> Total execution time: 0.0565
INFO - 2022-11-30 10:04:02 --> Config Class Initialized
INFO - 2022-11-30 10:04:02 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:04:02 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:04:02 --> Utf8 Class Initialized
INFO - 2022-11-30 10:04:02 --> URI Class Initialized
INFO - 2022-11-30 10:04:02 --> Router Class Initialized
INFO - 2022-11-30 10:04:02 --> Output Class Initialized
INFO - 2022-11-30 10:04:02 --> Security Class Initialized
DEBUG - 2022-11-30 10:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:04:02 --> Input Class Initialized
INFO - 2022-11-30 10:04:02 --> Language Class Initialized
INFO - 2022-11-30 10:04:02 --> Loader Class Initialized
INFO - 2022-11-30 10:04:02 --> Helper loaded: url_helper
INFO - 2022-11-30 10:04:02 --> Database Driver Class Initialized
INFO - 2022-11-30 10:04:02 --> Helper loaded: form_helper
INFO - 2022-11-30 10:04:02 --> Form Validation Class Initialized
INFO - 2022-11-30 10:04:02 --> Controller Class Initialized
INFO - 2022-11-30 10:04:02 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:04:02 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 10:04:14 --> Config Class Initialized
INFO - 2022-11-30 10:04:14 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:04:15 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:04:15 --> Utf8 Class Initialized
INFO - 2022-11-30 10:04:15 --> URI Class Initialized
INFO - 2022-11-30 10:04:15 --> Router Class Initialized
INFO - 2022-11-30 10:04:15 --> Output Class Initialized
INFO - 2022-11-30 10:04:15 --> Security Class Initialized
DEBUG - 2022-11-30 10:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:04:15 --> Input Class Initialized
INFO - 2022-11-30 10:04:15 --> Language Class Initialized
INFO - 2022-11-30 10:04:15 --> Loader Class Initialized
INFO - 2022-11-30 10:04:15 --> Helper loaded: url_helper
INFO - 2022-11-30 10:04:15 --> Database Driver Class Initialized
INFO - 2022-11-30 10:04:15 --> Helper loaded: form_helper
INFO - 2022-11-30 10:04:15 --> Form Validation Class Initialized
INFO - 2022-11-30 10:04:15 --> Controller Class Initialized
INFO - 2022-11-30 10:04:15 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:04:15 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:04:15 --> Final output sent to browser
DEBUG - 2022-11-30 10:04:15 --> Total execution time: 0.0706
INFO - 2022-11-30 10:04:21 --> Config Class Initialized
INFO - 2022-11-30 10:04:21 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:04:21 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:04:21 --> Utf8 Class Initialized
INFO - 2022-11-30 10:04:21 --> URI Class Initialized
INFO - 2022-11-30 10:04:21 --> Router Class Initialized
INFO - 2022-11-30 10:04:21 --> Output Class Initialized
INFO - 2022-11-30 10:04:21 --> Security Class Initialized
DEBUG - 2022-11-30 10:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:04:21 --> Input Class Initialized
INFO - 2022-11-30 10:04:21 --> Language Class Initialized
INFO - 2022-11-30 10:04:21 --> Loader Class Initialized
INFO - 2022-11-30 10:04:21 --> Helper loaded: url_helper
INFO - 2022-11-30 10:04:21 --> Database Driver Class Initialized
INFO - 2022-11-30 10:04:21 --> Helper loaded: form_helper
INFO - 2022-11-30 10:04:21 --> Form Validation Class Initialized
INFO - 2022-11-30 10:04:21 --> Controller Class Initialized
INFO - 2022-11-30 10:04:21 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:04:21 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 10:04:21 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 10:04:21 --> Final output sent to browser
DEBUG - 2022-11-30 10:04:21 --> Total execution time: 0.0440
INFO - 2022-11-30 10:04:28 --> Config Class Initialized
INFO - 2022-11-30 10:04:28 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:04:28 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:04:28 --> Utf8 Class Initialized
INFO - 2022-11-30 10:04:28 --> URI Class Initialized
INFO - 2022-11-30 10:04:28 --> Router Class Initialized
INFO - 2022-11-30 10:04:28 --> Output Class Initialized
INFO - 2022-11-30 10:04:28 --> Security Class Initialized
DEBUG - 2022-11-30 10:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:04:28 --> Input Class Initialized
INFO - 2022-11-30 10:04:28 --> Language Class Initialized
INFO - 2022-11-30 10:04:28 --> Loader Class Initialized
INFO - 2022-11-30 10:04:28 --> Helper loaded: url_helper
INFO - 2022-11-30 10:04:28 --> Database Driver Class Initialized
INFO - 2022-11-30 10:04:28 --> Helper loaded: form_helper
INFO - 2022-11-30 10:04:28 --> Form Validation Class Initialized
INFO - 2022-11-30 10:04:28 --> Controller Class Initialized
INFO - 2022-11-30 10:04:28 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:04:28 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 10:04:28 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-30 10:04:28 --> Final output sent to browser
DEBUG - 2022-11-30 10:04:28 --> Total execution time: 0.0628
INFO - 2022-11-30 10:04:30 --> Config Class Initialized
INFO - 2022-11-30 10:04:30 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:04:30 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:04:30 --> Utf8 Class Initialized
INFO - 2022-11-30 10:04:30 --> URI Class Initialized
INFO - 2022-11-30 10:04:30 --> Router Class Initialized
INFO - 2022-11-30 10:04:30 --> Output Class Initialized
INFO - 2022-11-30 10:04:30 --> Security Class Initialized
DEBUG - 2022-11-30 10:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:04:30 --> Input Class Initialized
INFO - 2022-11-30 10:04:30 --> Language Class Initialized
INFO - 2022-11-30 10:04:30 --> Loader Class Initialized
INFO - 2022-11-30 10:04:30 --> Helper loaded: url_helper
INFO - 2022-11-30 10:04:30 --> Database Driver Class Initialized
INFO - 2022-11-30 10:04:30 --> Helper loaded: form_helper
INFO - 2022-11-30 10:04:30 --> Form Validation Class Initialized
INFO - 2022-11-30 10:04:30 --> Controller Class Initialized
INFO - 2022-11-30 10:04:30 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:04:30 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 10:04:30 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 10:04:30 --> Final output sent to browser
DEBUG - 2022-11-30 10:04:30 --> Total execution time: 0.0649
INFO - 2022-11-30 10:04:47 --> Config Class Initialized
INFO - 2022-11-30 10:04:47 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:04:47 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:04:47 --> Utf8 Class Initialized
INFO - 2022-11-30 10:04:47 --> URI Class Initialized
INFO - 2022-11-30 10:04:47 --> Router Class Initialized
INFO - 2022-11-30 10:04:47 --> Output Class Initialized
INFO - 2022-11-30 10:04:47 --> Security Class Initialized
DEBUG - 2022-11-30 10:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:04:47 --> Input Class Initialized
INFO - 2022-11-30 10:04:47 --> Language Class Initialized
INFO - 2022-11-30 10:04:47 --> Loader Class Initialized
INFO - 2022-11-30 10:04:47 --> Helper loaded: url_helper
INFO - 2022-11-30 10:04:47 --> Database Driver Class Initialized
INFO - 2022-11-30 10:04:47 --> Helper loaded: form_helper
INFO - 2022-11-30 10:04:47 --> Form Validation Class Initialized
INFO - 2022-11-30 10:04:47 --> Controller Class Initialized
INFO - 2022-11-30 10:04:47 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:04:47 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 10:04:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-11-30 10:04:47 --> Config Class Initialized
INFO - 2022-11-30 10:04:47 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:04:47 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:04:47 --> Utf8 Class Initialized
INFO - 2022-11-30 10:04:47 --> URI Class Initialized
INFO - 2022-11-30 10:04:47 --> Router Class Initialized
INFO - 2022-11-30 10:04:47 --> Output Class Initialized
INFO - 2022-11-30 10:04:47 --> Security Class Initialized
DEBUG - 2022-11-30 10:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:04:47 --> Input Class Initialized
INFO - 2022-11-30 10:04:47 --> Language Class Initialized
INFO - 2022-11-30 10:04:47 --> Loader Class Initialized
INFO - 2022-11-30 10:04:47 --> Helper loaded: url_helper
INFO - 2022-11-30 10:04:47 --> Database Driver Class Initialized
INFO - 2022-11-30 10:04:47 --> Helper loaded: form_helper
INFO - 2022-11-30 10:04:47 --> Form Validation Class Initialized
INFO - 2022-11-30 10:04:47 --> Controller Class Initialized
INFO - 2022-11-30 10:04:47 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:04:47 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 10:04:47 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 10:04:47 --> Final output sent to browser
DEBUG - 2022-11-30 10:04:47 --> Total execution time: 0.0529
INFO - 2022-11-30 10:04:51 --> Config Class Initialized
INFO - 2022-11-30 10:04:51 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:04:51 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:04:51 --> Utf8 Class Initialized
INFO - 2022-11-30 10:04:51 --> URI Class Initialized
INFO - 2022-11-30 10:04:51 --> Router Class Initialized
INFO - 2022-11-30 10:04:51 --> Output Class Initialized
INFO - 2022-11-30 10:04:51 --> Security Class Initialized
DEBUG - 2022-11-30 10:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:04:51 --> Input Class Initialized
INFO - 2022-11-30 10:04:51 --> Language Class Initialized
INFO - 2022-11-30 10:04:51 --> Loader Class Initialized
INFO - 2022-11-30 10:04:51 --> Helper loaded: url_helper
INFO - 2022-11-30 10:04:51 --> Database Driver Class Initialized
INFO - 2022-11-30 10:04:51 --> Helper loaded: form_helper
INFO - 2022-11-30 10:04:51 --> Form Validation Class Initialized
INFO - 2022-11-30 10:04:51 --> Controller Class Initialized
INFO - 2022-11-30 10:04:51 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:04:51 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:04:51 --> Final output sent to browser
DEBUG - 2022-11-30 10:04:51 --> Total execution time: 0.0521
INFO - 2022-11-30 10:09:13 --> Config Class Initialized
INFO - 2022-11-30 10:09:13 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:09:13 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:09:13 --> Utf8 Class Initialized
INFO - 2022-11-30 10:09:13 --> URI Class Initialized
INFO - 2022-11-30 10:09:13 --> Router Class Initialized
INFO - 2022-11-30 10:09:13 --> Output Class Initialized
INFO - 2022-11-30 10:09:13 --> Security Class Initialized
DEBUG - 2022-11-30 10:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:09:13 --> Input Class Initialized
INFO - 2022-11-30 10:09:13 --> Language Class Initialized
INFO - 2022-11-30 10:09:13 --> Loader Class Initialized
INFO - 2022-11-30 10:09:13 --> Helper loaded: url_helper
INFO - 2022-11-30 10:09:13 --> Database Driver Class Initialized
INFO - 2022-11-30 10:09:13 --> Helper loaded: form_helper
INFO - 2022-11-30 10:09:13 --> Form Validation Class Initialized
INFO - 2022-11-30 10:09:13 --> Controller Class Initialized
INFO - 2022-11-30 10:09:13 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:09:41 --> Config Class Initialized
INFO - 2022-11-30 10:09:41 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:09:41 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:09:41 --> Utf8 Class Initialized
INFO - 2022-11-30 10:09:41 --> URI Class Initialized
INFO - 2022-11-30 10:09:41 --> Router Class Initialized
INFO - 2022-11-30 10:09:41 --> Output Class Initialized
INFO - 2022-11-30 10:09:41 --> Security Class Initialized
DEBUG - 2022-11-30 10:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:09:41 --> Input Class Initialized
INFO - 2022-11-30 10:09:41 --> Language Class Initialized
INFO - 2022-11-30 10:09:41 --> Loader Class Initialized
INFO - 2022-11-30 10:09:41 --> Helper loaded: url_helper
INFO - 2022-11-30 10:09:41 --> Database Driver Class Initialized
INFO - 2022-11-30 10:09:41 --> Helper loaded: form_helper
INFO - 2022-11-30 10:09:41 --> Form Validation Class Initialized
INFO - 2022-11-30 10:09:41 --> Controller Class Initialized
INFO - 2022-11-30 10:09:41 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:09:41 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:09:41 --> Final output sent to browser
DEBUG - 2022-11-30 10:09:41 --> Total execution time: 0.0712
INFO - 2022-11-30 10:09:43 --> Config Class Initialized
INFO - 2022-11-30 10:09:43 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:09:43 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:09:43 --> Utf8 Class Initialized
INFO - 2022-11-30 10:09:43 --> URI Class Initialized
INFO - 2022-11-30 10:09:43 --> Router Class Initialized
INFO - 2022-11-30 10:09:43 --> Output Class Initialized
INFO - 2022-11-30 10:09:43 --> Security Class Initialized
DEBUG - 2022-11-30 10:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:09:43 --> Input Class Initialized
INFO - 2022-11-30 10:09:43 --> Language Class Initialized
INFO - 2022-11-30 10:09:43 --> Loader Class Initialized
INFO - 2022-11-30 10:09:43 --> Helper loaded: url_helper
INFO - 2022-11-30 10:09:43 --> Database Driver Class Initialized
INFO - 2022-11-30 10:09:43 --> Helper loaded: form_helper
INFO - 2022-11-30 10:09:43 --> Form Validation Class Initialized
INFO - 2022-11-30 10:09:43 --> Controller Class Initialized
INFO - 2022-11-30 10:09:43 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:09:43 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:09:43 --> Final output sent to browser
DEBUG - 2022-11-30 10:09:43 --> Total execution time: 0.1062
INFO - 2022-11-30 10:09:56 --> Config Class Initialized
INFO - 2022-11-30 10:09:56 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:09:56 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:09:56 --> Utf8 Class Initialized
INFO - 2022-11-30 10:09:56 --> URI Class Initialized
INFO - 2022-11-30 10:09:56 --> Router Class Initialized
INFO - 2022-11-30 10:09:56 --> Output Class Initialized
INFO - 2022-11-30 10:09:56 --> Security Class Initialized
DEBUG - 2022-11-30 10:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:09:56 --> Input Class Initialized
INFO - 2022-11-30 10:09:56 --> Language Class Initialized
INFO - 2022-11-30 10:09:56 --> Loader Class Initialized
INFO - 2022-11-30 10:09:56 --> Helper loaded: url_helper
INFO - 2022-11-30 10:09:56 --> Database Driver Class Initialized
INFO - 2022-11-30 10:09:56 --> Helper loaded: form_helper
INFO - 2022-11-30 10:09:56 --> Form Validation Class Initialized
INFO - 2022-11-30 10:09:56 --> Controller Class Initialized
INFO - 2022-11-30 10:09:56 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:09:56 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:09:56 --> Final output sent to browser
DEBUG - 2022-11-30 10:09:56 --> Total execution time: 0.0757
INFO - 2022-11-30 10:09:57 --> Config Class Initialized
INFO - 2022-11-30 10:09:57 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:09:57 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:09:57 --> Utf8 Class Initialized
INFO - 2022-11-30 10:09:57 --> URI Class Initialized
INFO - 2022-11-30 10:09:57 --> Router Class Initialized
INFO - 2022-11-30 10:09:57 --> Output Class Initialized
INFO - 2022-11-30 10:09:57 --> Security Class Initialized
DEBUG - 2022-11-30 10:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:09:57 --> Input Class Initialized
INFO - 2022-11-30 10:09:57 --> Language Class Initialized
INFO - 2022-11-30 10:09:57 --> Loader Class Initialized
INFO - 2022-11-30 10:09:57 --> Helper loaded: url_helper
INFO - 2022-11-30 10:09:57 --> Database Driver Class Initialized
INFO - 2022-11-30 10:09:57 --> Helper loaded: form_helper
INFO - 2022-11-30 10:09:57 --> Form Validation Class Initialized
INFO - 2022-11-30 10:09:57 --> Controller Class Initialized
INFO - 2022-11-30 10:09:57 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:09:57 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:09:57 --> Final output sent to browser
DEBUG - 2022-11-30 10:09:57 --> Total execution time: 0.0678
INFO - 2022-11-30 10:10:26 --> Config Class Initialized
INFO - 2022-11-30 10:10:26 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:10:26 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:10:26 --> Utf8 Class Initialized
INFO - 2022-11-30 10:10:26 --> URI Class Initialized
INFO - 2022-11-30 10:10:26 --> Router Class Initialized
INFO - 2022-11-30 10:10:26 --> Output Class Initialized
INFO - 2022-11-30 10:10:26 --> Security Class Initialized
DEBUG - 2022-11-30 10:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:10:26 --> Input Class Initialized
INFO - 2022-11-30 10:10:26 --> Language Class Initialized
INFO - 2022-11-30 10:10:26 --> Loader Class Initialized
INFO - 2022-11-30 10:10:26 --> Helper loaded: url_helper
INFO - 2022-11-30 10:10:26 --> Database Driver Class Initialized
INFO - 2022-11-30 10:10:26 --> Helper loaded: form_helper
INFO - 2022-11-30 10:10:26 --> Form Validation Class Initialized
INFO - 2022-11-30 10:10:26 --> Controller Class Initialized
INFO - 2022-11-30 10:10:26 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:10:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:10:26 --> Final output sent to browser
DEBUG - 2022-11-30 10:10:26 --> Total execution time: 0.0844
INFO - 2022-11-30 10:10:26 --> Config Class Initialized
INFO - 2022-11-30 10:10:26 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:10:26 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:10:26 --> Utf8 Class Initialized
INFO - 2022-11-30 10:10:26 --> URI Class Initialized
INFO - 2022-11-30 10:10:26 --> Router Class Initialized
INFO - 2022-11-30 10:10:26 --> Output Class Initialized
INFO - 2022-11-30 10:10:26 --> Security Class Initialized
DEBUG - 2022-11-30 10:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:10:26 --> Input Class Initialized
INFO - 2022-11-30 10:10:26 --> Language Class Initialized
INFO - 2022-11-30 10:10:26 --> Loader Class Initialized
INFO - 2022-11-30 10:10:26 --> Helper loaded: url_helper
INFO - 2022-11-30 10:10:26 --> Database Driver Class Initialized
INFO - 2022-11-30 10:10:26 --> Helper loaded: form_helper
INFO - 2022-11-30 10:10:26 --> Form Validation Class Initialized
INFO - 2022-11-30 10:10:26 --> Controller Class Initialized
INFO - 2022-11-30 10:10:26 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:10:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:10:26 --> Final output sent to browser
DEBUG - 2022-11-30 10:10:26 --> Total execution time: 0.0751
INFO - 2022-11-30 10:10:27 --> Config Class Initialized
INFO - 2022-11-30 10:10:27 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:10:27 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:10:27 --> Utf8 Class Initialized
INFO - 2022-11-30 10:10:27 --> URI Class Initialized
INFO - 2022-11-30 10:10:27 --> Router Class Initialized
INFO - 2022-11-30 10:10:27 --> Output Class Initialized
INFO - 2022-11-30 10:10:27 --> Security Class Initialized
DEBUG - 2022-11-30 10:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:10:27 --> Input Class Initialized
INFO - 2022-11-30 10:10:27 --> Language Class Initialized
INFO - 2022-11-30 10:10:27 --> Loader Class Initialized
INFO - 2022-11-30 10:10:27 --> Helper loaded: url_helper
INFO - 2022-11-30 10:10:27 --> Database Driver Class Initialized
INFO - 2022-11-30 10:10:27 --> Helper loaded: form_helper
INFO - 2022-11-30 10:10:27 --> Form Validation Class Initialized
INFO - 2022-11-30 10:10:27 --> Controller Class Initialized
INFO - 2022-11-30 10:10:27 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:10:27 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:10:27 --> Final output sent to browser
DEBUG - 2022-11-30 10:10:27 --> Total execution time: 0.0543
INFO - 2022-11-30 10:10:56 --> Config Class Initialized
INFO - 2022-11-30 10:10:56 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:10:56 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:10:56 --> Utf8 Class Initialized
INFO - 2022-11-30 10:10:56 --> URI Class Initialized
INFO - 2022-11-30 10:10:56 --> Router Class Initialized
INFO - 2022-11-30 10:10:56 --> Output Class Initialized
INFO - 2022-11-30 10:10:56 --> Security Class Initialized
DEBUG - 2022-11-30 10:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:10:56 --> Input Class Initialized
INFO - 2022-11-30 10:10:56 --> Language Class Initialized
INFO - 2022-11-30 10:10:56 --> Loader Class Initialized
INFO - 2022-11-30 10:10:56 --> Helper loaded: url_helper
INFO - 2022-11-30 10:10:56 --> Database Driver Class Initialized
INFO - 2022-11-30 10:10:56 --> Helper loaded: form_helper
INFO - 2022-11-30 10:10:56 --> Form Validation Class Initialized
INFO - 2022-11-30 10:10:56 --> Controller Class Initialized
INFO - 2022-11-30 10:10:56 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:10:56 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:10:56 --> Final output sent to browser
DEBUG - 2022-11-30 10:10:56 --> Total execution time: 0.0613
INFO - 2022-11-30 10:10:56 --> Config Class Initialized
INFO - 2022-11-30 10:10:56 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:10:56 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:10:56 --> Utf8 Class Initialized
INFO - 2022-11-30 10:10:56 --> URI Class Initialized
INFO - 2022-11-30 10:10:56 --> Router Class Initialized
INFO - 2022-11-30 10:10:56 --> Output Class Initialized
INFO - 2022-11-30 10:10:56 --> Security Class Initialized
DEBUG - 2022-11-30 10:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:10:56 --> Input Class Initialized
INFO - 2022-11-30 10:10:56 --> Language Class Initialized
INFO - 2022-11-30 10:10:56 --> Loader Class Initialized
INFO - 2022-11-30 10:10:56 --> Helper loaded: url_helper
INFO - 2022-11-30 10:10:56 --> Database Driver Class Initialized
INFO - 2022-11-30 10:10:56 --> Helper loaded: form_helper
INFO - 2022-11-30 10:10:56 --> Form Validation Class Initialized
INFO - 2022-11-30 10:10:56 --> Controller Class Initialized
INFO - 2022-11-30 10:10:56 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:10:56 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:10:56 --> Final output sent to browser
DEBUG - 2022-11-30 10:10:56 --> Total execution time: 0.0507
INFO - 2022-11-30 10:10:56 --> Config Class Initialized
INFO - 2022-11-30 10:10:56 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:10:56 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:10:56 --> Utf8 Class Initialized
INFO - 2022-11-30 10:10:56 --> URI Class Initialized
INFO - 2022-11-30 10:10:56 --> Router Class Initialized
INFO - 2022-11-30 10:10:56 --> Output Class Initialized
INFO - 2022-11-30 10:10:56 --> Security Class Initialized
DEBUG - 2022-11-30 10:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:10:56 --> Input Class Initialized
INFO - 2022-11-30 10:10:56 --> Language Class Initialized
INFO - 2022-11-30 10:10:56 --> Loader Class Initialized
INFO - 2022-11-30 10:10:56 --> Helper loaded: url_helper
INFO - 2022-11-30 10:10:56 --> Database Driver Class Initialized
INFO - 2022-11-30 10:10:56 --> Helper loaded: form_helper
INFO - 2022-11-30 10:10:56 --> Form Validation Class Initialized
INFO - 2022-11-30 10:10:56 --> Controller Class Initialized
INFO - 2022-11-30 10:10:56 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:10:56 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:10:56 --> Final output sent to browser
DEBUG - 2022-11-30 10:10:56 --> Total execution time: 0.0511
INFO - 2022-11-30 10:11:01 --> Config Class Initialized
INFO - 2022-11-30 10:11:01 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:11:01 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:11:01 --> Utf8 Class Initialized
INFO - 2022-11-30 10:11:01 --> URI Class Initialized
INFO - 2022-11-30 10:11:01 --> Router Class Initialized
INFO - 2022-11-30 10:11:01 --> Output Class Initialized
INFO - 2022-11-30 10:11:01 --> Security Class Initialized
DEBUG - 2022-11-30 10:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:11:01 --> Input Class Initialized
INFO - 2022-11-30 10:11:01 --> Language Class Initialized
INFO - 2022-11-30 10:11:01 --> Loader Class Initialized
INFO - 2022-11-30 10:11:01 --> Helper loaded: url_helper
INFO - 2022-11-30 10:11:01 --> Database Driver Class Initialized
INFO - 2022-11-30 10:11:01 --> Helper loaded: form_helper
INFO - 2022-11-30 10:11:01 --> Form Validation Class Initialized
INFO - 2022-11-30 10:11:01 --> Controller Class Initialized
INFO - 2022-11-30 10:11:01 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:11:01 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:11:01 --> Final output sent to browser
DEBUG - 2022-11-30 10:11:01 --> Total execution time: 0.0583
INFO - 2022-11-30 10:11:06 --> Config Class Initialized
INFO - 2022-11-30 10:11:06 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:11:06 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:11:06 --> Utf8 Class Initialized
INFO - 2022-11-30 10:11:06 --> URI Class Initialized
INFO - 2022-11-30 10:11:06 --> Router Class Initialized
INFO - 2022-11-30 10:11:06 --> Output Class Initialized
INFO - 2022-11-30 10:11:06 --> Security Class Initialized
DEBUG - 2022-11-30 10:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:11:06 --> Input Class Initialized
INFO - 2022-11-30 10:11:06 --> Language Class Initialized
INFO - 2022-11-30 10:11:06 --> Loader Class Initialized
INFO - 2022-11-30 10:11:06 --> Helper loaded: url_helper
INFO - 2022-11-30 10:11:06 --> Database Driver Class Initialized
INFO - 2022-11-30 10:11:06 --> Helper loaded: form_helper
INFO - 2022-11-30 10:11:06 --> Form Validation Class Initialized
INFO - 2022-11-30 10:11:06 --> Controller Class Initialized
INFO - 2022-11-30 10:11:06 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:11:06 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:11:06 --> Final output sent to browser
DEBUG - 2022-11-30 10:11:06 --> Total execution time: 0.0739
INFO - 2022-11-30 10:11:06 --> Config Class Initialized
INFO - 2022-11-30 10:11:06 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:11:06 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:11:06 --> Utf8 Class Initialized
INFO - 2022-11-30 10:11:06 --> URI Class Initialized
INFO - 2022-11-30 10:11:06 --> Router Class Initialized
INFO - 2022-11-30 10:11:06 --> Output Class Initialized
INFO - 2022-11-30 10:11:06 --> Security Class Initialized
DEBUG - 2022-11-30 10:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:11:06 --> Input Class Initialized
INFO - 2022-11-30 10:11:06 --> Language Class Initialized
INFO - 2022-11-30 10:11:06 --> Loader Class Initialized
INFO - 2022-11-30 10:11:06 --> Helper loaded: url_helper
INFO - 2022-11-30 10:11:06 --> Database Driver Class Initialized
INFO - 2022-11-30 10:11:06 --> Helper loaded: form_helper
INFO - 2022-11-30 10:11:06 --> Form Validation Class Initialized
INFO - 2022-11-30 10:11:06 --> Controller Class Initialized
INFO - 2022-11-30 10:11:06 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:11:06 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:11:06 --> Final output sent to browser
DEBUG - 2022-11-30 10:11:06 --> Total execution time: 0.0752
INFO - 2022-11-30 10:11:06 --> Config Class Initialized
INFO - 2022-11-30 10:11:06 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:11:06 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:11:06 --> Utf8 Class Initialized
INFO - 2022-11-30 10:11:06 --> URI Class Initialized
INFO - 2022-11-30 10:11:06 --> Router Class Initialized
INFO - 2022-11-30 10:11:06 --> Output Class Initialized
INFO - 2022-11-30 10:11:06 --> Security Class Initialized
DEBUG - 2022-11-30 10:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:11:06 --> Input Class Initialized
INFO - 2022-11-30 10:11:06 --> Language Class Initialized
INFO - 2022-11-30 10:11:06 --> Loader Class Initialized
INFO - 2022-11-30 10:11:06 --> Helper loaded: url_helper
INFO - 2022-11-30 10:11:06 --> Database Driver Class Initialized
INFO - 2022-11-30 10:11:06 --> Helper loaded: form_helper
INFO - 2022-11-30 10:11:06 --> Form Validation Class Initialized
INFO - 2022-11-30 10:11:06 --> Controller Class Initialized
INFO - 2022-11-30 10:11:06 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:11:06 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:11:06 --> Final output sent to browser
DEBUG - 2022-11-30 10:11:06 --> Total execution time: 0.0745
INFO - 2022-11-30 10:11:12 --> Config Class Initialized
INFO - 2022-11-30 10:11:12 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:11:12 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:11:12 --> Utf8 Class Initialized
INFO - 2022-11-30 10:11:12 --> URI Class Initialized
INFO - 2022-11-30 10:11:12 --> Router Class Initialized
INFO - 2022-11-30 10:11:12 --> Output Class Initialized
INFO - 2022-11-30 10:11:12 --> Security Class Initialized
DEBUG - 2022-11-30 10:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:11:12 --> Input Class Initialized
INFO - 2022-11-30 10:11:12 --> Language Class Initialized
INFO - 2022-11-30 10:11:12 --> Loader Class Initialized
INFO - 2022-11-30 10:11:12 --> Helper loaded: url_helper
INFO - 2022-11-30 10:11:12 --> Database Driver Class Initialized
INFO - 2022-11-30 10:11:12 --> Helper loaded: form_helper
INFO - 2022-11-30 10:11:12 --> Form Validation Class Initialized
INFO - 2022-11-30 10:11:12 --> Controller Class Initialized
INFO - 2022-11-30 10:11:12 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:11:12 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:11:12 --> Final output sent to browser
DEBUG - 2022-11-30 10:11:12 --> Total execution time: 0.0604
INFO - 2022-11-30 10:11:12 --> Config Class Initialized
INFO - 2022-11-30 10:11:12 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:11:12 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:11:12 --> Utf8 Class Initialized
INFO - 2022-11-30 10:11:12 --> URI Class Initialized
INFO - 2022-11-30 10:11:12 --> Router Class Initialized
INFO - 2022-11-30 10:11:12 --> Output Class Initialized
INFO - 2022-11-30 10:11:12 --> Security Class Initialized
DEBUG - 2022-11-30 10:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:11:12 --> Input Class Initialized
INFO - 2022-11-30 10:11:12 --> Language Class Initialized
INFO - 2022-11-30 10:11:12 --> Loader Class Initialized
INFO - 2022-11-30 10:11:12 --> Helper loaded: url_helper
INFO - 2022-11-30 10:11:12 --> Database Driver Class Initialized
INFO - 2022-11-30 10:11:12 --> Helper loaded: form_helper
INFO - 2022-11-30 10:11:12 --> Form Validation Class Initialized
INFO - 2022-11-30 10:11:12 --> Controller Class Initialized
INFO - 2022-11-30 10:11:12 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:11:12 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:11:12 --> Final output sent to browser
DEBUG - 2022-11-30 10:11:12 --> Total execution time: 0.0608
INFO - 2022-11-30 10:11:12 --> Config Class Initialized
INFO - 2022-11-30 10:11:12 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:11:12 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:11:12 --> Utf8 Class Initialized
INFO - 2022-11-30 10:11:12 --> URI Class Initialized
INFO - 2022-11-30 10:11:12 --> Router Class Initialized
INFO - 2022-11-30 10:11:12 --> Output Class Initialized
INFO - 2022-11-30 10:11:12 --> Security Class Initialized
DEBUG - 2022-11-30 10:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:11:12 --> Input Class Initialized
INFO - 2022-11-30 10:11:12 --> Language Class Initialized
INFO - 2022-11-30 10:11:12 --> Loader Class Initialized
INFO - 2022-11-30 10:11:12 --> Helper loaded: url_helper
INFO - 2022-11-30 10:11:13 --> Database Driver Class Initialized
INFO - 2022-11-30 10:11:13 --> Helper loaded: form_helper
INFO - 2022-11-30 10:11:13 --> Form Validation Class Initialized
INFO - 2022-11-30 10:11:13 --> Controller Class Initialized
INFO - 2022-11-30 10:11:13 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:11:13 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:11:13 --> Final output sent to browser
DEBUG - 2022-11-30 10:11:13 --> Total execution time: 0.0614
INFO - 2022-11-30 10:11:13 --> Config Class Initialized
INFO - 2022-11-30 10:11:13 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:11:13 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:11:13 --> Utf8 Class Initialized
INFO - 2022-11-30 10:11:13 --> URI Class Initialized
INFO - 2022-11-30 10:11:13 --> Router Class Initialized
INFO - 2022-11-30 10:11:13 --> Output Class Initialized
INFO - 2022-11-30 10:11:13 --> Security Class Initialized
DEBUG - 2022-11-30 10:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:11:13 --> Input Class Initialized
INFO - 2022-11-30 10:11:13 --> Language Class Initialized
INFO - 2022-11-30 10:11:13 --> Loader Class Initialized
INFO - 2022-11-30 10:11:13 --> Helper loaded: url_helper
INFO - 2022-11-30 10:11:13 --> Database Driver Class Initialized
INFO - 2022-11-30 10:11:13 --> Helper loaded: form_helper
INFO - 2022-11-30 10:11:13 --> Form Validation Class Initialized
INFO - 2022-11-30 10:11:13 --> Controller Class Initialized
INFO - 2022-11-30 10:11:13 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:11:13 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:11:13 --> Final output sent to browser
DEBUG - 2022-11-30 10:11:13 --> Total execution time: 0.0634
INFO - 2022-11-30 10:11:13 --> Config Class Initialized
INFO - 2022-11-30 10:11:13 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:11:13 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:11:13 --> Utf8 Class Initialized
INFO - 2022-11-30 10:11:13 --> URI Class Initialized
INFO - 2022-11-30 10:11:13 --> Router Class Initialized
INFO - 2022-11-30 10:11:13 --> Output Class Initialized
INFO - 2022-11-30 10:11:13 --> Security Class Initialized
DEBUG - 2022-11-30 10:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:11:13 --> Input Class Initialized
INFO - 2022-11-30 10:11:13 --> Language Class Initialized
INFO - 2022-11-30 10:11:13 --> Loader Class Initialized
INFO - 2022-11-30 10:11:13 --> Helper loaded: url_helper
INFO - 2022-11-30 10:11:13 --> Database Driver Class Initialized
INFO - 2022-11-30 10:11:13 --> Helper loaded: form_helper
INFO - 2022-11-30 10:11:13 --> Form Validation Class Initialized
INFO - 2022-11-30 10:11:13 --> Controller Class Initialized
INFO - 2022-11-30 10:11:13 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:11:13 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:11:13 --> Final output sent to browser
DEBUG - 2022-11-30 10:11:13 --> Total execution time: 0.0575
INFO - 2022-11-30 10:11:18 --> Config Class Initialized
INFO - 2022-11-30 10:11:18 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:11:18 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:11:18 --> Utf8 Class Initialized
INFO - 2022-11-30 10:11:18 --> URI Class Initialized
INFO - 2022-11-30 10:11:18 --> Router Class Initialized
INFO - 2022-11-30 10:11:18 --> Output Class Initialized
INFO - 2022-11-30 10:11:18 --> Security Class Initialized
DEBUG - 2022-11-30 10:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:11:18 --> Input Class Initialized
INFO - 2022-11-30 10:11:18 --> Language Class Initialized
INFO - 2022-11-30 10:11:18 --> Loader Class Initialized
INFO - 2022-11-30 10:11:18 --> Helper loaded: url_helper
INFO - 2022-11-30 10:11:18 --> Database Driver Class Initialized
INFO - 2022-11-30 10:11:18 --> Helper loaded: form_helper
INFO - 2022-11-30 10:11:18 --> Form Validation Class Initialized
INFO - 2022-11-30 10:11:18 --> Controller Class Initialized
INFO - 2022-11-30 10:11:18 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:11:18 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:11:18 --> Final output sent to browser
DEBUG - 2022-11-30 10:11:18 --> Total execution time: 0.0555
INFO - 2022-11-30 10:11:22 --> Config Class Initialized
INFO - 2022-11-30 10:11:22 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:11:22 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:11:22 --> Utf8 Class Initialized
INFO - 2022-11-30 10:11:22 --> URI Class Initialized
INFO - 2022-11-30 10:11:22 --> Router Class Initialized
INFO - 2022-11-30 10:11:22 --> Output Class Initialized
INFO - 2022-11-30 10:11:22 --> Security Class Initialized
DEBUG - 2022-11-30 10:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:11:22 --> Input Class Initialized
INFO - 2022-11-30 10:11:22 --> Language Class Initialized
INFO - 2022-11-30 10:11:22 --> Loader Class Initialized
INFO - 2022-11-30 10:11:22 --> Helper loaded: url_helper
INFO - 2022-11-30 10:11:22 --> Database Driver Class Initialized
INFO - 2022-11-30 10:11:22 --> Helper loaded: form_helper
INFO - 2022-11-30 10:11:22 --> Form Validation Class Initialized
INFO - 2022-11-30 10:11:22 --> Controller Class Initialized
INFO - 2022-11-30 10:11:22 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:11:22 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:11:22 --> Final output sent to browser
DEBUG - 2022-11-30 10:11:22 --> Total execution time: 0.0501
INFO - 2022-11-30 10:11:26 --> Config Class Initialized
INFO - 2022-11-30 10:11:26 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:11:26 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:11:26 --> Utf8 Class Initialized
INFO - 2022-11-30 10:11:26 --> URI Class Initialized
INFO - 2022-11-30 10:11:26 --> Router Class Initialized
INFO - 2022-11-30 10:11:26 --> Output Class Initialized
INFO - 2022-11-30 10:11:26 --> Security Class Initialized
DEBUG - 2022-11-30 10:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:11:26 --> Input Class Initialized
INFO - 2022-11-30 10:11:26 --> Language Class Initialized
INFO - 2022-11-30 10:11:26 --> Loader Class Initialized
INFO - 2022-11-30 10:11:26 --> Helper loaded: url_helper
INFO - 2022-11-30 10:11:26 --> Database Driver Class Initialized
INFO - 2022-11-30 10:11:26 --> Helper loaded: form_helper
INFO - 2022-11-30 10:11:26 --> Form Validation Class Initialized
INFO - 2022-11-30 10:11:26 --> Controller Class Initialized
INFO - 2022-11-30 10:11:26 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:11:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\detail.php
INFO - 2022-11-30 10:11:26 --> Final output sent to browser
DEBUG - 2022-11-30 10:11:26 --> Total execution time: 0.0487
INFO - 2022-11-30 10:19:57 --> Config Class Initialized
INFO - 2022-11-30 10:19:57 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:19:57 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:19:57 --> Utf8 Class Initialized
INFO - 2022-11-30 10:19:57 --> URI Class Initialized
INFO - 2022-11-30 10:19:57 --> Router Class Initialized
INFO - 2022-11-30 10:19:57 --> Output Class Initialized
INFO - 2022-11-30 10:19:57 --> Security Class Initialized
DEBUG - 2022-11-30 10:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:19:57 --> Input Class Initialized
INFO - 2022-11-30 10:19:57 --> Language Class Initialized
INFO - 2022-11-30 10:19:57 --> Loader Class Initialized
INFO - 2022-11-30 10:19:57 --> Helper loaded: url_helper
INFO - 2022-11-30 10:19:57 --> Database Driver Class Initialized
INFO - 2022-11-30 10:19:57 --> Helper loaded: form_helper
INFO - 2022-11-30 10:19:57 --> Form Validation Class Initialized
INFO - 2022-11-30 10:19:57 --> Controller Class Initialized
INFO - 2022-11-30 10:19:57 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:19:57 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 10:19:57 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 10:19:57 --> Final output sent to browser
DEBUG - 2022-11-30 10:19:57 --> Total execution time: 0.1395
INFO - 2022-11-30 10:20:17 --> Config Class Initialized
INFO - 2022-11-30 10:20:17 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:20:17 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:20:17 --> Utf8 Class Initialized
INFO - 2022-11-30 10:20:17 --> URI Class Initialized
INFO - 2022-11-30 10:20:17 --> Router Class Initialized
INFO - 2022-11-30 10:20:17 --> Output Class Initialized
INFO - 2022-11-30 10:20:17 --> Security Class Initialized
DEBUG - 2022-11-30 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:20:17 --> Input Class Initialized
INFO - 2022-11-30 10:20:17 --> Language Class Initialized
INFO - 2022-11-30 10:20:17 --> Loader Class Initialized
INFO - 2022-11-30 10:20:17 --> Helper loaded: url_helper
INFO - 2022-11-30 10:20:17 --> Database Driver Class Initialized
INFO - 2022-11-30 10:20:17 --> Helper loaded: form_helper
INFO - 2022-11-30 10:20:17 --> Form Validation Class Initialized
INFO - 2022-11-30 10:20:17 --> Controller Class Initialized
INFO - 2022-11-30 10:20:17 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:20:17 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 10:20:17 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 10:20:17 --> Final output sent to browser
DEBUG - 2022-11-30 10:20:17 --> Total execution time: 0.0697
INFO - 2022-11-30 10:20:22 --> Config Class Initialized
INFO - 2022-11-30 10:20:22 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:20:22 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:20:22 --> Utf8 Class Initialized
INFO - 2022-11-30 10:20:22 --> URI Class Initialized
INFO - 2022-11-30 10:20:22 --> Router Class Initialized
INFO - 2022-11-30 10:20:22 --> Output Class Initialized
INFO - 2022-11-30 10:20:22 --> Security Class Initialized
DEBUG - 2022-11-30 10:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:20:22 --> Input Class Initialized
INFO - 2022-11-30 10:20:22 --> Language Class Initialized
INFO - 2022-11-30 10:20:22 --> Loader Class Initialized
INFO - 2022-11-30 10:20:22 --> Helper loaded: url_helper
INFO - 2022-11-30 10:20:22 --> Database Driver Class Initialized
INFO - 2022-11-30 10:20:22 --> Helper loaded: form_helper
INFO - 2022-11-30 10:20:22 --> Form Validation Class Initialized
INFO - 2022-11-30 10:20:22 --> Controller Class Initialized
INFO - 2022-11-30 10:20:22 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:20:22 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 10:20:22 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-30 10:20:22 --> Final output sent to browser
DEBUG - 2022-11-30 10:20:22 --> Total execution time: 0.0865
INFO - 2022-11-30 10:20:26 --> Config Class Initialized
INFO - 2022-11-30 10:20:26 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:20:26 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:20:26 --> Utf8 Class Initialized
INFO - 2022-11-30 10:20:26 --> URI Class Initialized
INFO - 2022-11-30 10:20:26 --> Router Class Initialized
INFO - 2022-11-30 10:20:26 --> Output Class Initialized
INFO - 2022-11-30 10:20:26 --> Security Class Initialized
DEBUG - 2022-11-30 10:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:20:26 --> Input Class Initialized
INFO - 2022-11-30 10:20:26 --> Language Class Initialized
INFO - 2022-11-30 10:20:26 --> Loader Class Initialized
INFO - 2022-11-30 10:20:26 --> Helper loaded: url_helper
INFO - 2022-11-30 10:20:26 --> Database Driver Class Initialized
INFO - 2022-11-30 10:20:26 --> Helper loaded: form_helper
INFO - 2022-11-30 10:20:26 --> Form Validation Class Initialized
INFO - 2022-11-30 10:20:26 --> Controller Class Initialized
INFO - 2022-11-30 10:20:26 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:20:26 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 10:20:26 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-30 10:20:26 --> Final output sent to browser
DEBUG - 2022-11-30 10:20:26 --> Total execution time: 0.0949
INFO - 2022-11-30 10:20:43 --> Config Class Initialized
INFO - 2022-11-30 10:20:43 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:20:43 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:20:43 --> Utf8 Class Initialized
INFO - 2022-11-30 10:20:43 --> URI Class Initialized
INFO - 2022-11-30 10:20:43 --> Router Class Initialized
INFO - 2022-11-30 10:20:43 --> Output Class Initialized
INFO - 2022-11-30 10:20:43 --> Security Class Initialized
DEBUG - 2022-11-30 10:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:20:43 --> Input Class Initialized
INFO - 2022-11-30 10:20:43 --> Language Class Initialized
INFO - 2022-11-30 10:20:43 --> Loader Class Initialized
INFO - 2022-11-30 10:20:43 --> Helper loaded: url_helper
INFO - 2022-11-30 10:20:43 --> Database Driver Class Initialized
INFO - 2022-11-30 10:20:43 --> Helper loaded: form_helper
INFO - 2022-11-30 10:20:43 --> Form Validation Class Initialized
INFO - 2022-11-30 10:20:43 --> Controller Class Initialized
INFO - 2022-11-30 10:20:43 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:20:43 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:20:43 --> Final output sent to browser
DEBUG - 2022-11-30 10:20:43 --> Total execution time: 0.0831
INFO - 2022-11-30 10:21:49 --> Config Class Initialized
INFO - 2022-11-30 10:21:49 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:21:49 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:21:49 --> Utf8 Class Initialized
INFO - 2022-11-30 10:21:49 --> URI Class Initialized
INFO - 2022-11-30 10:21:49 --> Router Class Initialized
INFO - 2022-11-30 10:21:49 --> Output Class Initialized
INFO - 2022-11-30 10:21:49 --> Security Class Initialized
DEBUG - 2022-11-30 10:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:21:49 --> Input Class Initialized
INFO - 2022-11-30 10:21:49 --> Language Class Initialized
INFO - 2022-11-30 10:21:49 --> Loader Class Initialized
INFO - 2022-11-30 10:21:49 --> Helper loaded: url_helper
INFO - 2022-11-30 10:21:49 --> Database Driver Class Initialized
INFO - 2022-11-30 10:21:49 --> Helper loaded: form_helper
INFO - 2022-11-30 10:21:49 --> Form Validation Class Initialized
INFO - 2022-11-30 10:21:49 --> Controller Class Initialized
INFO - 2022-11-30 10:21:49 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:21:49 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 10:23:10 --> Config Class Initialized
INFO - 2022-11-30 10:23:10 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:23:10 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:23:10 --> Utf8 Class Initialized
INFO - 2022-11-30 10:23:10 --> URI Class Initialized
INFO - 2022-11-30 10:23:10 --> Router Class Initialized
INFO - 2022-11-30 10:23:10 --> Output Class Initialized
INFO - 2022-11-30 10:23:10 --> Security Class Initialized
DEBUG - 2022-11-30 10:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:23:10 --> Input Class Initialized
INFO - 2022-11-30 10:23:10 --> Language Class Initialized
INFO - 2022-11-30 10:23:10 --> Loader Class Initialized
INFO - 2022-11-30 10:23:10 --> Helper loaded: url_helper
INFO - 2022-11-30 10:23:10 --> Database Driver Class Initialized
INFO - 2022-11-30 10:23:10 --> Helper loaded: form_helper
INFO - 2022-11-30 10:23:10 --> Form Validation Class Initialized
INFO - 2022-11-30 10:23:10 --> Controller Class Initialized
INFO - 2022-11-30 10:23:10 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:23:10 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 10:23:10 --> Config Class Initialized
INFO - 2022-11-30 10:23:10 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:23:10 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:23:10 --> Utf8 Class Initialized
INFO - 2022-11-30 10:23:10 --> URI Class Initialized
INFO - 2022-11-30 10:23:10 --> Router Class Initialized
INFO - 2022-11-30 10:23:10 --> Output Class Initialized
INFO - 2022-11-30 10:23:10 --> Security Class Initialized
DEBUG - 2022-11-30 10:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:23:10 --> Input Class Initialized
INFO - 2022-11-30 10:23:10 --> Language Class Initialized
INFO - 2022-11-30 10:23:10 --> Loader Class Initialized
INFO - 2022-11-30 10:23:10 --> Helper loaded: url_helper
INFO - 2022-11-30 10:23:10 --> Database Driver Class Initialized
INFO - 2022-11-30 10:23:10 --> Helper loaded: form_helper
INFO - 2022-11-30 10:23:10 --> Form Validation Class Initialized
INFO - 2022-11-30 10:23:10 --> Controller Class Initialized
INFO - 2022-11-30 10:23:10 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:23:10 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 10:23:10 --> Config Class Initialized
INFO - 2022-11-30 10:23:10 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:23:10 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:23:10 --> Utf8 Class Initialized
INFO - 2022-11-30 10:23:10 --> URI Class Initialized
INFO - 2022-11-30 10:23:10 --> Router Class Initialized
INFO - 2022-11-30 10:23:10 --> Output Class Initialized
INFO - 2022-11-30 10:23:10 --> Security Class Initialized
DEBUG - 2022-11-30 10:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:23:10 --> Input Class Initialized
INFO - 2022-11-30 10:23:10 --> Language Class Initialized
INFO - 2022-11-30 10:23:10 --> Loader Class Initialized
INFO - 2022-11-30 10:23:10 --> Helper loaded: url_helper
INFO - 2022-11-30 10:23:10 --> Database Driver Class Initialized
INFO - 2022-11-30 10:23:10 --> Helper loaded: form_helper
INFO - 2022-11-30 10:23:10 --> Form Validation Class Initialized
INFO - 2022-11-30 10:23:10 --> Controller Class Initialized
INFO - 2022-11-30 10:23:10 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:23:10 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 10:23:46 --> Config Class Initialized
INFO - 2022-11-30 10:23:46 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:23:46 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:23:46 --> Utf8 Class Initialized
INFO - 2022-11-30 10:23:46 --> URI Class Initialized
INFO - 2022-11-30 10:23:46 --> Router Class Initialized
INFO - 2022-11-30 10:23:46 --> Output Class Initialized
INFO - 2022-11-30 10:23:46 --> Security Class Initialized
DEBUG - 2022-11-30 10:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:23:46 --> Input Class Initialized
INFO - 2022-11-30 10:23:46 --> Language Class Initialized
INFO - 2022-11-30 10:23:46 --> Loader Class Initialized
INFO - 2022-11-30 10:23:46 --> Helper loaded: url_helper
INFO - 2022-11-30 10:23:46 --> Database Driver Class Initialized
INFO - 2022-11-30 10:23:46 --> Helper loaded: form_helper
INFO - 2022-11-30 10:23:46 --> Form Validation Class Initialized
INFO - 2022-11-30 10:23:46 --> Controller Class Initialized
INFO - 2022-11-30 10:23:46 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:23:46 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 10:23:47 --> Config Class Initialized
INFO - 2022-11-30 10:23:47 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:23:47 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:23:47 --> Utf8 Class Initialized
INFO - 2022-11-30 10:23:47 --> URI Class Initialized
INFO - 2022-11-30 10:23:47 --> Router Class Initialized
INFO - 2022-11-30 10:23:47 --> Output Class Initialized
INFO - 2022-11-30 10:23:47 --> Security Class Initialized
DEBUG - 2022-11-30 10:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:23:47 --> Input Class Initialized
INFO - 2022-11-30 10:23:47 --> Language Class Initialized
INFO - 2022-11-30 10:23:47 --> Loader Class Initialized
INFO - 2022-11-30 10:23:47 --> Helper loaded: url_helper
INFO - 2022-11-30 10:23:47 --> Database Driver Class Initialized
INFO - 2022-11-30 10:23:47 --> Helper loaded: form_helper
INFO - 2022-11-30 10:23:47 --> Form Validation Class Initialized
INFO - 2022-11-30 10:23:47 --> Controller Class Initialized
INFO - 2022-11-30 10:23:47 --> Model "Buku_model" initialized
ERROR - 2022-11-30 10:23:47 --> Severity: error --> Exception: Call to undefined function word_limiter() C:\xampp\htdocs\ekatalog\application\views\welcome_message.php 34
INFO - 2022-11-30 10:23:54 --> Config Class Initialized
INFO - 2022-11-30 10:23:54 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:23:54 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:23:54 --> Utf8 Class Initialized
INFO - 2022-11-30 10:23:54 --> URI Class Initialized
INFO - 2022-11-30 10:23:54 --> Router Class Initialized
INFO - 2022-11-30 10:23:54 --> Output Class Initialized
INFO - 2022-11-30 10:23:54 --> Security Class Initialized
DEBUG - 2022-11-30 10:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:23:54 --> Input Class Initialized
INFO - 2022-11-30 10:23:54 --> Language Class Initialized
INFO - 2022-11-30 10:23:54 --> Loader Class Initialized
INFO - 2022-11-30 10:23:54 --> Helper loaded: url_helper
INFO - 2022-11-30 10:23:54 --> Database Driver Class Initialized
INFO - 2022-11-30 10:23:54 --> Helper loaded: form_helper
INFO - 2022-11-30 10:23:54 --> Form Validation Class Initialized
INFO - 2022-11-30 10:23:54 --> Controller Class Initialized
INFO - 2022-11-30 10:23:54 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:23:54 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:23:54 --> Final output sent to browser
DEBUG - 2022-11-30 10:23:54 --> Total execution time: 0.0661
INFO - 2022-11-30 10:24:43 --> Config Class Initialized
INFO - 2022-11-30 10:24:43 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:24:43 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:24:43 --> Utf8 Class Initialized
INFO - 2022-11-30 10:24:43 --> URI Class Initialized
INFO - 2022-11-30 10:24:43 --> Router Class Initialized
INFO - 2022-11-30 10:24:43 --> Output Class Initialized
INFO - 2022-11-30 10:24:43 --> Security Class Initialized
DEBUG - 2022-11-30 10:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:24:43 --> Input Class Initialized
INFO - 2022-11-30 10:24:43 --> Language Class Initialized
INFO - 2022-11-30 10:24:43 --> Loader Class Initialized
INFO - 2022-11-30 10:24:43 --> Helper loaded: url_helper
INFO - 2022-11-30 10:24:43 --> Database Driver Class Initialized
INFO - 2022-11-30 10:24:43 --> Helper loaded: form_helper
INFO - 2022-11-30 10:24:43 --> Form Validation Class Initialized
INFO - 2022-11-30 10:24:43 --> Controller Class Initialized
INFO - 2022-11-30 10:24:43 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:24:43 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:24:43 --> Final output sent to browser
DEBUG - 2022-11-30 10:24:43 --> Total execution time: 0.0468
INFO - 2022-11-30 10:24:51 --> Config Class Initialized
INFO - 2022-11-30 10:24:51 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:24:51 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:24:51 --> Utf8 Class Initialized
INFO - 2022-11-30 10:24:51 --> URI Class Initialized
INFO - 2022-11-30 10:24:51 --> Router Class Initialized
INFO - 2022-11-30 10:24:51 --> Output Class Initialized
INFO - 2022-11-30 10:24:51 --> Security Class Initialized
DEBUG - 2022-11-30 10:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:24:51 --> Input Class Initialized
INFO - 2022-11-30 10:24:51 --> Language Class Initialized
INFO - 2022-11-30 10:24:51 --> Loader Class Initialized
INFO - 2022-11-30 10:24:51 --> Helper loaded: url_helper
INFO - 2022-11-30 10:24:51 --> Database Driver Class Initialized
INFO - 2022-11-30 10:24:51 --> Helper loaded: form_helper
INFO - 2022-11-30 10:24:51 --> Form Validation Class Initialized
INFO - 2022-11-30 10:24:51 --> Controller Class Initialized
INFO - 2022-11-30 10:24:51 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:24:51 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:24:51 --> Final output sent to browser
DEBUG - 2022-11-30 10:24:51 --> Total execution time: 0.0614
INFO - 2022-11-30 10:26:09 --> Config Class Initialized
INFO - 2022-11-30 10:26:09 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:26:09 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:26:10 --> Utf8 Class Initialized
INFO - 2022-11-30 10:26:10 --> URI Class Initialized
INFO - 2022-11-30 10:26:10 --> Router Class Initialized
INFO - 2022-11-30 10:26:10 --> Output Class Initialized
INFO - 2022-11-30 10:26:10 --> Security Class Initialized
DEBUG - 2022-11-30 10:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:26:10 --> Input Class Initialized
INFO - 2022-11-30 10:26:10 --> Language Class Initialized
INFO - 2022-11-30 10:26:10 --> Loader Class Initialized
INFO - 2022-11-30 10:26:10 --> Helper loaded: url_helper
INFO - 2022-11-30 10:26:10 --> Helper loaded: text_helper
INFO - 2022-11-30 10:26:10 --> Database Driver Class Initialized
INFO - 2022-11-30 10:26:10 --> Helper loaded: form_helper
INFO - 2022-11-30 10:26:10 --> Form Validation Class Initialized
INFO - 2022-11-30 10:26:10 --> Controller Class Initialized
INFO - 2022-11-30 10:26:10 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:26:10 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:26:10 --> Final output sent to browser
DEBUG - 2022-11-30 10:26:10 --> Total execution time: 0.0647
INFO - 2022-11-30 10:26:32 --> Config Class Initialized
INFO - 2022-11-30 10:26:32 --> Hooks Class Initialized
DEBUG - 2022-11-30 10:26:32 --> UTF-8 Support Enabled
INFO - 2022-11-30 10:26:32 --> Utf8 Class Initialized
INFO - 2022-11-30 10:26:32 --> URI Class Initialized
INFO - 2022-11-30 10:26:32 --> Router Class Initialized
INFO - 2022-11-30 10:26:32 --> Output Class Initialized
INFO - 2022-11-30 10:26:32 --> Security Class Initialized
DEBUG - 2022-11-30 10:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 10:26:32 --> Input Class Initialized
INFO - 2022-11-30 10:26:32 --> Language Class Initialized
INFO - 2022-11-30 10:26:32 --> Loader Class Initialized
INFO - 2022-11-30 10:26:32 --> Helper loaded: url_helper
INFO - 2022-11-30 10:26:32 --> Helper loaded: text_helper
INFO - 2022-11-30 10:26:32 --> Database Driver Class Initialized
INFO - 2022-11-30 10:26:32 --> Helper loaded: form_helper
INFO - 2022-11-30 10:26:32 --> Form Validation Class Initialized
INFO - 2022-11-30 10:26:32 --> Controller Class Initialized
INFO - 2022-11-30 10:26:32 --> Model "Buku_model" initialized
INFO - 2022-11-30 10:26:32 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-30 10:26:32 --> Final output sent to browser
DEBUG - 2022-11-30 10:26:32 --> Total execution time: 0.0951
INFO - 2022-11-30 11:13:41 --> Config Class Initialized
INFO - 2022-11-30 11:13:41 --> Hooks Class Initialized
DEBUG - 2022-11-30 11:13:41 --> UTF-8 Support Enabled
INFO - 2022-11-30 11:13:41 --> Utf8 Class Initialized
INFO - 2022-11-30 11:13:41 --> URI Class Initialized
INFO - 2022-11-30 11:13:41 --> Router Class Initialized
INFO - 2022-11-30 11:13:41 --> Output Class Initialized
INFO - 2022-11-30 11:13:41 --> Security Class Initialized
DEBUG - 2022-11-30 11:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 11:13:41 --> Input Class Initialized
INFO - 2022-11-30 11:13:41 --> Language Class Initialized
INFO - 2022-11-30 11:13:41 --> Loader Class Initialized
INFO - 2022-11-30 11:13:41 --> Helper loaded: url_helper
INFO - 2022-11-30 11:13:41 --> Helper loaded: text_helper
INFO - 2022-11-30 11:13:41 --> Database Driver Class Initialized
INFO - 2022-11-30 11:13:41 --> Helper loaded: form_helper
INFO - 2022-11-30 11:13:41 --> Form Validation Class Initialized
INFO - 2022-11-30 11:13:41 --> Controller Class Initialized
INFO - 2022-11-30 11:13:41 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 11:13:41 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-30 11:13:41 --> Final output sent to browser
DEBUG - 2022-11-30 11:13:41 --> Total execution time: 0.0366
INFO - 2022-11-30 11:14:00 --> Config Class Initialized
INFO - 2022-11-30 11:14:00 --> Hooks Class Initialized
DEBUG - 2022-11-30 11:14:00 --> UTF-8 Support Enabled
INFO - 2022-11-30 11:14:00 --> Utf8 Class Initialized
INFO - 2022-11-30 11:14:00 --> URI Class Initialized
INFO - 2022-11-30 11:14:00 --> Router Class Initialized
INFO - 2022-11-30 11:14:00 --> Output Class Initialized
INFO - 2022-11-30 11:14:00 --> Security Class Initialized
DEBUG - 2022-11-30 11:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 11:14:00 --> Input Class Initialized
INFO - 2022-11-30 11:14:00 --> Language Class Initialized
INFO - 2022-11-30 11:14:00 --> Loader Class Initialized
INFO - 2022-11-30 11:14:00 --> Helper loaded: url_helper
INFO - 2022-11-30 11:14:00 --> Helper loaded: text_helper
INFO - 2022-11-30 11:14:00 --> Database Driver Class Initialized
INFO - 2022-11-30 11:14:00 --> Helper loaded: form_helper
INFO - 2022-11-30 11:14:00 --> Form Validation Class Initialized
INFO - 2022-11-30 11:14:00 --> Controller Class Initialized
INFO - 2022-11-30 11:14:00 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 11:14:00 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/detail.php
INFO - 2022-11-30 11:14:00 --> Final output sent to browser
DEBUG - 2022-11-30 11:14:00 --> Total execution time: 0.0373
INFO - 2022-11-30 11:14:19 --> Config Class Initialized
INFO - 2022-11-30 11:14:19 --> Hooks Class Initialized
DEBUG - 2022-11-30 11:14:19 --> UTF-8 Support Enabled
INFO - 2022-11-30 11:14:19 --> Utf8 Class Initialized
INFO - 2022-11-30 11:14:19 --> URI Class Initialized
INFO - 2022-11-30 11:14:19 --> Router Class Initialized
INFO - 2022-11-30 11:14:19 --> Output Class Initialized
INFO - 2022-11-30 11:14:19 --> Security Class Initialized
DEBUG - 2022-11-30 11:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 11:14:19 --> Input Class Initialized
INFO - 2022-11-30 11:14:19 --> Language Class Initialized
INFO - 2022-11-30 11:14:19 --> Loader Class Initialized
INFO - 2022-11-30 11:14:19 --> Helper loaded: url_helper
INFO - 2022-11-30 11:14:19 --> Helper loaded: text_helper
INFO - 2022-11-30 11:14:19 --> Database Driver Class Initialized
INFO - 2022-11-30 11:14:19 --> Helper loaded: form_helper
INFO - 2022-11-30 11:14:19 --> Form Validation Class Initialized
INFO - 2022-11-30 11:14:19 --> Controller Class Initialized
INFO - 2022-11-30 11:14:19 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 11:14:19 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-30 11:14:19 --> Final output sent to browser
DEBUG - 2022-11-30 11:14:19 --> Total execution time: 0.0332
INFO - 2022-11-30 11:15:46 --> Config Class Initialized
INFO - 2022-11-30 11:15:46 --> Hooks Class Initialized
DEBUG - 2022-11-30 11:15:46 --> UTF-8 Support Enabled
INFO - 2022-11-30 11:15:46 --> Utf8 Class Initialized
INFO - 2022-11-30 11:15:46 --> URI Class Initialized
INFO - 2022-11-30 11:15:46 --> Router Class Initialized
INFO - 2022-11-30 11:15:46 --> Output Class Initialized
INFO - 2022-11-30 11:15:46 --> Security Class Initialized
DEBUG - 2022-11-30 11:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 11:15:46 --> Input Class Initialized
INFO - 2022-11-30 11:15:46 --> Language Class Initialized
INFO - 2022-11-30 11:15:46 --> Loader Class Initialized
INFO - 2022-11-30 11:15:46 --> Helper loaded: url_helper
INFO - 2022-11-30 11:15:46 --> Helper loaded: text_helper
INFO - 2022-11-30 11:15:46 --> Database Driver Class Initialized
INFO - 2022-11-30 11:15:46 --> Helper loaded: form_helper
INFO - 2022-11-30 11:15:46 --> Form Validation Class Initialized
INFO - 2022-11-30 11:15:46 --> Controller Class Initialized
INFO - 2022-11-30 11:15:46 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 11:15:46 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\penerbit/form.php
INFO - 2022-11-30 11:15:46 --> Final output sent to browser
DEBUG - 2022-11-30 11:15:46 --> Total execution time: 0.0569
INFO - 2022-11-30 11:16:41 --> Config Class Initialized
INFO - 2022-11-30 11:16:41 --> Hooks Class Initialized
DEBUG - 2022-11-30 11:16:41 --> UTF-8 Support Enabled
INFO - 2022-11-30 11:16:41 --> Utf8 Class Initialized
INFO - 2022-11-30 11:16:41 --> URI Class Initialized
INFO - 2022-11-30 11:16:41 --> Router Class Initialized
INFO - 2022-11-30 11:16:41 --> Output Class Initialized
INFO - 2022-11-30 11:16:41 --> Security Class Initialized
DEBUG - 2022-11-30 11:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 11:16:41 --> Input Class Initialized
INFO - 2022-11-30 11:16:41 --> Language Class Initialized
INFO - 2022-11-30 11:16:41 --> Loader Class Initialized
INFO - 2022-11-30 11:16:41 --> Helper loaded: url_helper
INFO - 2022-11-30 11:16:41 --> Helper loaded: text_helper
INFO - 2022-11-30 11:16:41 --> Database Driver Class Initialized
INFO - 2022-11-30 11:16:41 --> Helper loaded: form_helper
INFO - 2022-11-30 11:16:41 --> Form Validation Class Initialized
INFO - 2022-11-30 11:16:41 --> Controller Class Initialized
INFO - 2022-11-30 11:16:41 --> Model "Buku_model" initialized
INFO - 2022-11-30 11:16:41 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 11:16:41 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/index.php
INFO - 2022-11-30 11:16:41 --> Final output sent to browser
DEBUG - 2022-11-30 11:16:41 --> Total execution time: 0.0442
INFO - 2022-11-30 11:16:53 --> Config Class Initialized
INFO - 2022-11-30 11:16:53 --> Hooks Class Initialized
DEBUG - 2022-11-30 11:16:53 --> UTF-8 Support Enabled
INFO - 2022-11-30 11:16:53 --> Utf8 Class Initialized
INFO - 2022-11-30 11:16:53 --> URI Class Initialized
INFO - 2022-11-30 11:16:53 --> Router Class Initialized
INFO - 2022-11-30 11:16:53 --> Output Class Initialized
INFO - 2022-11-30 11:16:53 --> Security Class Initialized
DEBUG - 2022-11-30 11:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 11:16:53 --> Input Class Initialized
INFO - 2022-11-30 11:16:53 --> Language Class Initialized
INFO - 2022-11-30 11:16:53 --> Loader Class Initialized
INFO - 2022-11-30 11:16:53 --> Helper loaded: url_helper
INFO - 2022-11-30 11:16:53 --> Helper loaded: text_helper
INFO - 2022-11-30 11:16:53 --> Database Driver Class Initialized
INFO - 2022-11-30 11:16:53 --> Helper loaded: form_helper
INFO - 2022-11-30 11:16:53 --> Form Validation Class Initialized
INFO - 2022-11-30 11:16:53 --> Controller Class Initialized
INFO - 2022-11-30 11:16:53 --> Model "Buku_model" initialized
INFO - 2022-11-30 11:16:53 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 11:16:53 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 11:16:53 --> Final output sent to browser
DEBUG - 2022-11-30 11:16:53 --> Total execution time: 0.0399
INFO - 2022-11-30 11:17:21 --> Config Class Initialized
INFO - 2022-11-30 11:17:21 --> Hooks Class Initialized
DEBUG - 2022-11-30 11:17:21 --> UTF-8 Support Enabled
INFO - 2022-11-30 11:17:21 --> Utf8 Class Initialized
INFO - 2022-11-30 11:17:21 --> URI Class Initialized
INFO - 2022-11-30 11:17:21 --> Router Class Initialized
INFO - 2022-11-30 11:17:21 --> Output Class Initialized
INFO - 2022-11-30 11:17:21 --> Security Class Initialized
DEBUG - 2022-11-30 11:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 11:17:21 --> Input Class Initialized
INFO - 2022-11-30 11:17:21 --> Language Class Initialized
INFO - 2022-11-30 11:17:21 --> Loader Class Initialized
INFO - 2022-11-30 11:17:21 --> Helper loaded: url_helper
INFO - 2022-11-30 11:17:21 --> Helper loaded: text_helper
INFO - 2022-11-30 11:17:21 --> Database Driver Class Initialized
INFO - 2022-11-30 11:17:21 --> Helper loaded: form_helper
INFO - 2022-11-30 11:17:21 --> Form Validation Class Initialized
INFO - 2022-11-30 11:17:21 --> Controller Class Initialized
INFO - 2022-11-30 11:17:21 --> Model "Buku_model" initialized
INFO - 2022-11-30 11:17:21 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 11:17:21 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/detail.php
INFO - 2022-11-30 11:17:21 --> Final output sent to browser
DEBUG - 2022-11-30 11:17:21 --> Total execution time: 0.0501
INFO - 2022-11-30 11:17:36 --> Config Class Initialized
INFO - 2022-11-30 11:17:36 --> Hooks Class Initialized
DEBUG - 2022-11-30 11:17:36 --> UTF-8 Support Enabled
INFO - 2022-11-30 11:17:36 --> Utf8 Class Initialized
INFO - 2022-11-30 11:17:36 --> URI Class Initialized
INFO - 2022-11-30 11:17:36 --> Router Class Initialized
INFO - 2022-11-30 11:17:36 --> Output Class Initialized
INFO - 2022-11-30 11:17:36 --> Security Class Initialized
DEBUG - 2022-11-30 11:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-30 11:17:36 --> Input Class Initialized
INFO - 2022-11-30 11:17:36 --> Language Class Initialized
INFO - 2022-11-30 11:17:36 --> Loader Class Initialized
INFO - 2022-11-30 11:17:36 --> Helper loaded: url_helper
INFO - 2022-11-30 11:17:36 --> Helper loaded: text_helper
INFO - 2022-11-30 11:17:36 --> Database Driver Class Initialized
INFO - 2022-11-30 11:17:36 --> Helper loaded: form_helper
INFO - 2022-11-30 11:17:36 --> Form Validation Class Initialized
INFO - 2022-11-30 11:17:36 --> Controller Class Initialized
INFO - 2022-11-30 11:17:36 --> Model "Buku_model" initialized
INFO - 2022-11-30 11:17:36 --> Model "Penerbit_model" initialized
INFO - 2022-11-30 11:17:36 --> File loaded: C:\xampp\htdocs\ekatalog\application\views\buku/form.php
INFO - 2022-11-30 11:17:36 --> Final output sent to browser
DEBUG - 2022-11-30 11:17:36 --> Total execution time: 0.0375
