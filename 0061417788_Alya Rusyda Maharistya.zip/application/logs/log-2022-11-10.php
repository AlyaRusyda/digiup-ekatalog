<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-11-10 03:33:07 --> Config Class Initialized
INFO - 2022-11-10 03:33:07 --> Hooks Class Initialized
DEBUG - 2022-11-10 03:33:07 --> UTF-8 Support Enabled
INFO - 2022-11-10 03:33:07 --> Utf8 Class Initialized
INFO - 2022-11-10 03:33:07 --> URI Class Initialized
DEBUG - 2022-11-10 03:33:07 --> No URI present. Default controller set.
INFO - 2022-11-10 03:33:07 --> Router Class Initialized
INFO - 2022-11-10 03:33:07 --> Output Class Initialized
INFO - 2022-11-10 03:33:07 --> Security Class Initialized
DEBUG - 2022-11-10 03:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 03:33:07 --> Input Class Initialized
INFO - 2022-11-10 03:33:07 --> Language Class Initialized
INFO - 2022-11-10 03:33:07 --> Loader Class Initialized
INFO - 2022-11-10 03:33:07 --> Helper loaded: url_helper
INFO - 2022-11-10 03:33:07 --> Database Driver Class Initialized
INFO - 2022-11-10 03:33:07 --> Helper loaded: form_helper
INFO - 2022-11-10 03:33:07 --> Form Validation Class Initialized
DEBUG - 2022-11-10 03:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 03:33:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 03:33:07 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 03:33:07 --> Email Class Initialized
INFO - 2022-11-10 03:33:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 03:33:07 --> Helper loaded: cookie_helper
INFO - 2022-11-10 03:33:07 --> Helper loaded: language_helper
DEBUG - 2022-11-10 03:33:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 03:33:07 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 03:33:07 --> Controller Class Initialized
INFO - 2022-11-10 03:33:07 --> File loaded: E:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-10 03:33:07 --> Final output sent to browser
DEBUG - 2022-11-10 03:33:07 --> Total execution time: 0.1188
INFO - 2022-11-10 03:33:07 --> Config Class Initialized
INFO - 2022-11-10 03:33:07 --> Hooks Class Initialized
DEBUG - 2022-11-10 03:33:07 --> UTF-8 Support Enabled
INFO - 2022-11-10 03:33:07 --> Utf8 Class Initialized
INFO - 2022-11-10 03:33:07 --> URI Class Initialized
DEBUG - 2022-11-10 03:33:07 --> No URI present. Default controller set.
INFO - 2022-11-10 03:33:07 --> Router Class Initialized
INFO - 2022-11-10 03:33:07 --> Output Class Initialized
INFO - 2022-11-10 03:33:07 --> Security Class Initialized
DEBUG - 2022-11-10 03:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 03:33:07 --> Input Class Initialized
INFO - 2022-11-10 03:33:07 --> Language Class Initialized
INFO - 2022-11-10 03:33:07 --> Loader Class Initialized
INFO - 2022-11-10 03:33:07 --> Helper loaded: url_helper
INFO - 2022-11-10 03:33:07 --> Database Driver Class Initialized
INFO - 2022-11-10 03:33:07 --> Helper loaded: form_helper
INFO - 2022-11-10 03:33:07 --> Form Validation Class Initialized
DEBUG - 2022-11-10 03:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 03:33:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 03:33:07 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 03:33:07 --> Email Class Initialized
INFO - 2022-11-10 03:33:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 03:33:07 --> Helper loaded: cookie_helper
INFO - 2022-11-10 03:33:07 --> Helper loaded: language_helper
DEBUG - 2022-11-10 03:33:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 03:33:07 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 03:33:07 --> Controller Class Initialized
INFO - 2022-11-10 03:33:07 --> File loaded: E:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-10 03:33:07 --> Final output sent to browser
DEBUG - 2022-11-10 03:33:07 --> Total execution time: 0.0468
INFO - 2022-11-10 03:33:08 --> Config Class Initialized
INFO - 2022-11-10 03:33:08 --> Hooks Class Initialized
DEBUG - 2022-11-10 03:33:08 --> UTF-8 Support Enabled
INFO - 2022-11-10 03:33:08 --> Utf8 Class Initialized
INFO - 2022-11-10 03:33:08 --> URI Class Initialized
DEBUG - 2022-11-10 03:33:08 --> No URI present. Default controller set.
INFO - 2022-11-10 03:33:08 --> Router Class Initialized
INFO - 2022-11-10 03:33:08 --> Output Class Initialized
INFO - 2022-11-10 03:33:08 --> Security Class Initialized
DEBUG - 2022-11-10 03:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 03:33:08 --> Input Class Initialized
INFO - 2022-11-10 03:33:08 --> Language Class Initialized
INFO - 2022-11-10 03:33:08 --> Loader Class Initialized
INFO - 2022-11-10 03:33:08 --> Helper loaded: url_helper
INFO - 2022-11-10 03:33:08 --> Database Driver Class Initialized
INFO - 2022-11-10 03:33:08 --> Helper loaded: form_helper
INFO - 2022-11-10 03:33:08 --> Form Validation Class Initialized
DEBUG - 2022-11-10 03:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 03:33:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 03:33:08 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 03:33:08 --> Email Class Initialized
INFO - 2022-11-10 03:33:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 03:33:08 --> Helper loaded: cookie_helper
INFO - 2022-11-10 03:33:08 --> Helper loaded: language_helper
DEBUG - 2022-11-10 03:33:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 03:33:08 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 03:33:08 --> Controller Class Initialized
INFO - 2022-11-10 03:33:08 --> File loaded: E:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-10 03:33:08 --> Final output sent to browser
DEBUG - 2022-11-10 03:33:08 --> Total execution time: 0.0496
INFO - 2022-11-10 03:33:08 --> Config Class Initialized
INFO - 2022-11-10 03:33:08 --> Hooks Class Initialized
DEBUG - 2022-11-10 03:33:08 --> UTF-8 Support Enabled
INFO - 2022-11-10 03:33:08 --> Utf8 Class Initialized
INFO - 2022-11-10 03:33:08 --> URI Class Initialized
DEBUG - 2022-11-10 03:33:08 --> No URI present. Default controller set.
INFO - 2022-11-10 03:33:08 --> Router Class Initialized
INFO - 2022-11-10 03:33:08 --> Output Class Initialized
INFO - 2022-11-10 03:33:08 --> Security Class Initialized
DEBUG - 2022-11-10 03:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 03:33:08 --> Input Class Initialized
INFO - 2022-11-10 03:33:08 --> Language Class Initialized
INFO - 2022-11-10 03:33:08 --> Loader Class Initialized
INFO - 2022-11-10 03:33:08 --> Helper loaded: url_helper
INFO - 2022-11-10 03:33:08 --> Database Driver Class Initialized
INFO - 2022-11-10 03:33:08 --> Helper loaded: form_helper
INFO - 2022-11-10 03:33:08 --> Form Validation Class Initialized
DEBUG - 2022-11-10 03:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 03:33:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 03:33:08 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 03:33:08 --> Email Class Initialized
INFO - 2022-11-10 03:33:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 03:33:08 --> Helper loaded: cookie_helper
INFO - 2022-11-10 03:33:08 --> Helper loaded: language_helper
DEBUG - 2022-11-10 03:33:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 03:33:08 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 03:33:08 --> Controller Class Initialized
INFO - 2022-11-10 03:33:08 --> File loaded: E:\xampp\htdocs\ekatalog\application\views\welcome_message.php
INFO - 2022-11-10 03:33:08 --> Final output sent to browser
DEBUG - 2022-11-10 03:33:08 --> Total execution time: 0.0479
INFO - 2022-11-10 03:34:21 --> Config Class Initialized
INFO - 2022-11-10 03:34:21 --> Hooks Class Initialized
DEBUG - 2022-11-10 03:34:21 --> UTF-8 Support Enabled
INFO - 2022-11-10 03:34:21 --> Utf8 Class Initialized
INFO - 2022-11-10 03:34:21 --> URI Class Initialized
INFO - 2022-11-10 03:34:21 --> Router Class Initialized
INFO - 2022-11-10 03:34:21 --> Output Class Initialized
INFO - 2022-11-10 03:34:21 --> Security Class Initialized
DEBUG - 2022-11-10 03:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 03:34:21 --> Input Class Initialized
INFO - 2022-11-10 03:34:21 --> Language Class Initialized
INFO - 2022-11-10 03:34:21 --> Loader Class Initialized
INFO - 2022-11-10 03:34:21 --> Helper loaded: url_helper
INFO - 2022-11-10 03:34:21 --> Database Driver Class Initialized
INFO - 2022-11-10 03:34:21 --> Helper loaded: form_helper
INFO - 2022-11-10 03:34:21 --> Form Validation Class Initialized
DEBUG - 2022-11-10 03:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 03:34:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 03:34:21 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 03:34:21 --> Email Class Initialized
INFO - 2022-11-10 03:34:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 03:34:21 --> Helper loaded: cookie_helper
INFO - 2022-11-10 03:34:21 --> Helper loaded: language_helper
DEBUG - 2022-11-10 03:34:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 03:34:21 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 03:34:21 --> Controller Class Initialized
INFO - 2022-11-10 03:34:21 --> Model "Penerbit_model" initialized
ERROR - 2022-11-10 03:34:21 --> Query error: Table 'db_ekatalog.penerbit' doesn't exist - Invalid query: SELECT *
FROM `penerbit`
INFO - 2022-11-10 03:34:21 --> Language file loaded: language/english/db_lang.php
INFO - 2022-11-10 03:34:57 --> Config Class Initialized
INFO - 2022-11-10 03:34:57 --> Hooks Class Initialized
DEBUG - 2022-11-10 03:34:57 --> UTF-8 Support Enabled
INFO - 2022-11-10 03:34:57 --> Utf8 Class Initialized
INFO - 2022-11-10 03:34:57 --> URI Class Initialized
INFO - 2022-11-10 03:34:57 --> Router Class Initialized
INFO - 2022-11-10 03:34:57 --> Output Class Initialized
INFO - 2022-11-10 03:34:57 --> Security Class Initialized
DEBUG - 2022-11-10 03:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 03:34:57 --> Input Class Initialized
INFO - 2022-11-10 03:34:57 --> Language Class Initialized
INFO - 2022-11-10 03:34:57 --> Loader Class Initialized
INFO - 2022-11-10 03:34:57 --> Helper loaded: url_helper
INFO - 2022-11-10 03:34:57 --> Database Driver Class Initialized
INFO - 2022-11-10 03:34:57 --> Helper loaded: form_helper
INFO - 2022-11-10 03:34:57 --> Form Validation Class Initialized
DEBUG - 2022-11-10 03:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 03:34:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 03:34:57 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 03:34:57 --> Email Class Initialized
INFO - 2022-11-10 03:34:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 03:34:57 --> Helper loaded: cookie_helper
INFO - 2022-11-10 03:34:57 --> Helper loaded: language_helper
DEBUG - 2022-11-10 03:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 03:34:57 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 03:34:57 --> Controller Class Initialized
INFO - 2022-11-10 03:34:57 --> Model "Penerbit_model" initialized
INFO - 2022-11-10 04:04:00 --> Config Class Initialized
INFO - 2022-11-10 04:04:00 --> Hooks Class Initialized
DEBUG - 2022-11-10 04:04:00 --> UTF-8 Support Enabled
INFO - 2022-11-10 04:04:00 --> Utf8 Class Initialized
INFO - 2022-11-10 04:04:00 --> URI Class Initialized
INFO - 2022-11-10 04:04:00 --> Router Class Initialized
INFO - 2022-11-10 04:04:00 --> Output Class Initialized
INFO - 2022-11-10 04:04:00 --> Security Class Initialized
DEBUG - 2022-11-10 04:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 04:04:00 --> Input Class Initialized
INFO - 2022-11-10 04:04:00 --> Language Class Initialized
INFO - 2022-11-10 04:04:00 --> Loader Class Initialized
INFO - 2022-11-10 04:04:00 --> Helper loaded: url_helper
INFO - 2022-11-10 04:04:00 --> Database Driver Class Initialized
INFO - 2022-11-10 04:04:00 --> Helper loaded: form_helper
INFO - 2022-11-10 04:04:00 --> Form Validation Class Initialized
DEBUG - 2022-11-10 04:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 04:04:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 04:04:00 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 04:04:00 --> Email Class Initialized
INFO - 2022-11-10 04:04:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 04:04:00 --> Helper loaded: cookie_helper
INFO - 2022-11-10 04:04:00 --> Helper loaded: language_helper
DEBUG - 2022-11-10 04:04:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 04:04:00 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 04:04:00 --> Controller Class Initialized
INFO - 2022-11-10 04:04:00 --> Model "Penerbit_model" initialized
INFO - 2022-11-10 04:19:03 --> Config Class Initialized
INFO - 2022-11-10 04:19:03 --> Hooks Class Initialized
DEBUG - 2022-11-10 04:19:03 --> UTF-8 Support Enabled
INFO - 2022-11-10 04:19:03 --> Utf8 Class Initialized
INFO - 2022-11-10 04:19:03 --> URI Class Initialized
INFO - 2022-11-10 04:19:03 --> Router Class Initialized
INFO - 2022-11-10 04:19:03 --> Output Class Initialized
INFO - 2022-11-10 04:19:03 --> Security Class Initialized
DEBUG - 2022-11-10 04:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 04:19:03 --> Input Class Initialized
INFO - 2022-11-10 04:19:03 --> Language Class Initialized
INFO - 2022-11-10 04:19:03 --> Loader Class Initialized
INFO - 2022-11-10 04:19:03 --> Helper loaded: url_helper
INFO - 2022-11-10 04:19:03 --> Database Driver Class Initialized
INFO - 2022-11-10 04:19:03 --> Helper loaded: form_helper
INFO - 2022-11-10 04:19:03 --> Form Validation Class Initialized
DEBUG - 2022-11-10 04:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 04:19:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 04:19:03 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 04:19:03 --> Email Class Initialized
INFO - 2022-11-10 04:19:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 04:19:03 --> Helper loaded: cookie_helper
INFO - 2022-11-10 04:19:03 --> Helper loaded: language_helper
DEBUG - 2022-11-10 04:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 04:19:03 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 04:19:03 --> Controller Class Initialized
INFO - 2022-11-10 04:19:03 --> Model "Penerbit_model" initialized
INFO - 2022-11-10 04:19:32 --> Config Class Initialized
INFO - 2022-11-10 04:19:32 --> Hooks Class Initialized
DEBUG - 2022-11-10 04:19:32 --> UTF-8 Support Enabled
INFO - 2022-11-10 04:19:32 --> Utf8 Class Initialized
INFO - 2022-11-10 04:19:32 --> URI Class Initialized
INFO - 2022-11-10 04:19:32 --> Router Class Initialized
INFO - 2022-11-10 04:19:32 --> Output Class Initialized
INFO - 2022-11-10 04:19:32 --> Security Class Initialized
DEBUG - 2022-11-10 04:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 04:19:32 --> Input Class Initialized
INFO - 2022-11-10 04:19:32 --> Language Class Initialized
INFO - 2022-11-10 04:19:32 --> Loader Class Initialized
INFO - 2022-11-10 04:19:32 --> Helper loaded: url_helper
INFO - 2022-11-10 04:19:32 --> Database Driver Class Initialized
INFO - 2022-11-10 04:19:32 --> Helper loaded: form_helper
INFO - 2022-11-10 04:19:32 --> Form Validation Class Initialized
DEBUG - 2022-11-10 04:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 04:19:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 04:19:32 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 04:19:32 --> Email Class Initialized
INFO - 2022-11-10 04:19:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 04:19:32 --> Helper loaded: cookie_helper
INFO - 2022-11-10 04:19:32 --> Helper loaded: language_helper
DEBUG - 2022-11-10 04:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 04:19:32 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 04:19:32 --> Controller Class Initialized
INFO - 2022-11-10 04:19:32 --> Model "Penerbit_model" initialized
INFO - 2022-11-10 06:44:24 --> Config Class Initialized
INFO - 2022-11-10 06:44:24 --> Hooks Class Initialized
DEBUG - 2022-11-10 06:44:24 --> UTF-8 Support Enabled
INFO - 2022-11-10 06:44:24 --> Utf8 Class Initialized
INFO - 2022-11-10 06:44:24 --> URI Class Initialized
INFO - 2022-11-10 06:44:24 --> Router Class Initialized
INFO - 2022-11-10 06:44:24 --> Output Class Initialized
INFO - 2022-11-10 06:44:24 --> Security Class Initialized
DEBUG - 2022-11-10 06:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 06:44:24 --> Input Class Initialized
INFO - 2022-11-10 06:44:24 --> Language Class Initialized
INFO - 2022-11-10 06:44:24 --> Loader Class Initialized
INFO - 2022-11-10 06:44:24 --> Helper loaded: url_helper
INFO - 2022-11-10 06:44:24 --> Database Driver Class Initialized
INFO - 2022-11-10 06:44:24 --> Helper loaded: form_helper
INFO - 2022-11-10 06:44:24 --> Form Validation Class Initialized
DEBUG - 2022-11-10 06:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 06:44:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 06:44:24 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 06:44:24 --> Email Class Initialized
INFO - 2022-11-10 06:44:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 06:44:24 --> Helper loaded: cookie_helper
INFO - 2022-11-10 06:44:24 --> Helper loaded: language_helper
DEBUG - 2022-11-10 06:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 06:44:24 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 06:44:24 --> Controller Class Initialized
INFO - 2022-11-10 06:44:24 --> Model "Penerbit_model" initialized
INFO - 2022-11-10 06:44:24 --> Final output sent to browser
DEBUG - 2022-11-10 06:44:24 --> Total execution time: 0.1294
INFO - 2022-11-10 06:44:58 --> Config Class Initialized
INFO - 2022-11-10 06:44:58 --> Hooks Class Initialized
DEBUG - 2022-11-10 06:44:58 --> UTF-8 Support Enabled
INFO - 2022-11-10 06:44:58 --> Utf8 Class Initialized
INFO - 2022-11-10 06:44:58 --> URI Class Initialized
INFO - 2022-11-10 06:44:58 --> Router Class Initialized
INFO - 2022-11-10 06:44:58 --> Output Class Initialized
INFO - 2022-11-10 06:44:58 --> Security Class Initialized
DEBUG - 2022-11-10 06:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 06:44:58 --> Input Class Initialized
INFO - 2022-11-10 06:44:58 --> Language Class Initialized
INFO - 2022-11-10 06:44:58 --> Loader Class Initialized
INFO - 2022-11-10 06:44:58 --> Helper loaded: url_helper
INFO - 2022-11-10 06:44:58 --> Database Driver Class Initialized
INFO - 2022-11-10 06:44:58 --> Helper loaded: form_helper
INFO - 2022-11-10 06:44:58 --> Form Validation Class Initialized
DEBUG - 2022-11-10 06:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 06:44:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 06:44:58 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 06:44:58 --> Email Class Initialized
INFO - 2022-11-10 06:44:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 06:44:58 --> Helper loaded: cookie_helper
INFO - 2022-11-10 06:44:58 --> Helper loaded: language_helper
DEBUG - 2022-11-10 06:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 06:44:58 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 06:44:58 --> Controller Class Initialized
INFO - 2022-11-10 06:44:58 --> Model "Penerbit_model" initialized
INFO - 2022-11-10 06:44:58 --> Final output sent to browser
DEBUG - 2022-11-10 06:44:58 --> Total execution time: 0.0485
INFO - 2022-11-10 08:33:48 --> Config Class Initialized
INFO - 2022-11-10 08:33:48 --> Hooks Class Initialized
DEBUG - 2022-11-10 08:33:48 --> UTF-8 Support Enabled
INFO - 2022-11-10 08:33:48 --> Utf8 Class Initialized
INFO - 2022-11-10 08:33:48 --> URI Class Initialized
INFO - 2022-11-10 08:33:48 --> Router Class Initialized
INFO - 2022-11-10 08:33:48 --> Output Class Initialized
INFO - 2022-11-10 08:33:48 --> Security Class Initialized
DEBUG - 2022-11-10 08:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 08:33:48 --> Input Class Initialized
INFO - 2022-11-10 08:33:48 --> Language Class Initialized
INFO - 2022-11-10 08:33:48 --> Loader Class Initialized
INFO - 2022-11-10 08:33:48 --> Helper loaded: url_helper
INFO - 2022-11-10 08:33:48 --> Database Driver Class Initialized
INFO - 2022-11-10 08:33:48 --> Helper loaded: form_helper
INFO - 2022-11-10 08:33:48 --> Form Validation Class Initialized
DEBUG - 2022-11-10 08:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 08:33:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 08:33:48 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 08:33:48 --> Email Class Initialized
INFO - 2022-11-10 08:33:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 08:33:48 --> Helper loaded: cookie_helper
INFO - 2022-11-10 08:33:48 --> Helper loaded: language_helper
DEBUG - 2022-11-10 08:33:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 08:33:49 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 08:33:49 --> Controller Class Initialized
INFO - 2022-11-10 08:33:49 --> Model "Penerbit_model" initialized
ERROR - 2022-11-10 08:33:49 --> Severity: Notice --> Undefined index: telpon E:\xampp\htdocs\ekatalog\application\views\penerbit\index.php 21
ERROR - 2022-11-10 08:33:49 --> Severity: Notice --> Undefined index: telpon E:\xampp\htdocs\ekatalog\application\views\penerbit\index.php 21
INFO - 2022-11-10 08:33:49 --> File loaded: E:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-10 08:33:49 --> Final output sent to browser
DEBUG - 2022-11-10 08:33:49 --> Total execution time: 1.2083
INFO - 2022-11-10 08:34:36 --> Config Class Initialized
INFO - 2022-11-10 08:34:36 --> Hooks Class Initialized
DEBUG - 2022-11-10 08:34:36 --> UTF-8 Support Enabled
INFO - 2022-11-10 08:34:36 --> Utf8 Class Initialized
INFO - 2022-11-10 08:34:36 --> URI Class Initialized
INFO - 2022-11-10 08:34:36 --> Router Class Initialized
INFO - 2022-11-10 08:34:36 --> Output Class Initialized
INFO - 2022-11-10 08:34:36 --> Security Class Initialized
DEBUG - 2022-11-10 08:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 08:34:36 --> Input Class Initialized
INFO - 2022-11-10 08:34:36 --> Language Class Initialized
INFO - 2022-11-10 08:34:36 --> Loader Class Initialized
INFO - 2022-11-10 08:34:36 --> Helper loaded: url_helper
INFO - 2022-11-10 08:34:36 --> Database Driver Class Initialized
INFO - 2022-11-10 08:34:36 --> Helper loaded: form_helper
INFO - 2022-11-10 08:34:36 --> Form Validation Class Initialized
DEBUG - 2022-11-10 08:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 08:34:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 08:34:36 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 08:34:36 --> Email Class Initialized
INFO - 2022-11-10 08:34:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 08:34:36 --> Helper loaded: cookie_helper
INFO - 2022-11-10 08:34:36 --> Helper loaded: language_helper
DEBUG - 2022-11-10 08:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 08:34:36 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 08:34:36 --> Controller Class Initialized
INFO - 2022-11-10 08:34:36 --> Model "Penerbit_model" initialized
ERROR - 2022-11-10 08:34:36 --> Severity: Notice --> Undefined index: telp E:\xampp\htdocs\ekatalog\application\views\penerbit\index.php 21
ERROR - 2022-11-10 08:34:36 --> Severity: Notice --> Undefined index: telp E:\xampp\htdocs\ekatalog\application\views\penerbit\index.php 21
INFO - 2022-11-10 08:34:36 --> File loaded: E:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-10 08:34:36 --> Final output sent to browser
DEBUG - 2022-11-10 08:34:36 --> Total execution time: 0.0941
INFO - 2022-11-10 08:34:38 --> Config Class Initialized
INFO - 2022-11-10 08:34:38 --> Hooks Class Initialized
DEBUG - 2022-11-10 08:34:38 --> UTF-8 Support Enabled
INFO - 2022-11-10 08:34:38 --> Utf8 Class Initialized
INFO - 2022-11-10 08:34:38 --> URI Class Initialized
INFO - 2022-11-10 08:34:38 --> Router Class Initialized
INFO - 2022-11-10 08:34:38 --> Output Class Initialized
INFO - 2022-11-10 08:34:38 --> Security Class Initialized
DEBUG - 2022-11-10 08:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 08:34:38 --> Input Class Initialized
INFO - 2022-11-10 08:34:38 --> Language Class Initialized
INFO - 2022-11-10 08:34:38 --> Loader Class Initialized
INFO - 2022-11-10 08:34:38 --> Helper loaded: url_helper
INFO - 2022-11-10 08:34:38 --> Database Driver Class Initialized
INFO - 2022-11-10 08:34:38 --> Helper loaded: form_helper
INFO - 2022-11-10 08:34:38 --> Form Validation Class Initialized
DEBUG - 2022-11-10 08:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 08:34:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 08:34:38 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 08:34:38 --> Email Class Initialized
INFO - 2022-11-10 08:34:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 08:34:38 --> Helper loaded: cookie_helper
INFO - 2022-11-10 08:34:38 --> Helper loaded: language_helper
DEBUG - 2022-11-10 08:34:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 08:34:38 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 08:34:38 --> Controller Class Initialized
INFO - 2022-11-10 08:34:38 --> Model "Penerbit_model" initialized
ERROR - 2022-11-10 08:34:38 --> Severity: Notice --> Undefined index: telp E:\xampp\htdocs\ekatalog\application\views\penerbit\index.php 21
ERROR - 2022-11-10 08:34:38 --> Severity: Notice --> Undefined index: telp E:\xampp\htdocs\ekatalog\application\views\penerbit\index.php 21
INFO - 2022-11-10 08:34:38 --> File loaded: E:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-10 08:34:38 --> Final output sent to browser
DEBUG - 2022-11-10 08:34:38 --> Total execution time: 0.0987
INFO - 2022-11-10 08:34:51 --> Config Class Initialized
INFO - 2022-11-10 08:34:51 --> Hooks Class Initialized
DEBUG - 2022-11-10 08:34:51 --> UTF-8 Support Enabled
INFO - 2022-11-10 08:34:51 --> Utf8 Class Initialized
INFO - 2022-11-10 08:34:51 --> URI Class Initialized
INFO - 2022-11-10 08:34:51 --> Router Class Initialized
INFO - 2022-11-10 08:34:51 --> Output Class Initialized
INFO - 2022-11-10 08:34:51 --> Security Class Initialized
DEBUG - 2022-11-10 08:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-10 08:34:51 --> Input Class Initialized
INFO - 2022-11-10 08:34:51 --> Language Class Initialized
INFO - 2022-11-10 08:34:51 --> Loader Class Initialized
INFO - 2022-11-10 08:34:51 --> Helper loaded: url_helper
INFO - 2022-11-10 08:34:51 --> Database Driver Class Initialized
INFO - 2022-11-10 08:34:51 --> Helper loaded: form_helper
INFO - 2022-11-10 08:34:51 --> Form Validation Class Initialized
DEBUG - 2022-11-10 08:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-10 08:34:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-11-10 08:34:51 --> Config file loaded: E:\xampp\htdocs\ekatalog\application\config/ion_auth.php
INFO - 2022-11-10 08:34:51 --> Email Class Initialized
INFO - 2022-11-10 08:34:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2022-11-10 08:34:51 --> Helper loaded: cookie_helper
INFO - 2022-11-10 08:34:51 --> Helper loaded: language_helper
DEBUG - 2022-11-10 08:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-11-10 08:34:51 --> Model "Ion_auth_model" initialized
INFO - 2022-11-10 08:34:51 --> Controller Class Initialized
INFO - 2022-11-10 08:34:51 --> Model "Penerbit_model" initialized
INFO - 2022-11-10 08:34:51 --> File loaded: E:\xampp\htdocs\ekatalog\application\views\penerbit/index.php
INFO - 2022-11-10 08:34:51 --> Final output sent to browser
DEBUG - 2022-11-10 08:34:51 --> Total execution time: 0.0761
