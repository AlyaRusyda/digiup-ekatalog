<?php
require_once 'Base_model.php';

class Penerbit_model extends Base_Model{
    //nama tabel
    var $table = "tbl_penerbit";
}