<!DOCTYPE html>
<html>

<head>
    <title>E Katalog</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= BASE_ASSETS ?>/bootstrap-5.2.2/css/bootstrap.min.css">

    <script type="text/javascript" src="<?= BASE_ASSETS ?>/bootstrap-
5.2.2/js/bootstrap.min.js"></script>

</head>

<body>